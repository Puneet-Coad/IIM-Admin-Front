import { combineReducers } from 'redux';
 


const appReducer = combineReducers({
    
});

export default appReducer;