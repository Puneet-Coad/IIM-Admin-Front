import React from "react";
import "../App.css";
import { HashRouter, Routes } from "react-router-dom";
import { AppRootContainer } from "./app-root/app-root.container";
import store from './store';
import { Provider } from 'react-redux';
import CssBaseline from '@mui/material/CssBaseline';
import theme from "../theme";
import { ThemeProvider } from "@mui/material";


export default function App() {
  return (
    <HashRouter >
      <CssBaseline />
      <Provider store={store}>
        <ThemeProvider theme={theme} >
          <AppRootContainer />
        </ThemeProvider>
      </Provider>

    </HashRouter>
  );
}
