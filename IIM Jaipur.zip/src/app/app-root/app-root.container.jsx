import AppRoot from './app-root.component';
import { connect } from 'react-redux';

const mapStateToProps = state => ({
    // isLoggedIn: state.customerPage.isLoggedIn,
    // loggedCustomer: state.customerPage.loggedCustomer,
});

export const AppRootContainer = connect(mapStateToProps, {})(AppRoot);