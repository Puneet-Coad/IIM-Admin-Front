import * as React from 'react';
import { Box, Grid, Container } from '@mui/material';
import RoutePath from '../../routes';
import Sidebar from '../../comon/sidebar';



export default function AppRoot(props) {
    // const { loggedCustomer, isLoggedIn } = props;

    return (
        <Container
            maxWidth="xl"
            sx={{
                background: "#F3F6FD",
                py: 2
            }}
        >
            <Grid
                container
                spacing={2}
            >
                <Grid
                    item xs={2}
                    sx={{ position: 'relative' }}
                >
                    <Box
                        sx={{
                            // position: 'fixed',
                            // top: 0,
                            textAlign: "center",
                            borderRadius: "20px",
                            overflowY: "scroll",
                            maxHeight: "90vh",
                            "&::-webkit-scrollbar": {
                                display: "none",
                                width: '0px',
                            },
                        }}
                    >
                        <Sidebar />
                    </Box>

                </Grid>
                <Grid item xs={10}>
                    <Box
                    >
                        <RoutePath />
                    </Box>
                </Grid>
            </Grid>
        </Container>
    );
}