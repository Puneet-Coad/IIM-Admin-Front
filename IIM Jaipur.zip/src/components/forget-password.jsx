import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";

import {Link} from "react-router-dom";

import TextField from "@mui/material/TextField";
import forgetimage from "../assets/forgetpassword.gif";

import PersonIcon from "@mui/icons-material/Person";
import InputAdornment from "@mui/material/InputAdornment"; 
const LoginForm = () => {
  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword((prevState) => !prevState);
  };

  return (
    <>
      <Grid container sx={{ justifyContent: "center" }}>
        <Grid item xs={8}>
          <Grid container sx={{ justifyContent: "space-between" }}>
            <Grid item xs={5}>
              <img src={forgetimage}></img>
            </Grid>
            <Grid item xs={5}>
              <Typography
                sx={{ fontSize: "32px", fontWeight: 700, color: "#676C7D" }}
              >
                Forget Password<span style={{ color: "#F04349" }}>!</span>
              </Typography>
              <Typography>
                Explore, learn, and grow with us. enjoy a seamless and enriching
                educational journey. lets begin!{" "}
              </Typography>
              <Box>
                <Typography
                  sx={{
                    margin: "20px auto",
                    fontSize: "17px",
                    fontWeight: 500,
                    color: "#676C7D",
                  }}
                >
                  Your Email
                </Typography>
                <TextField
                  sx={{
                    borderRadius: "10px",
                    background: "#EFF0F2",
                    width: "100%",
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "10px", // Set border radius
                    },
                  }}
                  variant="outlined"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PersonIcon sx={{ color: "#adadad" }} />
                      </InputAdornment>
                    ),
                  }}
                  placeholder="Enter your email"
                />

                <Button
                  variant="contained"
                  sx={{
                    width: "100%",
                    margin: "20px auto",
                    padding: "12px",
                    textTransform: "none",
                    background: "#F84E47",
                    transition:
                      "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                    "&:hover": {
                      background: "#FF665C", // Change background color on hover
                      transform: "translateY(-4px)",
                    },
                  }}
                >
                  Send Request
                </Button>
                <Link to="/">
                  <Button
                    variant="contained"
                    sx={{
                      width: "100%",
                      margin: "20px auto",
                      padding: "12px",
                      textTransform: "none",
                      background: "#F84E47",
                      transition:
                        "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                      "&:hover": {
                        background: "#FF665C", // Change background color on hover
                        transform: "translateY(-4px)",
                      },
                    }}
                  >
                    Back to login{" "}
                  </Button>
                </Link>
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default LoginForm;
