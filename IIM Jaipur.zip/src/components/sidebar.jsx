import React, { useState } from "react";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import MenuItem from "@mui/material/MenuItem";
import Button from "@mui/material/Button";
import classplus from "../assets/classs plus logo.png";

import { FaBookOpenReader } from "react-icons/fa6";
import { AiOutlineProfile } from "react-icons/ai";
import { FaBook } from "react-icons/fa";
import { CiHeart } from "react-icons/ci";
import { Route, useNavigate } from "react-router-dom";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import { FaHistory } from "react-icons/fa";
import { FaKey } from "react-icons/fa";




const Sidebar = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [menuOpenBatch, setMenuOpenBatch] = useState(false);
  const [menuOpenPeople, setMenuOpenPeople] = useState(false);
  const navigate = useNavigate();

  return (
    <Box>
      <Paper
        elevation={0}
        sx={{
          textAlign: "center",
          borderRadius: "20px",
          overflow: "scroll",
          "&::-webkit-scrollbar": {
            display: "none",
            position: "sticky",
          },
        }}
      >
        <Box sx={{ maxHeight: "101vh" }}>
          <Box sx={{ textAlign: "center" }}>
            <img
              src={classplus}
              style={{
                width: "70%",
                margin: "20px 0px auto",
              }}
              alt="Class Plus Logo"
            />
          </Box>


          <Box sx={{ display: "grid", padding: "20px" }}>
            <Button
              variant="contained"
              sx={{
                margin: "5px auto",
                width: "100%",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                background: "#E8F4FD",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px", // Removed duplicate property
                padding: "10px",
                color: "#6EC3EB",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
              }}
            >
              <FaBookOpenReader
                style={{ marginRight: "12px", fontSize: "16px" }}
              />
              Dashboard
            </Button>
            <Box>
              <Button
                onMouseEnter={() => setMenuOpen(true)}
                onMouseLeave={() => setMenuOpen(false)}
                sx={{
                  margin: "5px auto",
                  position: "relative",
                  width: "100%",
                  color: "#6EC3EB",
                  fontSize: "14px",
                  fontWeight: "600",
                  justifyContent: "start",
                  alignItems: "center",
                  textTransform: "none",
                  borderRadius: "9px",
                  padding: "10px",
                  "&:hover": {
                    backgroundColor: "#E8F4FD",
                    color: "#64C1EE",
                  },
                  transition: "0.6s",
                }}
              >
                <AiOutlineProfile
                  style={{ marginRight: "12px", fontSize: "16px" }}
                />
                Courses
              </Button>
              {menuOpen && (
                <Box
                  sx={{ left: "200px", top: "160px", position: "absolute" }}
                  style={{
                    width: "200px",
                    backgroundColor: "#fff",
                    boxShadow: "0px 8px 16px rgba(0, 0, 0, 0.1)",
                    borderRadius: "8px",
                    padding: "8px",
                    zIndex: 999999,
                    Transform: "1s",
                  }}
                  onMouseEnter={() => setMenuOpen(true)}
                  onMouseLeave={() => setMenuOpen(false)}
                >
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/course")}
                  >
                    My Courses
                  </MenuItem>
                  <MenuItem sx={{ fontWeight: "600", fontSize: "15px" }}>
                    Global Courses
                  </MenuItem>
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/managecoupons")}
                  >
                    Manage Coupons
                  </MenuItem>
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/backend addition")}
                  >
                    Backend Addition{" "}
                  </MenuItem>
                </Box>
              )}
            </Box> 
            <Box>
              <Button
                onMouseEnter={() => setMenuOpenBatch(true)}
                onMouseLeave={() => setMenuOpenBatch(false)}
                sx={{
                  margin: "5px auto",
                  position: "relative",
                  width: "100%",
                  color: "#6EC3EB",
                  fontSize: "14px",
                  fontWeight: "600",
                  justifyContent: "start",
                  alignItems: "center",
                  textTransform: "none",
                  borderRadius: "9px",
                  padding: "10px",
                  "&:hover": {
                    backgroundColor: "#E8F4FD",
                    color: "#64C1EE",
                  },
                  transition: "0.6s",
                }}
              >
                <AiOutlineProfile
                  style={{ marginRight: "12px", fontSize: "16px" }}
                />
                Batches
              </Button>
              {menuOpenBatch && (
                <Box
                  sx={{ left: "200px", top: "220px", position: "absolute" }}
                  style={{
                    width: "200px",
                    backgroundColor: "#fff",
                    boxShadow: "0px 8px 16px rgba(0, 0, 0, 0.1)",
                    borderRadius: "8px",
                    padding: "8px",
                    zIndex: 999999,
                    Transform: "1s",
                  }}
                  onMouseEnter={() => setMenuOpenBatch(true)}
                  onMouseLeave={() => setMenuOpenBatch(false)}
                >
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/managebatch")}
                  >
                    Manage Batch{" "}
                  </MenuItem>
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/managefees")}
                  >
                    Manage Fees{" "}
                  </MenuItem>
                </Box>
              )}
            </Box> 
            <Button
              sx={{
                margin: "5px auto",
                position: "relative",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
              onClick={() => navigate("/testportal")}
            >
              <AiOutlineProfile
                style={{ marginRight: "12px", fontSize: "16px" }}
              />
              Test Portal
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
            >
              <FaBook style={{ marginRight: "12px", fontSize: "16px" }} />
              Your App
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
            >
              <CiHeart style={{ marginRight: "12px", fontSize: "16px" }} />
              Landing Pages
            </Button>
            <Box>
              <Button
                onMouseEnter={() => setMenuOpenPeople(true)}
                onMouseLeave={() => setMenuOpenPeople(false)}
                sx={{
                  margin: "5px auto",
                  position: "relative",
                  width: "100%",
                  color: "#6EC3EB",
                  fontSize: "14px",
                  fontWeight: "600",
                  justifyContent: "start",
                  alignItems: "center",
                  textTransform: "none",
                  borderRadius: "9px",
                  padding: "10px",
                  "&:hover": {
                    backgroundColor: "#E8F4FD",
                    color: "#64C1EE",
                  },
                  transition: "0.6s",
                }}
              >
                <AiOutlineProfile
                  style={{ marginRight: "12px", fontSize: "16px" }}
                />
                People
              </Button>
              {menuOpenPeople && (
                <Box
                  sx={{
                    width: "200px",
                    backgroundColor: "#fff",
                    boxShadow: "0px 8px 16px rgba(0, 0, 0, 0.1)",
                    borderRadius: "8px",
                    padding: "8px",
                    zIndex: 999999,
                    Transform: "1s",
                    position: 'absolute',
                    left: "200px", top: "440px",
                  }}
                  onMouseEnter={() => setMenuOpenPeople(true)}
                  onMouseLeave={() => setMenuOpenPeople(false)}
                >
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/user")}
                  >
                    Users
                  </MenuItem>
                  <MenuItem sx={{ fontWeight: "600", fontSize: "15px" }}>
                    Team Members
                  </MenuItem>
                  <MenuItem
                    sx={{ fontWeight: "600", fontSize: "15px" }}
                    onClick={() => navigate("/managecoupons")}
                  >
                    Lead Enquiry
                  </MenuItem>
                </Box>
              )}
            </Box> 
            <Button
              sx={{
                margin: "5px auto",
                position: "relative",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
              onClick={() => navigate("/chat")}
            >
              <AiOutlineProfile
                style={{ marginRight: "12px", fontSize: "16px" }}
              />
              Chats
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                position: "relative",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
              onClick={() => navigate("/analytics")}
            >
              <AiOutlineProfile
                style={{ marginRight: "12px", fontSize: "16px" }}
              />
              Analytics
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
            >
              <FaHistory style={{ marginRight: "12px", fontSize: "16px" }} />
              Integrations
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
            >
              <PersonOutlineIcon
                style={{ marginRight: "12px", fontSize: "16px" }}
              />
              Campaigns
            </Button>
            <Button
              sx={{
                margin: "5px auto",
                width: "100%",
                color: "#6EC3EB",
                fontSize: "14px",
                fontWeight: "600",
                justifyContent: "start",
                alignItems: "center",
                textTransform: "none",
                borderRadius: "9px",
                padding: "10px",
                "&:hover": {
                  backgroundColor: "#E8F4FD",
                  color: "#64C1EE",
                },
                transition: "0.6s",
              }}
            >
              <FaKey style={{ marginRight: "12px", fontSize: "16px" }} />
              Account
            </Button>
          </Box>
          <Box
            sx={{
              background: "white",
              padding: "10px",
              borderRadius: "10px",
              textAlign: "center",
              bottom: "0px",
              position: "sticky",
            }}
          >
            <Button variant="contained">Help & Support</Button>
          </Box>
        </Box>
      </Paper>
    </Box>
  );
};

export default Sidebar;
