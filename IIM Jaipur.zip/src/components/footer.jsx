import * as React from "react";
import { Box, Grid, Button, Paper } from "@mui/material";
import { FaArrowLeft } from "react-icons/fa6";

const Footer = () => {
  return (
    <>
      <Grid
        item
        xs={12}
        sx={{ position: "sticky", bottom: "0px", width: "100%" }}
      >
        <Paper sx={{ padding: "10px", borderRadius: "20px" }}>
          {" "}
          <Button
            variant="outlined"
            sx={{
              border: "1px solid #CDEAE9",
              textTransform: "none",
              borderRadius: "10px",
              height: "50px",
            }}
          >
            <FaArrowLeft /> Previous{" "}
          </Button>
        </Paper>
      </Grid>
    </>
  );
};

export default Footer;
