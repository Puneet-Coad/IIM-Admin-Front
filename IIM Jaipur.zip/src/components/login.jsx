import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";

import {Link} from "react-router-dom";
import loginImage from "../assets/academy login.gif";
import TextField from "@mui/material/TextField";
import PersonIcon from "@mui/icons-material/Person";
import { FaKey } from "react-icons/fa";
import InputAdornment from "@mui/material/InputAdornment"; // Add this line
import { FaEye, FaEyeSlash } from "react-icons/fa";




const LoginForm = () => {
  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword((prevState) => !prevState);
  };

  return (
    <>
      <Grid container sx={{ justifyContent: "center" }}>
        <Grid item xs={8}>
          <Grid container sx={{ justifyContent: "space-between" }}>
            <Grid item xs={5}>
              <img src={loginImage}></img>
            </Grid>
            <Grid item xs={5}>
              <Typography
                sx={{ fontSize: "32px", fontWeight: 700, color: "#676C7D" }}
              >
                Log In <span style={{ color: "#F04349" }}>!</span>
              </Typography>
              <Typography>
                Explore, learn, and grow with us. enjoy a seamless and enriching
                educational journey. lets begin!{" "}
              </Typography>
              <Box>
                <Typography
                  sx={{
                    margin: "20px auto",
                    fontSize: "17px",
                    fontWeight: 500,
                    color: "#676C7D",
                  }}
                >
                  Your Emailllllll
                </Typography>
                <TextField
                  sx={{
                    borderRadius: "10px",
                    background: "#EFF0F2",
                    width: "100%",
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "10px", // Set border radius
                    },
                  }}
                  variant="outlined"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <PersonIcon sx={{ color: "#adadad" }} />
                      </InputAdornment>
                    ),
                  }}
                  placeholder="Enter your email"
                />
                <Typography
                  sx={{
                    margin: "20px auto",
                    fontSize: "17px",
                    fontWeight: 500,
                    color: "#676C7D",
                  }}
                >
                  Password
                </Typography>
                <TextField
                  sx={{
                    borderRadius: "10px",
                    background: "#EFF0F2",
                    width: "100%",
                    "& .MuiOutlinedInput-root": {
                      borderRadius: "10px", // Set border radius
                    },
                  }}
                  variant="outlined"
                  type={showPassword ? "text" : "password"} // Toggle between 'password' and 'text'
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <FaKey style={{ color: "#adadad" }} />
                      </InputAdornment>
                    ),
                    endAdornment: (
                      <InputAdornment
                        position="end"
                        onClick={togglePasswordVisibility}
                        style={{ cursor: "pointer" }}
                      >
                        {showPassword ? <FaEyeSlash /> : <FaEye />}
                      </InputAdornment>
                    ),
                  }}
                  placeholder="Enter your password"
                />
                 <Link to="/forget-password">
                  <Typography
                    sx={{
                      textAlign: "right",
                      color: "gray",
                      fontSize: "16px",
                      cursor: "pointer",
                    }}
                  >
                    Forgot password?
                  </Typography>
                </Link>

                <Button
                  variant="contained"
                  sx={{
                    width: "100%",
                    margin: "20px auto",
                    padding: "12px",
                    textTransform: "none",
                    background: "#F84E47",
                    transition:
                      "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                    "&:hover": {
                      background: "#FF665C", // Change background color on hover
                      transform: "translateY(-4px)",
                    },
                  }}
                >
                  Login
                </Button>
                {/* <Box sx={{ textAlign: "center" }}>
                  <Typography sx={{ color: "gray" }}>Login as-</Typography>
                  <Box
                    sx={{ display: "flex", justifyContent: "space-between" }}
                  >
                    <Button
                      variant="contained"
                      sx={{
                        margin: "20px 10px auto",
                        textTransform: "none",
                        background: "#F84E47",
                        width: "100%",

                        transition:
                          "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                        "&:hover": {
                          background: "#FF665C", // Change background color on hover
                          transform: "translateY(-4px)",
                        },
                      }}
                    >
                      Student{" "}
                    </Button>
                    <Button
                      variant="contained"
                      sx={{
                        margin: "20px 10px auto",
                        width: "100%",
                        textTransform: "none",
                        background: "#F84E47",

                        transition:
                          "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                        "&:hover": {
                          background: "#FF665C", // Change background color on hover
                          transform: "translateY(-4px)",
                        },
                      }}
                    >
                      Admin
                    </Button>
                    <Button
                      variant="contained"
                      sx={{
                        margin: "20px 10px auto",
                        textTransform: "none",
                        width: "100%",

                        background: "#F84E47",
                        transition:
                          "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                        "&:hover": {
                          background: "#FF665C", // Change background color on hover
                          transform: "translateY(-4px)",
                        },
                      }}
                    >
                      Instructor
                    </Button>
                  </Box>
                  <Typography sx={{ color: "gray", margin: "20px auto" }}>
                    Don't have an account ?{" "}
                    <span style={{ color: "#F84E47", cursor: "pointer" }}>
                      Sign Up
                    </span>
                  </Typography>
                  <Typography sx={{ color: "gray", margin: "20px auto" }}>
                    Or
                  </Typography>
                  <Button
                    variant="contained"
                    sx={{
                      width: "60%",
                      margin: "20px auto",
                      padding: "12px",
                      textTransform: "none",
                      background: "#F84E47",
                      transition:
                        "background-color 0.3s ease, transform 0.3s ease", // Smooth transition for both properties

                      "&:hover": {
                        background: "#FF665C", // Change background color on hover
                        transform: "translateY(-4px)",
                      },
                    }}
                  >
                    <FaFacebook style={{fontSize:"20px", marginRight:"10px"}} />
                    Continue with facebooks
                  </Button>
                </Box> */}
              </Box>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default LoginForm;
