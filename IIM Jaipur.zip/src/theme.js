import { createTheme } from "@mui/material/styles";


const theme = createTheme({
    palette: {
        primary: {
            main: '#3C99E8',   //button color 
            // dark: '#000000'  // hover color
            // color={ '#131B21'}
        },
        secondary: {
            main: '#F3F6FD',

        },
    },
});

export default theme;
