import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Stepper from "@mui/material/Stepper";
import Step from "@mui/material/Step";
import StepLabel from "@mui/material/StepLabel";
import Link from "@mui/material/Link";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";
import { Paper, Button, IconButton, Menu, Modal, Input, OutlinedInput, Dialog, DialogTitle, DialogActions } from "@mui/material";
import CloudUploadIcon from "@mui/icons-material/CloudUpload";
import { styled } from "@mui/material/styles";
import DeleteIcon from "@mui/icons-material/Delete";
import TextField from "@mui/material/TextField";
import Sidedrawer from "../../components/sidedrawer";
import Navbar from "../../comon/navbar/navbar";
import FolderIcon from "@mui/icons-material/Folder";
import NativeSelect from "@mui/material/NativeSelect";
import InputBase from "@mui/material/InputBase";
import { FaArrowLeft } from "react-icons/fa6";
import { FaIndianRupeeSign } from "react-icons/fa6";
import Divider from "@mui/material/Divider";
import { ImCheckboxChecked } from "react-icons/im";
import { FaLightbulb } from "react-icons/fa";
import { CiEdit } from "react-icons/ci";
import { HiUpload } from "react-icons/hi";
import Checkbox from "@mui/material/Checkbox";
import { useTheme } from "@mui/material/styles";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import Select from "@mui/material/Select";
import EventNoteIcon from "@mui/icons-material/EventNote";
import ImageIcon from "@mui/icons-material/Image";
import SourceIcon from "@mui/icons-material/Source";
import DownloadForOfflineIcon from "@mui/icons-material/DownloadForOffline";
import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import CloseIcon from "@mui/icons-material/Close";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import SearchIcon from "@mui/icons-material/Search";
import BorderColorIcon from "@mui/icons-material/BorderColor";
import LockOpenIcon from "@mui/icons-material/LockOpen";
import DeleteOutlineIcon from "@mui/icons-material/DeleteOutline";
import dayjs from "dayjs";
import { DemoContainer } from "@mui/x-date-pickers/internals/demo";
import { LocalizationProvider } from "@mui/x-date-pickers/LocalizationProvider";
import { AdapterDayjs } from "@mui/x-date-pickers/AdapterDayjs";
import { DateTimePicker } from "@mui/x-date-pickers/DateTimePicker";
import FolderModel from "./component/stepthreedialog/folderdialog"

export default function CreateCourse() {
    const [currentPage, setCurrentPage] = useState("ProfilePage");
    const [dialogOpen, setDialogOpen] = useState(false);
    const [opensubmenu, setopensubmenu] = useState(false);
    const [opensubmenuedit, setopensubmenuedit] = useState(false);
    const [submenu, setsubmenu] = useState(false);
    const [subfolderCreate, setsubfolderCreate] = useState(false);
    const [FolderData, setFolderData] = useState({ foldername: "", description: "" });
    const [allFolder, setallFolder] = useState([]);

    const makefolder = (e) => {
        setFolderData({ ...FolderData, [e.target.name]: e.target.value })
    }
    const foldersubmit = () => {
        setFolderData({ foldername: "", description: "" })
        let localData = []
        localData = allFolder.concat(FolderData)
        setallFolder(localData)
    }

    const changePage = (page) => {
        setCurrentPage(page);
    };

    const style = {
        position: "absolute",
        top: "50%",
        left: "50%",
        transform: "translate(-50%, -50%)",
        width: 400,
        bgcolor: "background.paper",
        border: "2px solid #000",
        boxShadow: 24,
        pt: 2,
        px: 4,
        pb: 3,
    };
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const [open1, setOpen1] = React.useState(false);
    const handleOpen1 = () => {
        setOpen1(true);
    };
    const handleClose1 = () => {
        setOpen1(false);
    };
    const [opena1, setOpena1] = React.useState(false);
    const handleOpena1 = () => {
        setOpena1(true);
    };
    const handleClosea1 = () => {
        setOpena1(false);
    };
    const [openaa1, setOpenaa1] = React.useState(false);
    const handleOpenaa1 = () => {
        setOpenaa1(true);
    };
    const handleCloseaa1 = () => {
        setOpenaa1(false);
    };
    const [openmm, setOpenmm] = React.useState(false);
    const handleOpenmm = () => {
        setOpenmm(true);
    };
    const handleClosemm = () => {
        setOpenmm(false);
    };
    const [anchorEl, setAnchorEl] = React.useState(null);

    const handleMenu = (event) => {
        setAnchorEl(event.currentTarget);
    };

    const handleClosep = () => {
        setAnchorEl(null);
    };
    const [anchorE2, setAnchorE2] = React.useState(null);
    const openm2 = Boolean(anchorE2);
    const handleClickm2 = (event) => {
        setAnchorE2(event.currentTarget);
    };
    const handleClosem2 = () => {
        setAnchorE2(null);
    };
    const [openm2s, setOpenm2s] = React.useState(false);
    const handleOpenm2s = () => setOpenm2s(true);
    const handleClosem2s = () => setOpenm2s(false);

    const label = { inputProps: { "aria-label": "Checkbox demo" } };
    const [value, setValue] = React.useState(dayjs("2022-04-17T15:30"));

    const BootstrapInput = styled(InputBase)(({ theme }) => ({
        "& .MuiInputBase-input": {
            borderRadius: 4,
            position: "relative",
            backgroundColor: theme.palette.background.paper,
            border: "1px solid #ced4da",
            fontSize: 16,
            padding: "10px 26px 10px 12px",
            transition: theme.transitions.create(["border-color", "box-shadow"]),
            fontFamily: [
                "-apple-system",
                "BlinkMacSystemFont",
                '"Segoe UI"',
                "Roboto",
                '"Helvetica Neue"',
                "Arial",
                "sans-serif",
                '"Apple Color Emoji"',
                '"Segoe UI Emoji"',
                '"Segoe UI Symbol"',
            ].join(","),
            "&:focus": {
                borderRadius: 4,
                borderColor: "#80bdff",
                boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
            },
        },
    }));

    const [age, setAge] = useState(10);
    const [year, setYear] = React.useState("");
    const handleChangeedit = (event) => {
        const selectedValue = parseInt(event.target.value);
        console.log("Selected value:", selectedValue);
        setAge(selectedValue);
    };
    const handleChangeyear = (event) => {
        setYear(event.target.value);
    };
    const [checked, setChecked] = React.useState(true);

    const handleChangecheck = (event) => {
        setChecked(event.target.checked);
    };
    const handleChangepromote = (event) => {
        setChecked(event.target.checked);
    };

    const theme = useTheme();
    const [personName, setPersonName] = React.useState([]);

    const handleChange = (event) => {
        const {
            target: { value },
        } = event;
        setPersonName(typeof value === "string" ? value.split(",") : value);
    };
    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 0;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 100,
            },
        },
    };

    const names = [
        "Oliver Hansen",
        "Van Henry",
        "April Tucker",
        "Ralph Hubbard",
        "Omar Alexander",
        "Carlos Abbott",
        "Miriam Wagner",
        "Bradley Wilkerson",
        "Virginia Andrews",
        "Kelly Snyder",
    ];

    function getStyles(name, personName, theme) {
        return {
            fontWeight:
                personName.indexOf(name) === -1
                    ? theme.typography.fontWeightRegular
                    : theme.typography.fontWeightMedium,
        };
    }

    const VisuallyHiddenInput = styled("input")({
        clip: "rect(0 0 0 0)",
        clipPath: "inset(50%)",
        height: 1,
        overflow: "hidden",
        position: "absolute",
        bottom: 0,
        left: 0,
        whiteSpace: "nowrap",
        width: 1,
    });
    console.log("Current age:", age);

    const StepOneForm = () => (
        <>
            <Grid container spacing={2} sx={{ justifyContent: "space-between" }}>
                <Grid item xs={4}>
                    <Paper elevation={0}>
                        <FormControl style={{ width: "100%" }}>
                            <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                                gutterBottom
                            >
                                Name{" "}
                            </Typography>
                            <TextField
                                style={{
                                    borderRadius: "12px",
                                    border: "1px solid #e1e1e1",
                                    padding: "5px 15px",
                                }}
                                sx={{
                                    transition: "0.3s ease-in-out",
                                    "&:hover": {
                                        boxShadow:
                                            " rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                    },
                                }}
                                size="small"
                                variant="standard"
                                placeholder="Enter Course Name"
                                InputProps={{ disableUnderline: true }}
                            />
                        </FormControl>
                        <FormControl style={{ width: "100%" }}>
                            <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                                gutterBottom
                            >
                                Description{" "}
                            </Typography>
                            <TextField
                                style={{
                                    borderRadius: "12px",
                                    border: "1px solid #e1e1e1",
                                    padding: "10px 15px",
                                    height: "100px",
                                }}
                                sx={{
                                    transition: "0.3s ease-in-out",
                                    "&:hover": {
                                        boxShadow:
                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                    },
                                }}
                                size="medium"
                                variant="standard"
                                placeholder="Enter course description here"
                                InputProps={{ disableUnderline: true }}
                            />
                        </FormControl>
                        <Typography
                            variant="subtitle1"
                            sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                            gutterBottom
                        >
                            Add Thumbnail{" "}
                        </Typography>
                        <Button
                            component="label"
                            role={undefined}
                            tabIndex={-1}
                            startIcon={<HiUpload />}
                            sx={{ textTransform: "none", fontSize: "12px", color: "#76C1D6" }}
                        >
                            Upload Thumbnail Image
                            <VisuallyHiddenInput type="file" />
                        </Button>
                        <Typography
                            sx={{
                                fontSize: "12px",
                                fontWeight: "500",
                                color: "#A7A6A9",
                                alignItems: "center",
                                display: "flex",
                                margin: "10px auto",
                            }}
                        >
                            {" "}
                            <FaLightbulb style={{ color: "#EDAA1D", marginRight: "8px" }} />
                            Recommend Image Size:
                            <span style={{ color: "black" }}>800*600,PNG or JPG file</span>
                        </Typography>
                        <Divider />

                        <Grid container>
                            <Grid item xs={6}>
                                <Box>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "20px",
                                        }}
                                        gutterBottom
                                    >
                                        Category{" "}
                                    </Typography>
                                    <FormControl sx={{ width: 300, borderRadius: 20 }}>
                                        <Select
                                            multiple
                                            displayEmpty
                                            value={personName}
                                            onChange={handleChange}
                                            input={
                                                <OutlinedInput
                                                    style={{
                                                        borderRadius: "16px",
                                                        width: "60%",
                                                        height: "40px",
                                                    }}
                                                />
                                            }
                                            renderValue={(selected) => {
                                                if (selected.length === 0) {
                                                    return (
                                                        <Typography
                                                            sx={{ fontSize: "14px", fontWeight: "500" }}
                                                        >
                                                            Select Category{" "}
                                                        </Typography>
                                                    );
                                                }

                                                return selected.join(", ");
                                            }}
                                            MenuProps={MenuProps}
                                            inputProps={{ "aria-label": "Without label" }}
                                        >
                                            {names.map((name) => (
                                                <MenuItem
                                                    key={name}
                                                    value={name}
                                                    style={getStyles(name, personName, theme)}
                                                >
                                                    {name}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Box>
                            </Grid>
                            <Grid item xs={6}>
                                <Box>
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "20px",
                                        }}
                                        gutterBottom
                                    >
                                        Sub Category{" "}
                                    </Typography>
                                    <FormControl sx={{ width: 300, borderRadius: 20 }}>
                                        <Select
                                            multiple
                                            displayEmpty
                                            value={personName}
                                            onChange={handleChange}
                                            input={
                                                <OutlinedInput
                                                    style={{
                                                        borderRadius: "16px",
                                                        width: "60%",
                                                        height: "40px",
                                                    }}
                                                />
                                            }
                                            renderValue={(selected) => {
                                                if (selected.length === 0) {
                                                    return (
                                                        <Typography
                                                            sx={{ fontSize: "14px", fontWeight: "500" }}
                                                        >
                                                            Select Category{" "}
                                                        </Typography>
                                                    );
                                                }

                                                return selected.join(", ");
                                            }}
                                            MenuProps={MenuProps}
                                            inputProps={{ "aria-label": "Without label" }}
                                        >
                                            {names.map((name) => (
                                                <MenuItem
                                                    key={name}
                                                    value={name}
                                                    style={getStyles(name, personName, theme)}
                                                >
                                                    {name}
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Box>
                            </Grid>
                        </Grid>
                    </Paper>
                </Grid>
                <Grid item xs={3} mt={4}>
                    <Paper elevation={0}>
                        <Box
                            sx={{
                                background: "#F3F6FD",
                                padding: "15px",
                                borderRadius: "15px",
                            }}
                        >
                            <Typography
                                variant="subtitle1"
                                sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                                gutterBottom
                            >
                                Features{" "}
                            </Typography>
                            <Box>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Allow Offline Download
                                </Typography>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Create Installments
                                </Typography>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Promote course with trial{" "}
                                </Typography>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Conduct LIVE Classes{" "}
                                </Typography>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Allow course Preview{" "}
                                </Typography>
                                <Typography
                                    sx={{
                                        display: "flex",
                                        alignItems: "center",
                                        fontSize: "15px",
                                        fontWeight: "500",
                                        margin: "10px auto",
                                    }}
                                >
                                    <ImCheckboxChecked
                                        style={{
                                            marginRight: "5px",
                                            color: "#09BC48",
                                            borderRadius: "20px",
                                            fontSize: "15px",
                                        }}
                                    />
                                    Limit course access{" "}
                                </Typography>
                            </Box>
                        </Box>
                    </Paper>
                </Grid>
            </Grid>
        </>
    );

    const StepTwoForm = () => (
        <Grid container spacing={2} sx={{ justifyContent: "space-between" }}>
            <Grid item xs={7}>
                <Paper elevation={0}>
                    <Typography
                        variant="subtitle1"
                        sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                        gutterBottom
                    >
                        Course Duration Type{" "}
                    </Typography>
                    <FormControl sx={{ width: "100%" }} variant="standard">
                        <NativeSelect
                            id="demo-customized-select-native"
                            value={age}
                            onChange={handleChangeedit}
                            input={<BootstrapInput />}
                        >
                            <option value={10}>Single Validity </option>
                            <option value={20}>Multiple Validity</option>
                            <option value={30}>Lifetime Validity</option>
                            <option value={40}>Course Expiry Date</option>
                        </NativeSelect>
                    </FormControl>
                    <Typography
                        sx={{ margin: "10px auto" }}
                        variant="caption"
                        display="block"
                        fontWeight={600}
                        mt={1}
                        gutterBottom
                    >
                        Course will expire after fixed period of time for all students based
                        on their purchase date.{" "}
                    </Typography>

                    {age === 10 && (
                        <Box className="Single validity">
                            <Grid container spacing={4}>
                                <Grid item xs={8}>
                                    {" "}
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            // placeholder="Enter course description here"
                                            InputProps={{ disableUnderline: true }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    <FormControl sx={{ width: "100%" }} variant="standard">
                                        <NativeSelect
                                            sx={{ borderRadius: "19px" }}
                                            id="demo-customized-select-native"
                                            value={year}
                                            onChange={handleChangeyear}
                                            input={<BootstrapInput />}
                                            style={{ textAlign: "center" }} // Align options to center
                                        >
                                            <option sx={{ margin: "10px auto" }} value={10}>
                                                Single Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={20}>
                                                Multiple Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={30}>
                                                Lifetime Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={40}>
                                                Course Expiry Date
                                            </option>
                                        </NativeSelect>
                                    </FormControl>
                                </Grid>
                            </Grid>

                            <Grid container spacing={4}>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Price{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Discount{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Effective Price{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12}>
                                    <Button
                                        component="label"
                                        role={undefined}
                                        tabIndex={-1}
                                        startIcon={<HiUpload />}
                                        sx={{
                                            textTransform: "none",
                                            fontSize: "12px",
                                            color: "#76C1D6",
                                            marginTop: "-20px",
                                        }}
                                    >
                                        Create Installments
                                        <VisuallyHiddenInput type="file" />
                                    </Button>
                                </Grid>
                                <Divider sx={{ marginTop: "10px" }} />

                                <Grid item xs={12} sx={{ textAlign: "center" }}>
                                    <Sidedrawer />
                                </Grid>
                            </Grid>
                        </Box>
                    )}

                    {age === 20 && (
                        <Box className="Multiple validity">
                            <Box
                                sx={{
                                    background: "#F3F6FD",
                                    padding: "10px",
                                    borderRadius: "12px",
                                }}
                            >
                                <Grid container spacing={4}>
                                    <Grid item xs={12}>
                                        <Box
                                            sx={{
                                                display: "flex",
                                                justifyContent: "space-between",
                                                height: "60px",
                                                alignItems: "center",
                                            }}
                                        >
                                            <Typography sx={{ fontWeight: "600" }}>
                                                3 Months(s).
                                                <span style={{ color: "#19ACE7", fontWeight: "600" }}>
                                                    ₹1.03
                                                </span>
                                            </Typography>
                                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                                <Button
                                                    component="label"
                                                    sx={{
                                                        textTransform: "none",
                                                        fontSize: "12px",
                                                        color: "#76C1D6",
                                                        marginTop: "0", // Adjusted marginTop value
                                                        background: "#e4f5ff",
                                                        borderRadius: "10px",
                                                        marginRight: "10px",
                                                        padding: "10px",
                                                        "&:hover": {
                                                            background: "#e4f5ff",
                                                        },
                                                    }}
                                                >
                                                    Cancel
                                                </Button>

                                                <Button
                                                    component="label"
                                                    sx={{
                                                        textTransform: "none",
                                                        fontSize: "12px",
                                                        color: "#76C1D6",
                                                        marginTop: "0", // Adjusted marginTop value
                                                        background: "#00A5E5",
                                                        borderRadius: "10px",
                                                        color: "white",
                                                        padding: "10px",
                                                        "&:hover": {
                                                            background: "#00A5E5",
                                                        },
                                                    }}
                                                >
                                                    Save
                                                </Button>
                                            </Box>
                                        </Box>
                                    </Grid>
                                    <Grid item xs={6}>
                                        {" "}
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                // placeholder="Enter course description here"
                                                InputProps={{ disableUnderline: true }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <FormControl sx={{ width: "100%" }} variant="standard">
                                            <NativeSelect
                                                sx={{ borderRadius: "19px" }}
                                                id="demo-customized-select-native"
                                                value={year}
                                                onChange={handleChangeyear}
                                                input={<BootstrapInput />}
                                                style={{ textAlign: "center" }} // Align options to center
                                            >
                                                <option sx={{ margin: "10px auto" }} value={10}>
                                                    Month(s){" "}
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={20}>
                                                    Multiple Validity
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={30}>
                                                    Lifetime Validity
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={40}>
                                                    Course Expiry Date
                                                </option>
                                            </NativeSelect>
                                        </FormControl>
                                    </Grid>
                                </Grid>

                                <Grid container spacing={4}>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Price{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Discount{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Effective Price{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item xs={12}>
                                        <Typography sx={{ fontSize: "11px" }}>
                                            <Checkbox
                                                checked={checked}
                                                onChange={handleChangepromote}
                                                inputProps={{ "aria-label": "controlled" }}
                                                sx={{ fontSize: "11px" }}
                                            />
                                            Select to promote this plan <Link href="#">i</Link>
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Box>

                            <Grid item xs={12}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: "space-between",
                                        height: "60px",
                                        alignItems: "center",
                                        background: "#F3F6FD",
                                        borderRadius: "12px",
                                        margin: "12px auto",
                                        border: "2px solid #A7F2EF",
                                        padding: "5px",
                                    }}
                                >
                                    <Typography sx={{ fontWeight: "600" }}>
                                        3 Months(s).
                                        <span style={{ color: "#19ACE7", fontWeight: "600" }}>
                                            ₹1.03
                                        </span>
                                    </Typography>
                                    <Box sx={{ display: "flex", alignItems: "center" }}>
                                        <Button
                                            variant=""
                                            startIcon={<DeleteIcon />}
                                            sx={{ color: "#A27D8C", textTransform: "none" }}
                                        >
                                            Delete
                                        </Button>

                                        <Button
                                            variant=""
                                            startIcon={<CiEdit />}
                                            sx={{ color: "#79A3B5", textTransform: "none" }}
                                        >
                                            Edit{" "}
                                        </Button>
                                    </Box>
                                </Box>
                            </Grid>
                        </Box>
                    )}

                    {age === 30 && (
                        <Box className="Lifetime validity">
                            <Grid container spacing={4}>
                                <Grid item xs={8}>
                                    {" "}
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            // placeholder="Enter course description here"
                                            InputProps={{ disableUnderline: true }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    <FormControl sx={{ width: "100%" }} variant="standard">
                                        <NativeSelect
                                            sx={{ borderRadius: "19px" }}
                                            id="demo-customized-select-native"
                                            value={year}
                                            onChange={handleChangeyear}
                                            input={<BootstrapInput />}
                                            style={{ textAlign: "center" }} // Align options to center
                                        >
                                            <option sx={{ margin: "10px auto" }} value={10}>
                                                Single Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={20}>
                                                Multiple Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={30}>
                                                Lifetime Validity
                                            </option>
                                            <option sx={{ margin: "10px auto" }} value={40}>
                                                Course Expiry Date
                                            </option>
                                        </NativeSelect>
                                    </FormControl>
                                </Grid>
                            </Grid>

                            <Grid container spacing={4}>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Price{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Discount{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={4}>
                                    {" "}
                                    <Typography
                                        variant="subtitle1"
                                        sx={{
                                            fontWeight: "700",
                                            fontSize: "13px",
                                            marginTop: "12px",
                                        }}
                                        gutterBottom
                                    >
                                        Effective Price{" "}
                                    </Typography>
                                    <FormControl style={{ width: "100%" }} variant="standard">
                                        <TextField
                                            style={{
                                                borderRadius: "30px",
                                                border: "1px solid #e1e1e1",
                                                height: "31px",
                                                padding: "6px 18px",
                                            }}
                                            sx={{
                                                transition: "0.3s ease-in-out",
                                                "&:hover": {
                                                    boxShadow:
                                                        "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                },
                                            }}
                                            size="medium"
                                            variant="standard"
                                            InputProps={{
                                                disableUnderline: true,
                                                startAdornment: (
                                                    <FaIndianRupeeSign
                                                        sx={{
                                                            color: "rgba(0, 0, 0, 0.54)",
                                                            marginRight: "6px",
                                                        }}
                                                    />
                                                ),
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item xs={12}>
                                    <Button
                                        component="label"
                                        role={undefined}
                                        tabIndex={-1}
                                        startIcon={<HiUpload />}
                                        sx={{
                                            textTransform: "none",
                                            fontSize: "12px",
                                            color: "#76C1D6",
                                            marginTop: "-20px",
                                        }}
                                    >
                                        Create Installments
                                        <VisuallyHiddenInput type="file" />
                                    </Button>
                                </Grid>
                                <Divider sx={{ marginTop: "10px" }} />


                            </Grid>
                        </Box>
                    )}

                    {age === 40 && (
                        <Box className="Course Expiry Date">
                            <Box
                                sx={{
                                    background: "#F3F6FD",
                                    padding: "10px",
                                    borderRadius: "12px",
                                }}
                            >
                                <Grid container spacing={4}>
                                    <Grid item xs={12}>
                                        <Box
                                            sx={{
                                                display: "flex",
                                                justifyContent: "space-between",
                                                height: "60px",
                                                alignItems: "center",
                                            }}
                                        >
                                            <Typography sx={{ fontWeight: "600" }}>
                                                3 Months(s).
                                                <span style={{ color: "#19ACE7", fontWeight: "600" }}>
                                                    ₹1.03
                                                </span>
                                            </Typography>
                                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                                <Button
                                                    component="label"
                                                    sx={{
                                                        textTransform: "none",
                                                        fontSize: "12px",
                                                        color: "#76C1D6",
                                                        marginTop: "0", // Adjusted marginTop value
                                                        background: "#e4f5ff",
                                                        borderRadius: "10px",
                                                        marginRight: "10px",
                                                        padding: "10px",
                                                        "&:hover": {
                                                            background: "#e4f5ff",
                                                        },
                                                    }}
                                                >
                                                    Cancel
                                                </Button>

                                                <Button
                                                    component="label"
                                                    sx={{
                                                        textTransform: "none",
                                                        fontSize: "12px",
                                                        color: "#76C1D6",
                                                        marginTop: "0", // Adjusted marginTop value
                                                        background: "#00A5E5",
                                                        borderRadius: "10px",
                                                        color: "white",
                                                        padding: "10px",
                                                        "&:hover": {
                                                            background: "#00A5E5",
                                                        },
                                                    }}
                                                >
                                                    Save
                                                </Button>
                                            </Box>
                                        </Box>
                                    </Grid>
                                    <Grid item xs={6}>
                                        {" "}
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                // placeholder="Enter course description here"
                                                InputProps={{ disableUnderline: true }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={6}>
                                        <FormControl sx={{ width: "100%" }} variant="standard">
                                            <NativeSelect
                                                sx={{ borderRadius: "19px" }}
                                                id="demo-customized-select-native"
                                                value={year}
                                                onChange={handleChangeyear}
                                                input={<BootstrapInput />}
                                                style={{ textAlign: "center" }} // Align options to center
                                            >
                                                <option sx={{ margin: "10px auto" }} value={10}>
                                                    Month(s){" "}
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={20}>
                                                    Multiple Validity
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={30}>
                                                    Lifetime Validity
                                                </option>
                                                <option sx={{ margin: "10px auto" }} value={40}>
                                                    Course Expiry Date
                                                </option>
                                            </NativeSelect>
                                        </FormControl>
                                    </Grid>
                                </Grid>

                                <Grid container spacing={4}>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Price{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Discount{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>
                                    <Grid item xs={4}>
                                        {" "}
                                        <Typography
                                            variant="subtitle1"
                                            sx={{
                                                fontWeight: "700",
                                                fontSize: "13px",
                                                marginTop: "12px",
                                            }}
                                            gutterBottom
                                        >
                                            Effective Price{" "}
                                        </Typography>
                                        <FormControl style={{ width: "100%" }} variant="standard">
                                            <TextField
                                                style={{
                                                    borderRadius: "30px",
                                                    border: "1px solid #e1e1e1",
                                                    height: "31px",
                                                    padding: "6px 18px",
                                                }}
                                                sx={{
                                                    transition: "0.3s ease-in-out",
                                                    "&:hover": {
                                                        boxShadow:
                                                            "rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                                    },
                                                }}
                                                size="medium"
                                                variant="standard"
                                                InputProps={{
                                                    disableUnderline: true,
                                                    startAdornment: (
                                                        <FaIndianRupeeSign
                                                            sx={{
                                                                color: "rgba(0, 0, 0, 0.54)",
                                                                marginRight: "6px",
                                                            }}
                                                        />
                                                    ),
                                                }}
                                            />
                                        </FormControl>
                                    </Grid>

                                    <Grid item xs={12}>
                                        <Typography sx={{ fontSize: "11px" }}>
                                            <Checkbox
                                                checked={checked}
                                                onChange={handleChangepromote}
                                                inputProps={{ "aria-label": "controlled" }}
                                                sx={{ fontSize: "11px" }}
                                            />
                                            Select to promote this plan <Link href="#">i</Link>
                                        </Typography>
                                    </Grid>
                                </Grid>
                            </Box>

                            <Grid item xs={12}>
                                <Box
                                    sx={{
                                        display: "flex",
                                        justifyContent: "space-between",
                                        height: "60px",
                                        alignItems: "center",
                                        background: "#F3F6FD",
                                        borderRadius: "12px",
                                        margin: "12px auto",
                                        border: "2px solid #A7F2EF",
                                        padding: "5px",
                                    }}
                                >
                                    <Typography sx={{ fontWeight: "600" }}>
                                        3 Months(s).
                                        <span style={{ color: "#19ACE7", fontWeight: "600" }}>
                                            ₹1.03
                                        </span>
                                    </Typography>
                                    <Box sx={{ display: "flex", alignItems: "center" }}>
                                        <Button
                                            variant=""
                                            startIcon={<DeleteIcon />}
                                            sx={{ color: "#A27D8C", textTransform: "none" }}
                                        >
                                            Delete
                                        </Button>

                                        <Button
                                            variant=""
                                            startIcon={<CiEdit />}
                                            sx={{ color: "#79A3B5", textTransform: "none" }}
                                        >
                                            Edit{" "}
                                        </Button>
                                    </Box>
                                </Box>
                            </Grid>
                        </Box>
                    )}
                </Paper>
            </Grid>
            <Grid item xs={3} mt={4}>
                <Paper elevation={0}>
                    <Box
                        sx={{
                            background: "#F3F6FD",
                            padding: "15px",
                            borderRadius: "15px",
                        }}
                    >
                        <Typography
                            variant="subtitle1"
                            sx={{ fontWeight: "700", fontSize: "13px", marginTop: "20px" }}
                            gutterBottom
                        >
                            Features{" "}
                        </Typography>
                        <Box>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Allow Offline Download
                            </Typography>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Create Installments
                            </Typography>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Promote course with trial{" "}
                            </Typography>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Conduct LIVE Classes{" "}
                            </Typography>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Allow course Preview{" "}
                            </Typography>
                            <Typography
                                sx={{
                                    display: "flex",
                                    alignItems: "center",
                                    fontSize: "15px",
                                    fontWeight: "500",
                                    margin: "10px auto",
                                }}
                            >
                                <ImCheckboxChecked
                                    style={{
                                        marginRight: "5px",
                                        color: "#09BC48",
                                        borderRadius: "20px",
                                        fontSize: "15px",
                                    }}
                                />
                                Limit course access{" "}
                            </Typography>
                        </Box>
                    </Box>
                </Paper>
            </Grid>
        </Grid>
    );

    const StepThreeForm = () => (
        <>
            <Grid container spacing={4} mt={1}>
                <Grid item xs={9}>
                    {currentPage === "ProfilePage" && (
                        <>
                            <Typography variant="h6">Contents</Typography>
                            {allFolder.map((x) => {
                                return (
                                    <>
                                        <Box
                                            sx={{
                                                borderRadius: "20px",
                                                px: "2%",
                                                overflowY: "scroll",
                                                height: "200px",
                                                "&::-webkit-scrollbar": {
                                                    width: "0.4em",
                                                },
                                                "&::-webkit-scrollbar-track": {
                                                    "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                                },
                                                "&::-webkit-scrollbar-thumb": {
                                                    backgroundColor: "rgba(0,0,0,.1)",
                                                    borderRadius: "10px",
                                                },
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                    "&:hover": { backgroundColor: "#ede9e8" },
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                }}
                                            >
                                                <Box display={"flex"}>
                                                    <Box
                                                        onClick={() => changePage("LecturePage")}
                                                        sx={{ display: "flex" }}
                                                    >
                                                        <FolderIcon color="primary" sx={{ fontSize: "60px" }} />
                                                        <Box p={"10px"}>
                                                            <Typography variant="h6">
                                                                {x?.foldername}
                                                            </Typography>
                                                            <Typography fontSize={"12px"}>
                                                                {x?.description}
                                                            </Typography>
                                                        </Box>
                                                    </Box>
                                                </Box>
                                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                    <Button variant="contained" onClick={() => { setsubmenu(true) }}>
                                                        <Typography fontSize={'13px'} textTransform={'none'}>+ Add</Typography>
                                                    </Button>
                                                    <Menu
                                                        id="long-menu"
                                                        sx={{
                                                            position: 'absolute'
                                                        }}
                                                        MenuListProps={{
                                                            'aria-labelledby': 'long-button',
                                                        }}
                                                        open={submenu}
                                                        onClose={() => { setsubmenu(false) }}
                                                        PaperProps={{
                                                            style: {
                                                                maxHeight: ITEM_HEIGHT * 4.5,
                                                                width: '20ch',
                                                            },
                                                        }}
                                                    >
                                                        <MenuItem onClick={() => { setsubfolderCreate(true) }}><FolderIcon fontSize="small" />Folder</MenuItem>
                                                        <Dialog
                                                            open={subfolderCreate}
                                                            onClose={() => { setsubfolderCreate(false) }}
                                                            aria-labelledby="draggable-dialog-title"
                                                        >
                                                            <DialogTitle style={{ cursor: 'move', width: '400px' }} id="draggable-dialog-title">
                                                                Create Folder
                                                            </DialogTitle>
                                                            <TextField
                                                                autoFocus
                                                                required
                                                                margin="dense"
                                                                id="subfoldername"
                                                                name="subfoldername"
                                                                label="Folder Name"
                                                                type="text"
                                                                sx={{ width: '90%', margin: 'auto' }}
                                                                variant="outlined"
                                                            />
                                                            <DialogActions>
                                                                <Button onClick={() => { setsubfolderCreate(false) }}>
                                                                    Cancel
                                                                </Button>
                                                                <Button onClick={() => { setsubfolderCreate(false) }}>Create</Button>
                                                            </DialogActions>
                                                        </Dialog>
                                                        <MenuItem><PlayCircleIcon fontSize="small" />Video</MenuItem>
                                                        <MenuItem><EventNoteIcon fontSize="small" />Online Test</MenuItem>
                                                        <MenuItem><EventNoteIcon fontSize="small" />Subjective Test</MenuItem>
                                                        <MenuItem><ImageIcon fontSize="small" />Document</MenuItem>
                                                        <MenuItem><ImageIcon fontSize="small" />Image</MenuItem>
                                                        <MenuItem><SourceIcon fontSize="small" />Zip File</MenuItem>
                                                        <MenuItem><DownloadForOfflineIcon fontSize="small" />Import Content</MenuItem>
                                                        <MenuItem><DownloadForOfflineIcon fontSize="small" />Import Live</MenuItem>
                                                    </Menu>
                                                    <Box>
                                                        <IconButton
                                                            size="large"
                                                            aria-label="account of current user"
                                                            aria-controls="menu-appbar"
                                                            aria-haspopup="true"
                                                            onClick={handleMenu}
                                                            color="inherit"
                                                        >
                                                            <MoreVertIcon />
                                                        </IconButton>
                                                        <Menu
                                                            id="menu-appbar"
                                                            anchorEl={anchorEl}
                                                            // anchorOrigin={{
                                                            //   vertical: 'bottom',
                                                            //   horizontal: 'right',
                                                            // }}

                                                            open={Boolean(anchorEl)}
                                                            onClose={handleClosep}
                                                        >
                                                            <MenuItem onClick={handleOpenmm}>
                                                                <BorderColorIcon /> &nbsp; Edit
                                                            </MenuItem>
                                                            <Modal
                                                                open={openmm}
                                                                onClose={handleClosemm}
                                                                aria-labelledby="parent-modal-title"
                                                                aria-describedby="parent-modal-description"
                                                            >
                                                                <Box
                                                                    sx={{ ...style, width: "40%" }}
                                                                    textAlign={"center"}
                                                                >
                                                                    <Box
                                                                        display={"flex"}
                                                                        justifyContent={"space-between"}
                                                                        alignItems={"center"}
                                                                    >
                                                                        <Typography>Edit Folder</Typography>
                                                                        <Button onClick={handleClosemm}>
                                                                            <CloseIcon sx={{ color: "#000" }} />
                                                                        </Button>
                                                                    </Box>
                                                                    <Divider />
                                                                    <Typography
                                                                        textAlign={"left"}
                                                                        fontSize={"8px"}
                                                                        p={2}
                                                                    >
                                                                        Folder Name
                                                                    </Typography>
                                                                    <Paper elevation={3} sx={{ mb: "20px", p: "5px" }}>
                                                                        <Typography textAlign={"left"}>
                                                                            VIDEO LECTURES
                                                                        </Typography>
                                                                    </Paper>
                                                                    <Divider />
                                                                    <Box
                                                                        sx={{
                                                                            display: "flex",
                                                                            justifyContent: "end",
                                                                            mt: "10px",
                                                                            gap: "5px",
                                                                        }}
                                                                    >
                                                                        <Button variant={"contained"}>Save</Button>
                                                                        <Button variant="outlined" disabled>
                                                                            Discard
                                                                        </Button>
                                                                    </Box>
                                                                </Box>
                                                            </Modal>
                                                            <MenuItem onClick={handleClosep}>
                                                                <DeleteOutlineIcon /> &nbsp; Remove
                                                            </MenuItem>
                                                            <MenuItem onClick={handleClosep}>
                                                                <EventNoteIcon /> &nbsp; Schedule
                                                            </MenuItem>
                                                        </Menu>
                                                    </Box>
                                                </Box>
                                            </Box>
                                            <Box sx={{ display: 'flex', width: "90%", alignItems: 'center', "&:hover": { backgroundColor: "#ede9e8" }, justifyContent: 'space-between', margin: "auto", }}>
                                                <Box
                                                    onClick={() => changePage("VideoLecturePage")}
                                                    sx={{
                                                        display: "flex",
                                                        width: '100%',
                                                    }}
                                                >
                                                    <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                                    <Typography fontSize={"11px"} fontWeight={500} py={1}>
                                                        Video Lectures
                                                    </Typography>
                                                </Box>
                                                <Box onClick={() => { setopensubmenu(true) }}><MoreVertIcon /></Box>
                                                <Menu
                                                    id="menu-appbar"
                                                    // anchorOrigin={{
                                                    //   vertical: 'bottom',
                                                    //   horizontal: 'right',
                                                    // }}

                                                    open={opensubmenu}
                                                    onClose={() => { setopensubmenu(false) }}
                                                >
                                                    <MenuItem onClick={() => { setopensubmenuedit(true) }}>
                                                        <BorderColorIcon /> &nbsp; Edit
                                                    </MenuItem>
                                                    <Modal
                                                        open={opensubmenuedit}
                                                        onClose={() => { setopensubmenuedit(false) }}
                                                        aria-labelledby="parent-modal-title"
                                                        aria-describedby="parent-modal-description"
                                                    >
                                                        <Box
                                                            sx={{ ...style, width: "40%" }}
                                                            textAlign={"center"}
                                                        >
                                                            <Box
                                                                display={"flex"}
                                                                justifyContent={"space-between"}
                                                                alignItems={"center"}
                                                            >
                                                                <Typography>Edit Folder</Typography>
                                                                <Button onClick={() => { setopensubmenuedit(false) }}>
                                                                    <CloseIcon sx={{ color: "#000" }} />
                                                                </Button>
                                                            </Box>
                                                            <Divider />
                                                            <Typography
                                                                textAlign={"left"}
                                                                fontSize={"8px"}
                                                                p={2}
                                                            >
                                                                Folder Name
                                                            </Typography>
                                                            <Paper elevation={3} sx={{ mb: "20px", p: "5px" }}>
                                                                <Typography textAlign={"left"}>
                                                                    VIDEO LECTURES
                                                                </Typography>
                                                            </Paper>
                                                            <Divider />
                                                            <Box
                                                                sx={{
                                                                    display: "flex",
                                                                    justifyContent: "end",
                                                                    mt: "10px",
                                                                    gap: "5px",
                                                                }}
                                                            >
                                                                <Button variant={"contained"}>Save</Button>
                                                                <Button variant="outlined" disabled>
                                                                    Discard
                                                                </Button>
                                                            </Box>
                                                        </Box>
                                                    </Modal>
                                                    <MenuItem onClick={() => { setopensubmenu(false) }}>
                                                        <DeleteOutlineIcon /> &nbsp; Remove
                                                    </MenuItem>
                                                    <MenuItem onClick={() => { setopensubmenu(false) }}>
                                                        <EventNoteIcon /> &nbsp; Schedule
                                                    </MenuItem>
                                                </Menu>
                                            </Box>
                                        </Box>
                                    </>
                                )
                            })}
                        </>
                    )}
                    {currentPage === "LecturePage" && (
                        <>
                            <Typography variant="h6" sx={{ display: "flex" }}>
                                <ArrowBackIcon onClick={() => changePage("ProfilePage")} />{" "}
                                Rajasthan State Eligibility Test &#40;set&#41; Mathematic &gt;
                                UNIT-05 CURVE TRACING
                            </Typography>
                            <Box
                                sx={{
                                    borderRadius: "20px",
                                    px: "2%",
                                    overflowY: "scroll",
                                    height: "200px",
                                    "&::-webkit-scrollbar": {
                                        width: "0.4em",
                                    },
                                    "&::-webkit-scrollbar-track": {
                                        "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                    },
                                    "&::-webkit-scrollbar-thumb": {
                                        backgroundColor: "rgba(0,0,0,.1)",
                                        borderRadius: "10px",
                                    },
                                }}
                            >
                                <Box
                                    display={"flex"}
                                    m={"auto"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" } }}
                                >
                                    <FolderIcon color="primary" sx={{ fontSize: "70px" }} />
                                    <Box p={1}>
                                        <Typography fontSize={"14px"}>Video Lectures</Typography>
                                        <Typography fontSize={"12px"}>
                                            3 Video &#40;s&#41;
                                        </Typography>
                                    </Box>
                                </Box>
                                <Box
                                    display={"flex"}
                                    width={"90%"}
                                    m={"auto"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" } }}
                                >
                                    <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                    <Box p={1}>
                                        <Typography fontSize={"14px"}>Video Lectures 1</Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12/03/2024
                                        </Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12.54.30
                                        </Typography>
                                    </Box>
                                </Box>
                                <Box
                                    display={"flex"}
                                    width={"90%"}
                                    m={"auto"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" } }}
                                >
                                    <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                    <Box p={1}>
                                        <Typography fontSize={"14px"}>Video Lectures 2</Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12/03/2024
                                        </Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12.54.30
                                        </Typography>
                                    </Box>
                                </Box>
                                <Box
                                    display={"flex"}
                                    width={"90%"}
                                    m={"auto"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" } }}
                                >
                                    <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                    <Box p={1}>
                                        <Typography fontSize={"14px"}>Video Lectures 3</Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12/03/2024
                                        </Typography>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            12.54.30
                                        </Typography>
                                    </Box>
                                </Box>
                                <Button sx={{ ml: "7%" }}>+ Add Contents</Button>
                            </Box>
                            <Box
                                display={"flex"}
                                m={"auto"}
                                sx={{ "&:hover": { backgroundColor: "#ede9e8" } }}
                            >
                                <FolderIcon color="primary" sx={{ fontSize: "70px" }} />
                                <Box p={1}>
                                    <Typography fontSize={"14px"}>Video Lectures</Typography>
                                    <Typography fontSize={"10px"} fontWeight={500}>
                                        3 Video &#40;s&#41;
                                    </Typography>
                                </Box>
                            </Box>
                        </>
                    )}
                    {currentPage === "VideoLecturePage" && (
                        <>
                            <Typography variant="h6" sx={{ display: "flex" }}>
                                <ArrowBackIcon onClick={() => changePage("ProfilePage")} />{" "}
                                Rajasthan State Eligibility Test &#40;set&#41; Mathematic &gt;
                                UNIT-05 CURVE TRACING &#40;Video Lectures&#41;
                            </Typography>
                            <Box
                                sx={{
                                    borderRadius: "20px",
                                    px: "2%",
                                    overflowY: "scroll",
                                    height: "200px",
                                    "&::-webkit-scrollbar": {
                                        width: "0.4em",
                                    },
                                    "&::-webkit-scrollbar-track": {
                                        "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                    },
                                    "&::-webkit-scrollbar-thumb": {
                                        backgroundColor: "rgba(0,0,0,.1)",
                                        borderRadius: "10px",
                                    },
                                }}
                            >
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" }, p: "10px" }}
                                >
                                    <Box display={"flex"} width={"90%"} m={"auto"}>
                                        <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                        <Box>
                                            <Typography fontSize={"14px"}>
                                                Video Lectures 1
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12/03/2024
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12.54.30
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <LockOpenIcon />
                                    <Box>
                                        <Button
                                            id="basic-button"
                                            aria-controls={openm2 ? "basic-menu" : undefined}
                                            aria-haspopup="true"
                                            aria-expanded={openm2 ? "true" : undefined}
                                            onClick={handleClickm2}
                                        >
                                            <MoreVertIcon />
                                        </Button>
                                        <Menu
                                            id="basic-menu"
                                            anchorEl={anchorE2}
                                            open={openm2}
                                            onClose={handleClosem2}
                                            MenuListProps={{
                                                "aria-labelledby": "basic-button",
                                            }}
                                        >
                                            <MenuItem onClick={handleClosem2}>
                                                <BorderColorIcon /> &nbsp; Edit
                                            </MenuItem>
                                            <MenuItem onClick={handleClosem2}>
                                                <DeleteOutlineIcon /> &nbsp; Remove
                                            </MenuItem>
                                            <MenuItem onClick={handleOpenm2s}>
                                                <EventNoteIcon /> &nbsp; Schedule
                                            </MenuItem>
                                            <Modal
                                                open={openm2s}
                                                onClose={handleClosem2s}
                                                aria-labelledby="modal-modal-title"
                                                aria-describedby="modal-modal-description"
                                            >
                                                <Box sx={style}>
                                                    <Box
                                                        display={"flex"}
                                                        justifyContent={"space-between"}
                                                        alignItems={"center"}
                                                    >
                                                        <Typography variant={"h6"}>
                                                            Schedule Content&#40;s&#41;
                                                        </Typography>
                                                        <Button onClick={handleClosem2s}>
                                                            <CloseIcon sx={{ color: "#000" }} />
                                                        </Button>
                                                    </Box>
                                                    <Divider />
                                                    <Typography fontSize={"10px"} sx={{ my: 2 }}>
                                                        Your selected content will be unlocked to the
                                                        student on the following date:
                                                    </Typography>


                                                    <LocalizationProvider dateAdapter={AdapterDayjs}>
                                                        <DemoContainer
                                                            components={["DateTimePicker", "DateTimePicker"]}
                                                        >
                                                            <DateTimePicker
                                                                label="Select date and time"
                                                                value={value}
                                                                onChange={(newValue) => setValue(newValue)}
                                                            />
                                                        </DemoContainer>
                                                    </LocalizationProvider>


                                                    <Typography fontSize={"10px"} sx={{ my: 2 }}>
                                                        Note - In case your content is already scheduled,
                                                        it'll be reset as per the new scheduling criteria
                                                    </Typography>
                                                    <Divider />
                                                    <Box mt={1}>
                                                        <Grid container spacing={5}>
                                                            <Grid item xs={6}>
                                                                <Button
                                                                    variant={"outlined"}
                                                                    onClick={handleClosem2s}
                                                                    fullWidth
                                                                >
                                                                    <CloseIcon /> &nbsp; Cancel
                                                                </Button>
                                                            </Grid>
                                                            <Grid item xs={6}>
                                                                <Button variant={"contained"} fullWidth>
                                                                    <EventNoteIcon /> &nbsp; Schedule
                                                                </Button>
                                                            </Grid>
                                                        </Grid>
                                                    </Box>
                                                </Box>
                                            </Modal>
                                            <MenuItem onClick={handleClosem2}>
                                                <LockOpenIcon /> &nbsp; Unlock
                                            </MenuItem>
                                        </Menu>
                                    </Box>
                                </Box>
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" }, p: "10px" }}
                                >
                                    <Box display={"flex"} width={"90%"} m={"auto"}>
                                        <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                        <Box>
                                            <Typography fontSize={"14px"}>
                                                Video Lectures 2
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12/03/2024
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12.54.30
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <LockOpenIcon />
                                    <MoreVertIcon />
                                </Box>
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" }, p: "10px" }}
                                >
                                    <Box display={"flex"} width={"90%"} m={"auto"}>
                                        <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                        <Box>
                                            <Typography fontSize={"14px"}>
                                                Video Lectures 3
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12/03/2024
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12.54.30
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <LockOpenIcon />
                                    <MoreVertIcon />
                                </Box>
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    sx={{ "&:hover": { backgroundColor: "#ede9e8" }, p: "10px" }}
                                >
                                    <Box display={"flex"} width={"90%"} m={"auto"}>
                                        <FolderIcon color="primary" sx={{ fontSize: "40px" }} />
                                        <Box>
                                            <Typography fontSize={"14px"}>
                                                Video Lectures 4
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12/03/2024
                                            </Typography>
                                            <Typography fontSize={"10px"} fontWeight={500}>
                                                12.54.30
                                            </Typography>
                                        </Box>
                                    </Box>
                                    <LockOpenIcon />
                                    <MoreVertIcon />
                                </Box>
                            </Box>
                        </>
                    )}
                </Grid>
                <Grid item xs={3}>
                    <Paper elevation={3} sx={{ p: "20px" }}>
                        <Typography variant="h6" sx={{ fontWeight: "800", m: "10px" }}>
                            Add content
                        </Typography>
                        <Button
                            onClick={() => setDialogOpen(true)}
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <FolderIcon color="primary" fontSize="small" /> &nbsp; Folder
                        </Button>

                        <Button
                            variant="text"
                            onClick={handleOpen}
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <PlayCircleIcon color="primary" fontSize="small" /> &nbsp; Video
                        </Button>
                        <Modal
                            open={open}
                            onClose={handleClose}
                            aria-labelledby="parent-modal-title"
                            aria-describedby="parent-modal-description"
                        >
                            <Box sx={{ ...style, width: "40%", p: "1" }} textAlign={"center"}>
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    alignItems={"center"}
                                >
                                    <Typography>Add Video</Typography>
                                    <Button onClick={handleClose}>
                                        <CloseIcon sx={{ color: "#000" }} />
                                    </Button>
                                </Box>
                                <Button
                                    variant="outlined"
                                    component="label"
                                    sx={{ p: "20px", my: "20px" }}
                                >
                                    {" "}
                                    <VisuallyHiddenInput type="file" /> <CloudUploadIcon />
                                    &nbsp;{" "}
                                    <Typography variant="body1" color={"#000"}>
                                        {" "}
                                        Upload from your PC
                                    </Typography>
                                </Button>
                                <Typography fontSize={"11px"}>
                                    Select Multiple Vidoes From Your Storage
                                </Typography>
                                <Typography fontSize={"11px"}>
                                    * Max. Upto 5Gb per video
                                </Typography>
                                <Typography
                                    mt={2}
                                    p={2}
                                    sx={{ backgroundColor: "#d7e3f5" }}
                                    fontSize={"10px"}
                                >
                                    Video restrication &#91;Decide the maximum numbers of viwes
                                    and/or the maximum view duration&#93; are available for
                                    classplus powered videos. Use our new video player for
                                    searnless video viewing experience.
                                </Typography>
                            </Box>
                        </Modal>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <EventNoteIcon color="primary" fontSize="small" /> &nbsp; Online
                            Test
                        </Button>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <EventNoteIcon color="primary" fontSize="small" /> &nbsp;
                            Subjective Test
                        </Button>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <FolderIcon color="primary" fontSize="small" /> &nbsp; Document
                        </Button>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <ImageIcon color="primary" fontSize="small" /> &nbsp; Image
                        </Button>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <SourceIcon color="primary" fontSize="small" /> &nbsp; Zip File
                        </Button>
                        <Button
                            variant="text"
                            onClick={handleOpen1}
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <DownloadForOfflineIcon color="primary" fontSize="small" /> &nbsp;
                            Import Content
                        </Button>
                        <Modal
                            open={open1}
                            onClose={handleClose1}
                            aria-labelledby="parent-modal-title"
                            aria-describedby="parent-modal-description"
                        >
                            <Box sx={{ ...style, width: "40%", height: "80%", p: "1" }}>
                                <Box
                                    display={"flex"}
                                    justifyContent={"space-between"}
                                    alignItems={"center"}
                                >
                                    <Typography>Import Content</Typography>
                                    <Button onClick={handleClose1}>
                                        <CloseIcon sx={{ color: "#000" }} />
                                    </Button>
                                </Box>
                                <Divider />
                                <Typography
                                    mt={2}
                                    p={2}
                                    sx={{
                                        backgroundColor: "#d7e3f5",
                                        fontWeight: "500",
                                        textAlign: "center",
                                    }}
                                    fontSize={"12px"}
                                >
                                    Select the entire course &#40;5 mix&#41; or any set of content
                                    you want to import from the list of available courses.
                                </Typography>
                                <Grid container p={1}>
                                    <Grid item xs={4}>
                                        <Typography fontSize={"10px"} fontWeight={500}>
                                            Selected &#40;0&#41;
                                        </Typography>
                                    </Grid>
                                    <Grid item xs={8}>
                                        <Typography sx={{ display: "flex", alignItems: "center" }}>
                                            <SearchIcon fontSize={"10px"} />{" "}
                                            <Input
                                                placeholder="Search your courses here"
                                                sx={{ border: "1px solid gray", fontSize: "10px" }}
                                            />
                                        </Typography>
                                    </Grid>
                                </Grid>
                                <Box
                                    mt={2}
                                    sx={{
                                        height: "55%",
                                        borderRadius: "20px",
                                        px: "2%",
                                        overflowY: "scroll",
                                        "&::-webkit-scrollbar": {
                                            width: "0.4em",
                                        },
                                        "&::-webkit-scrollbar-track": {
                                            "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                        },
                                        "&::-webkit-scrollbar-thumb": {
                                            backgroundColor: "rgba(0,0,0,.1)",
                                            borderRadius: "10px",
                                        },
                                    }}
                                >
                                    <Box
                                        sx={{
                                            "&:hover": { backgroundColor: "#ede9e8" },
                                            display: "flex",
                                        }}
                                    >
                                        <Checkbox {...label} />
                                        <Box
                                            onClick={handleOpena1}
                                            sx={{ display: "flex", alignItems: "center" }}
                                        >
                                            <FolderIcon color="primary" sx={{ fontSize: "60px" }} />
                                            <Box p={"10px"}>
                                                <Typography fontSize={"15px"}>
                                                    Rajasthan State Eligibility Test &#40;set&#41;
                                                    Mathematic
                                                </Typography>
                                                <Typography fontSize={"10px"}>
                                                    319 Videos, 233 Files, 3 Test
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Box>
                                    <Modal
                                        open={opena1}
                                        onClose={handleClosea1}
                                        aria-labelledby="parent-modal-title"
                                        aria-describedby="parent-modal-description"
                                    >
                                        <Box sx={{ ...style, width: "40%", height: "80%", p: "1" }}>
                                            <Box
                                                display={"flex"}
                                                justifyContent={"space-between"}
                                                alignItems={"center"}
                                            >
                                                <Typography>Import Content</Typography>
                                                <Button onClick={handleClosea1}>
                                                    <CloseIcon sx={{ color: "#000" }} />
                                                </Button>
                                            </Box>
                                            <Divider />
                                            <Typography
                                                mt={2}
                                                p={2}
                                                sx={{
                                                    backgroundColor: "#d7e3f5",
                                                    fontWeight: "500",
                                                    textAlign: "center",
                                                }}
                                                fontSize={"12px"}
                                            >
                                                Select the entire course &#40;5 mix&#41; or any set of
                                                content you want to import from the list of available
                                                courses.
                                            </Typography>
                                            <Typography fontSize={"10px"} p={1} fontWeight={500}>
                                                Selected &#40;0&#41;
                                            </Typography>
                                            <Box
                                                mt={2}
                                                sx={{
                                                    height: "55%",
                                                    borderRadius: "20px",
                                                    px: "2%",
                                                    overflowY: "scroll",
                                                    "&::-webkit-scrollbar": {
                                                        width: "0.4em",
                                                    },
                                                    "&::-webkit-scrollbar-track": {
                                                        "-webkit-box-shadow":
                                                            "inset 0 0 6px rgba(0,0,0,0.00)",
                                                    },
                                                    "&::-webkit-scrollbar-thumb": {
                                                        backgroundColor: "rgba(0,0,0,.1)",
                                                        borderRadius: "10px",
                                                    },
                                                }}
                                            >
                                                <Box
                                                    sx={{
                                                        "&:hover": { backgroundColor: "#ede9e8" },
                                                        display: "flex",
                                                    }}
                                                >
                                                    <Checkbox {...label} />
                                                    <Box
                                                        onClick={handleOpenaa1}
                                                        sx={{ display: "flex", alignItems: "center" }}
                                                    >
                                                        <FolderIcon
                                                            color="primary"
                                                            sx={{ fontSize: "40px" }}
                                                        />
                                                        <Typography fontSize={"13px"}>
                                                            UNIT-05 CURVE TRACING
                                                        </Typography>
                                                    </Box>
                                                </Box>
                                                <Modal
                                                    open={openaa1}
                                                    onClose={handleCloseaa1}
                                                    aria-labelledby="parent-modal-title"
                                                    aria-describedby="parent-modal-description"
                                                >
                                                    <Box
                                                        sx={{
                                                            ...style,
                                                            width: "40%",
                                                            height: "80%",
                                                            p: "1",
                                                        }}
                                                    >
                                                        <Box
                                                            display={"flex"}
                                                            justifyContent={"space-between"}
                                                            alignItems={"center"}
                                                        >
                                                            <Typography>Import Content</Typography>
                                                            <Button onClick={handleCloseaa1}>
                                                                <CloseIcon sx={{ color: "#000" }} />
                                                            </Button>
                                                        </Box>
                                                        <Divider />
                                                        <Typography
                                                            mt={2}
                                                            p={2}
                                                            sx={{
                                                                backgroundColor: "#d7e3f5",
                                                                fontWeight: "500",
                                                                textAlign: "center",
                                                            }}
                                                            fontSize={"12px"}
                                                        >
                                                            Select the entire course &#40;5 mix&#41; or any
                                                            set of content you want to import from the list of
                                                            available courses.
                                                        </Typography>
                                                        <Typography
                                                            fontSize={"10px"}
                                                            p={1}
                                                            fontWeight={500}
                                                        >
                                                            Selected &#40;0&#41;
                                                        </Typography>
                                                        <Box
                                                            mt={2}
                                                            sx={{
                                                                height: "55%",
                                                                borderRadius: "20px",
                                                                px: "2%",
                                                                overflowY: "scroll",
                                                                "&::-webkit-scrollbar": {
                                                                    width: "0.4em",
                                                                },
                                                                "&::-webkit-scrollbar-track": {
                                                                    "-webkit-box-shadow":
                                                                        "inset 0 0 6px rgba(0,0,0,0.00)",
                                                                },
                                                                "&::-webkit-scrollbar-thumb": {
                                                                    backgroundColor: "rgba(0,0,0,.1)",
                                                                    borderRadius: "10px",
                                                                },
                                                            }}
                                                        >
                                                            <Box
                                                                sx={{
                                                                    "&:hover": { backgroundColor: "#ede9e8" },
                                                                    display: "flex",
                                                                }}
                                                            >
                                                                <Checkbox {...label} />
                                                                <Box
                                                                    sx={{ display: "flex", alignItems: "center" }}
                                                                >
                                                                    <FolderIcon
                                                                        color="primary"
                                                                        sx={{ fontSize: "40px" }}
                                                                    />
                                                                    <Box p={"10px"}>
                                                                        <Typography fontSize={"13px"}>
                                                                            Video Lectures
                                                                        </Typography>
                                                                        <Typography fontSize={"8px"}>
                                                                            3 Videos
                                                                        </Typography>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                            <Divider />
                                                            <Box
                                                                sx={{
                                                                    "&:hover": { backgroundColor: "#ede9e8" },
                                                                    display: "flex",
                                                                }}
                                                            >
                                                                <Checkbox {...label} />
                                                                <Box
                                                                    sx={{ display: "flex", alignItems: "center" }}
                                                                >
                                                                    <FolderIcon
                                                                        color="primary"
                                                                        sx={{ fontSize: "40px" }}
                                                                    />
                                                                    <Box p={"10px"}>
                                                                        <Typography fontSize={"13px"}>
                                                                            Video Lectures
                                                                        </Typography>
                                                                        <Typography fontSize={"8px"}>
                                                                            3 Videos
                                                                        </Typography>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                            <Divider />
                                                            <Box
                                                                sx={{
                                                                    "&:hover": { backgroundColor: "#ede9e8" },
                                                                    display: "flex",
                                                                }}
                                                            >
                                                                <Checkbox {...label} />
                                                                <Box
                                                                    sx={{ display: "flex", alignItems: "center" }}
                                                                >
                                                                    <FolderIcon
                                                                        color="primary"
                                                                        sx={{ fontSize: "40px" }}
                                                                    />
                                                                    <Box p={"10px"}>
                                                                        <Typography fontSize={"13px"}>
                                                                            Video Lectures
                                                                        </Typography>
                                                                        <Typography fontSize={"8px"}>
                                                                            3 Videos
                                                                        </Typography>
                                                                    </Box>
                                                                </Box>
                                                            </Box>
                                                        </Box>
                                                        <Divider />
                                                        <Box
                                                            sx={{
                                                                display: "flex",
                                                                justifyContent: "end",
                                                                mt: "10px",
                                                            }}
                                                        >
                                                            <Button size="small">Cancel</Button>
                                                            <Button
                                                                size="small"
                                                                variant="contained"
                                                                sx={{ textTransform: "none" }}
                                                            >
                                                                Import Selected
                                                            </Button>
                                                        </Box>
                                                    </Box>
                                                </Modal>
                                                <Divider />
                                            </Box>
                                            <Divider />
                                            <Box
                                                sx={{
                                                    display: "flex",
                                                    justifyContent: "end",
                                                    mt: "10px",
                                                }}
                                            >
                                                <Button size="small">Cancel</Button>
                                                <Button
                                                    size="small"
                                                    variant="contained"
                                                    sx={{ textTransform: "none" }}
                                                >
                                                    Import Selected
                                                </Button>
                                            </Box>
                                        </Box>
                                    </Modal>
                                    <Divider />
                                </Box>
                                <Divider />
                                <Box
                                    sx={{ display: "flex", justifyContent: "end", mt: "10px" }}
                                >
                                    <Button size="small">Cancel</Button>
                                    <Button
                                        size="small"
                                        variant="contained"
                                        sx={{ textTransform: "none" }}
                                    >
                                        Import Selected
                                    </Button>
                                </Box>
                            </Box>
                        </Modal>
                        <Button
                            variant="text"
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                my: "5px",
                                color: "#000",
                            }}
                        >
                            <DownloadForOfflineIcon color="primary" fontSize="small" /> &nbsp;
                            Import Live
                        </Button>
                    </Paper>
                </Grid>
            </Grid>
        </>
    );

    const StepFourForm = () => (
        <Typography>bdhfbdhbfkafna mnd dbfkh kfbdjhewbkjfh </Typography>
    );

    const steps = ["Basic Information", "Edit Price", " Add Content", "Bundle"];
    const [activeStep, setActiveStep] = React.useState(0);
    const [skipped, setSkipped] = React.useState(new Set());

    const isStepOptional = (step) => {
        return step === 1 || step === 3;
    };

    const isStepSkipped = (step) => {
        return skipped.has(step);
    };

    const handleNext = () => {
        let newSkipped = skipped;
        if (isStepSkipped(activeStep)) {
            newSkipped = new Set(newSkipped.values());
            newSkipped.delete(activeStep);
        }

        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        setSkipped(newSkipped);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleSkip = () => {
        if (!isStepOptional(activeStep)) {
            throw new Error("You can't skip a step that isn't optional.");
        }

        setActiveStep((prevActiveStep) => prevActiveStep + 1);
        setSkipped((prevSkipped) => {
            const newSkipped = new Set(prevSkipped.values());
            newSkipped.add(activeStep);
            return newSkipped;
        });
    };

    const handleReset = () => {
        setActiveStep(0);
    };

    const renderStepForm = (step) => {
        switch (step) {
            case 0:
                return (
                    <Box>
                        <StepOneForm />
                    </Box>
                );
            case 1:
                return (
                    <Box>
                        <StepTwoForm />
                    </Box>
                );
            case 2:
                return (
                    <Box>
                        <StepThreeForm />
                    </Box>
                );
            case 3:
                return (
                    <Box>
                        <StepFourForm />
                    </Box>
                );
            default:
                return null;
        }
    };

    return (
        <>
            <FolderModel
                open={dialogOpen}
                onClose={() => setDialogOpen(false)}
                FolderData={FolderData}
                allFolder={allFolder}
                makefolder={makefolder}
                foldersubmit={foldersubmit}
            />
            <Grid container>
                <Grid item xs={12}>
                    <Navbar
                        title=" Your Courses(157) "
                        desc=" Add/View Courses of your brand "
                        progressNum={78}
                    />
                </Grid>

                <Grid container mt={0} spacing={2} position={"relative"}>
                    <Grid item xs={12}>
                        <Paper
                            elevation={0}
                            sx={{
                                borderRadius: "20px",
                                padding: "25px",
                                height: "70vh",
                                overflow: "overlay",
                                "&::-webkit-scrollbar": { display: "none" },
                            }}
                        >
                            <Box sx={{ width: "100%" }}>
                                <Stepper activeStep={activeStep}>
                                    {steps.map((label, index) => {
                                        const stepProps = {};
                                        const labelProps = {};
                                        if (isStepOptional(index)) {
                                            labelProps.optional = (
                                                <Typography variant="caption">Optional</Typography>
                                            );
                                        }
                                        if (isStepSkipped(index)) {
                                            stepProps.completed = false;
                                        }
                                        return (
                                            <Step key={label} {...stepProps}>
                                                <StepLabel {...labelProps}>{label}</StepLabel>
                                            </Step>
                                        );
                                    })}
                                </Stepper>
                                {renderStepForm(activeStep)}
                                {activeStep === steps.length ? (
                                    <React.Fragment>
                                        <Typography sx={{ mt: 2, mb: 1 }}>
                                            All steps completed - you&apos;re finished
                                        </Typography>
                                        <Box
                                            sx={{ display: "flex", flexDirection: "row", pt: 2 }}
                                        >
                                            <Box sx={{ flex: "1 1 auto" }} />
                                            <Button onClick={handleReset}>Reset</Button>
                                        </Box>
                                    </React.Fragment>
                                ) : (
                                    <React.Fragment>
                                        <Box
                                            sx={{ display: "flex", flexDirection: "row", pt: 2 }}
                                        >
                                            <Box sx={{ flex: "1 1 auto" }} />
                                            {isStepOptional(activeStep) && (
                                                <Button
                                                    color="inherit"
                                                    onClick={handleSkip}
                                                    sx={{ mr: 1 }}
                                                >
                                                    Skip
                                                </Button>
                                            )}
                                        </Box>
                                    </React.Fragment>
                                )}
                            </Box>
                        </Paper>
                    </Grid>
                    <Grid
                        item
                        xs={12}
                        sx={{ position: "sticky", bottom: "0px", width: "100%" }}
                    >
                        <Paper
                            sx={{
                                padding: "10px",
                                borderRadius: "20px",
                                display: "flex",
                                justifyContent: "space-between",
                            }}
                        >
                            {" "}
                            <Button
                                variant="outlined"
                                color="inherit"
                                disabled={activeStep === 0}
                                onClick={handleBack}
                                sx={{
                                    border: "1px solid #63BEEA",
                                    textTransform: "none",
                                    borderRadius: "10px",
                                    height: "50px",
                                    color: "#63BEEA",
                                    mr: 1,
                                }}
                            >
                                <FaArrowLeft /> Previous
                            </Button>
                            <Box sx={{ display: "flex", alignItems: "center" }}>
                                <Typography sx={{ fontSize: "11px" }}>
                                    <Checkbox
                                        checked={checked}
                                        onChange={handleChangecheck}
                                        inputProps={{ "aria-label": "controlled" }}
                                        sx={{ fontSize: "11px" }}
                                    />
                                    I have read and agree to <Link href="#">the T&C</Link>
                                </Typography>
                                <Button
                                    onClick={handleNext}
                                    variant="standard"
                                    color="inherit"
                                    sx={{
                                        border: "1px solid #CDEAE9",
                                        textTransform: "none",
                                        borderRadius: "10px",
                                        height: "50px",
                                        background: "#63BEEA",
                                        color: "white",
                                        mr: 1,
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "space-between",
                                        marginLeft: "5px",
                                    }}
                                >
                                    {activeStep === steps.length - 1
                                        ? "Finish"
                                        : "Edit Price"}
                                    <ArrowForwardIcon />
                                </Button>
                            </Box>
                        </Paper>
                    </Grid>{" "}
                </Grid>
            </Grid>

        </>
    );
};