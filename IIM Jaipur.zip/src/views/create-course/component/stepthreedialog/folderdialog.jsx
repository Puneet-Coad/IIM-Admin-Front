import React from 'react'
import { Box, Button, Dialog, DialogActions, DialogTitle, FormControl, Grid, TextField } from '@mui/material'

export default function Folderdialog({ open, onClose, FolderData, makefolder, foldersubmit }) {

    return (
        <Box>
            <Dialog
                open={open}
                onClose={() => onClose()}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth='sm'
                fullWidth="sm"
            >
                <DialogTitle id="alert-dialog-title">
                    {"New Folder"}
                </DialogTitle>
                <Box px={2}>
                    <Grid container spacing={2}>
                        <Grid item xs={12}>
                            <FormControl fullWidth>

                                <TextField
                                    value={FolderData?.foldername}
                                    onChange={(e) => makefolder(e)}
                                    autoFocus
                                    required
                                    id="foldername"
                                    name="foldername"
                                    label="Folder Name"
                                    type="text"
                                    variant="outlined"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <FormControl fullWidth>
                                <TextField
                                    onChange={(e) => makefolder(e)}
                                    value={FolderData.description}
                                    autoFocus
                                    required
                                    id="description"
                                    name="description"
                                    label="Description"
                                    type="text"
                                    variant="outlined"
                                />
                            </FormControl>
                        </Grid>
                        <Grid item xs={12}>
                            <DialogActions>
                                <Button onClick={() => onClose()}>Cancel</Button>
                                <Button onClick={() => foldersubmit()}>Create</Button>
                            </DialogActions>
                        </Grid>
                    </Grid>
                </Box>
            </Dialog>
        </Box>
    )
}