import React from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { FaRegClock } from "react-icons/fa6";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import { CiMenuKebab } from "react-icons/ci";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Fade from "@mui/material/Fade";
import Divider from "@mui/material/Divider";
import Sidebar from "../../components/sidebar";
import Navbar from "../../comon/navbar/navbar";

const ManageCoupons = () => {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
    
          <Grid container>
            <Grid item xs={12}>
              <Navbar
                title=" Your Courses(157) "
                desc=" Add/View Courses of your brand "
                progressNum={78}
              />
            </Grid>

            <Grid container mt={0} spacing={2} position={"relative"}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    margin: "10px auto",
                  }}
                >
                  {" "}
                  <Typography fontWeight={500} fontSize={20}>
                    Coupon Codes
                  </Typography>
                  <Button
                    sx={{
                      background: "#059FE3",
                      padding: "10px",
                      borderRadius: "10px",
                      color: "white",

                      textTransform: "none",
                      "&:hover": {
                        background: "#007bb5", // Change background color on hover
                        textDecoration: "none", // Remove any default hover effects
                      },
                    }}
                  >
                    Create Coupon
                  </Button>
                </Box>
                <Divider sx={{ margin: "20px auto" }} />
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "space-between",
                    height: "60px",
                    alignItems: "center",
                    background: "#E8F4FC",
                    borderRadius: "12px",
                    margin: "12px auto",
                    border: "2px solid #A7F2EF",
                    padding: "0px 15px",
                    fontSize: "20px",
                  }}
                >
                  <Typography sx={{ fontWeight: "600", fontSize: "15px" }}>
                    You can avail coupons to your students and increase the
                    sales of your courses
                    <span
                      style={{
                        color: "#19ACE7",
                        fontWeight: "600",
                        textDecoration: "underline",
                      }}
                    >
                      Learn More{" "}
                    </span>
                  </Typography>
                </Box>
                <Box>
                  <Typography sx={{ fontWeight: "500", margin: "10px auto" }}>
                    Your Coupon List (1)
                  </Typography>
                </Box>

                <Paper
                  elevation={0}
                  sx={{
                    padding: "5px",
                    maxHeight: "58vh",
                    overflow: "overlay",
                    "&::-webkit-scrollbar": { display: "none" },
                  }}
                >
                  <Grid container>
                    <Grid item xs={2}>
                      <Box sx={{ textAlign: "center", padding: "10px" }}>
                        <Typography
                          variant="subtitle2"
                          fontWeight={600}
                          gutterBottom
                        >
                          20% OFF
                        </Typography>
                        <Typography
                          variant="caption"
                          display="block"
                          gutterBottom
                          sx={{ fontSize: "10px" }}
                        >
                          up to ₹4,000
                        </Typography>
                        <Box
                          sx={{
                            background: "#FAF5EE",
                            border: "2px dotted #ffd6a4",
                            padding: "8px",
                            textAlign: "center",
                            fontWeight: "600",
                            fontSize: "14px",
                          }}
                        >
                          SHREERAM
                        </Box>
                      </Box>
                    </Grid>

                    <Grid item xs={0.1}>
                      <Divider orientation="vertical" />
                    </Grid>
                    <Grid item xs={7}>
                      <Box sx={{ padding: "10px" }}>
                        <Typography
                          variant="subtitle2"
                          fontWeight={600}
                          gutterBottom
                        >
                          JAI SHREE RAM
                        </Typography>
                        <Typography
                          variant="caption"
                          display="block"
                          gutterBottom
                          sx={{ fontSize: "10px" }}
                        >
                          Created by IIM Jaipur{" "}
                          <span
                            style={{
                              color: "#19ACE7",
                              fontWeight: "600",
                              marginLeft: "10px",
                            }}
                          >
                            Public Coupon{" "}
                          </span>
                        </Typography>
                        <Typography
                          variant="caption"
                          display="block"
                          gutterBottom
                          sx={{
                            fontSize: "10px",
                            display: "flex",
                            alignItems: "center",
                            marginTop: "20px",
                          }}
                        >
                          <FaRegClock />
                          2024/01/22,11:31 am-2024/01/22,11:59 pm
                          <Divider
                            orientation="vertical"
                            sx={{
                              width: "1px",
                              height: "15px",
                              marginLeft: "13px",
                            }}
                          />
                          <span
                            style={{
                              color: "#19ACE7",
                              fontWeight: "600",
                              marginLeft: "10px",
                            }}
                          >
                            Used 35 times{" "}
                          </span>
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid item xs={2.9}>
                      <Box sx={{ padding: "10px", textAlign:"right" }}>
                        <Button
                          variant="contained"
                          sx={{
                            background: "#FC2E4D",
                            fontSize: "10px",

                            "&:hover": {
                              background: "#FC2E4D",
                            },
                          }}
                        >
                          Expired
                        </Button>
                        <Button
                          id="fade-button"
                          aria-controls={open ? "fade-menu" : undefined}
                          aria-haspopup="true"
                          aria-expanded={open ? "true" : undefined}
                          onClick={handleClick}
                          sx={{minWidth:"0px"}}
                        >
                          <CiMenuKebab />
                        </Button>
                        <Menu
                          id="fade-menu"
                          MenuListProps={{
                            "aria-labelledby": "fade-button",
                          }}
                          anchorEl={anchorEl}
                          open={open}
                          onClose={handleClose}
                          TransitionComponent={Fade}
                        >
                          <MenuItem onClick={handleClose}>Profile</MenuItem>
                          <MenuItem onClick={handleClose}>My account</MenuItem>
                          <MenuItem onClick={handleClose}>Logout</MenuItem>
                        </Menu>
                        <Typography
                          variant="caption"
                          display="block"
                          gutterBottom
                          sx={{
                            fontSize: "10px",
                            marginTop: "20px",
                          }}
                        >
                          <span
                            style={{
                              color: "#19ACE7",
                              fontWeight: "600",
                              marginLeft: "10px",
                              padding:"13px"
                            }}
                          >
                            Show Details{" "}
                          </span>
                        </Typography>
                      </Box>
                    </Grid>
                  </Grid>
              
                </Paper>
              </Grid>
              <Grid
                item
                xs={12}
                sx={{ position: "sticky", bottom: "0px", width: "100%" }}
              >
                {/* <Paper
                  sx={{
                    padding: "10px",
                    borderRadius: "20px",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <Button
                    variant="outlined"
                    color="inherit"
                    disabled={activeStep === 0}
                    onClick={handleBack}
                    sx={{
                      border: "1px solid #63BEEA",
                      textTransform: "none",
                      borderRadius: "10px",
                      height: "50px",
                      color: "#63BEEA",
                      mr: 1,
                    }}
                  >
                    <FaArrowLeft /> Previous
                  </Button>
                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Typography sx={{ fontSize: "11px" }}>
                      <Checkbox
                        checked={checked}
                        onChange={handleChangecheck}
                        inputProps={{ "aria-label": "controlled" }}
                        sx={{ fontSize: "11px" }}
                      />
                      I have read and agree to <Link href="#">the T&C</Link>
                    </Typography>
                  </Box>
                </Paper> */}
              </Grid>{" "}
            </Grid>
          </Grid>
       
    </>
  );
};

export default ManageCoupons;
