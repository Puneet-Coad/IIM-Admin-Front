import React, { useState } from "react";
import {
  Grid,
  Box,
  IconButton,
  Card,
  CardContent,
  CardMedia,
  Typography,
  CardActionArea,
  Button,
  InputBase,
  styled,
  FormControl,
  NativeSelect,
} from "@mui/material";
import Navbar from "../../comon/navbar/navbar";
import SearchIcon from "@mui/icons-material/Search";
 import { Link } from 'react-router-dom';
import { FaRegStar } from "react-icons/fa";
import course1admin from "../../assets/course1 img.jpg";
import course2admin from "../../assets/course2.png";
import course3admin from "../../assets/admincourse3.jpeg";
import course4admin from "../../assets/admincourse4.jpeg";
import Filtersidedrawer from "./component/filter-drawer";


const Course = () => {
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const [age, setAge] = React.useState("");
  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const BootstrapInput = styled(InputBase)(({ theme }) => ({
    "& .MuiInputBase-input": {
      borderRadius: 4,
      backgroundColor: theme.palette.background.paper,
      border: "1px solid #ced4da",
      fontSize: 16,
      padding: "10px 26px 10px 12px",
      transition: theme.transitions.create(["border-color", "box-shadow"]),
      fontFamily: [
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(","),
      "&:focus": {
        borderRadius: 4,
        borderColor: "#80bdff",
        boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
      },
    },
  }));
  const [searchQuery, setSearchQuery] = useState("");

  const handleSearch = () => {
    console.log("Search query:", searchQuery);
  };

  const handleChange1 = (event) => {
    setSearchQuery(event.target.value);
  };

  return (
    <>
       
          <Grid container>
            <Grid item xs={12}>
              <Navbar
                title=" Your Courses(157) "
                desc=" Add/View Courses of your brand "
                progressNum={78}
              />
            </Grid>
            <Grid
              container
              sx={{ justifyContent: "space-between", alignItems: "center" }}
              mt={4}
            >
              <Grid item xs={7}>
                <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                  <Box>
                    <Box
                      component="form"
                      sx={{
                        p: "2px 4px",
                        display: "flex",
                        alignItems: "center",
                        width: "350px",
                        borderRadius: "16px",
                        border: "1px solid #b4b4b4",
                        background: "white",
                        height: "42px",
                      }}
                    >
                      <IconButton
                        type="button"
                        sx={{ p: "10px" }}
                        aria-label="search"
                        onClick={handleSearch}
                      >
                        <SearchIcon />
                      </IconButton>
                      <InputBase
                        sx={{ ml: 1, flex: 1 }}
                        placeholder="Search by name"
                        inputProps={{ "aria-label": "search google maps" }}
                        onChange={handleChange1}
                        value={searchQuery}
                      />
                    </Box>
                  </Box>
                  <Box>
                    <FormControl variant="standard">
                      <NativeSelect
                        id="demo-customized-select-native"
                        value={age}
                        onChange={handleChange}
                        input={<BootstrapInput />}
                      >
                        <option aria-label="None" value="">
                          Sort By{" "}
                        </option>
                        <option value={10}>Ten</option>
                        <option value={20}>Twenty</option>
                        <option value={30}>Thirty</option>
                      </NativeSelect>
                    </FormControl>
                  </Box>
                  <Box>
                    <Filtersidedrawer />
                  </Box>
                </Box>
              </Grid>
              <Grid item xs={5}>
                <Box
                  sx={{
                    width: '100%',
                    display: 'flex',
                    alignItems: 'flex-end',
                    justifyContent: 'flex-end'
                  }}>
                  <Button
                    sx={{
                      background: "white",
                      padding: "10px",
                      borderRadius: "10px",
                      color: "#059FE3",
                      border: "1px solid #059FE3",
                      marginRight: "10px",
                    }}
                  >
                    <FaRegStar />
                    Featured
                  </Button>
                  <Button
                    sx={{
                      background: "#059FE3",
                      padding: "10px",
                      borderRadius: "10px",
                      color: "white",
                      "&:hover": {
                        background: "#007bb5",
                        textDecoration: "none",
                      },
                    }}
                  >
                    Create Courses
                  </Button>
                </Box>
              </Grid>
            </Grid>
            <Grid container mt={4} spacing={2}>
              <Grid item xs={3}>
                <Link to="/course-detail">

                  <Card
                    sx={{
                      maxWidth: "100%",
                      borderRadius: "20px",

                    }}
                  >
                    <CardActionArea>
                      <Box>
                        <CardMedia
                          component="img"
                          height="180"
                          img
                          src={course1admin}
                          alt="green iguana"
                          sx={{ objectFit: "cover", position: "relative" }}
                        />
                        <Typography
                          sx={{
                            background: "#727A85",
                            width: "60%",
                            borderRadius: "10px",
                            borderTopLeftRadius: "0px",
                            borderBottomLeftRadius: "0px",
                            fontSize: "14px",
                            color: "white",
                            padding: "3px 5px 3px 5px",
                            fontWeight: "500",
                            position: "absolute",
                            top: 12,
                          }}
                        >
                          Unpublished Course
                        </Typography>
                      </Box>

                      <CardContent>
                        <Typography
                          gutterBottom
                          sx={{ fontSize: "12px", fontWeight: "600" }}
                        >
                          Rajasthan State Eligibility Test(SET)Mathematics
                        </Typography>
                        <Typography
                          color="text.secondary"
                          sx={{ fontSize: "12px", fontWeight: "500" }}
                        >
                          Created by:You(Owner)
                        </Typography>
                        <Button
                          sx={{
                            background: "#D8EAF2",
                            fontSize: "10px",
                            textTransform: "none",
                            padding: "1px",
                            fontWeight: "600",
                            margin: "10px auto",
                          }}
                        >
                          1 Year
                        </Button>
                        <Typography
                          mt={4}
                          sx={{ fontWeight: "700", fontSize: "15px" }}
                        >
                          ₹14160
                        </Typography>
                      </CardContent>
                    </CardActionArea>
                  </Card>
                </Link>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course2admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#727A85",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        Unpublished Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        Kendriya Vidhyalya TGT Exam{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹4720
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course3admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        IIT Jam 2024{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹11210
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course4admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        RPSC First Grade (Hindi Medium) Mathematics teacher-2022{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹6500
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course3admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        RPSC First Grade (Hindi Medium) Mathematics teacher-2022{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹6500
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course3admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        RPSC First Grade (Hindi Medium) Mathematics teacher-2022{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹6500
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course4admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        RPSC First Grade (Hindi Medium) Mathematics teacher-2022{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹6500
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
              <Grid item xs={3}>
                <Card
                  sx={{
                    maxWidth: "100%",
                    borderRadius: "20px",

                  }}
                >
                  <CardActionArea>
                    <Box>
                      <CardMedia
                        component="img"
                        height="180"
                        img
                        src={course1admin}
                        alt="green iguana"
                        sx={{ objectFit: "cover", position: "relative" }}
                      />
                      <Typography
                        sx={{
                          background: "#FFA700",
                          width: "60%",
                          borderRadius: "10px",
                          borderTopLeftRadius: "0px",
                          borderBottomLeftRadius: "0px",
                          fontSize: "14px",
                          color: "white",
                          padding: "3px 5px 3px 5px",
                          fontWeight: "500",
                          position: "absolute",
                          top: 12,
                        }}
                      >
                        <FaRegStar />
                        Featured Course
                      </Typography>
                    </Box>

                    <CardContent>
                      <Typography
                        gutterBottom
                        sx={{ fontSize: "12px", fontWeight: "600" }}
                      >
                        RPSC First Grade (Hindi Medium) Mathematics teacher-2022{" "}
                      </Typography>
                      <Typography
                        color="text.secondary"
                        sx={{ fontSize: "12px", fontWeight: "500" }}
                      >
                        Created by:You(Owner)
                      </Typography>
                      <Button
                        sx={{
                          background: "#D8EAF2",
                          fontSize: "10px",
                          textTransform: "none",
                          padding: "1px",
                          fontWeight: "600",
                          margin: "10px auto",
                        }}
                      >
                        1 Year
                      </Button>
                      <Typography
                        mt={4}
                        sx={{ fontWeight: "700", fontSize: "15px" }}
                      >
                        ₹6500
                      </Typography>
                    </CardContent>
                  </CardActionArea>
                </Card>
              </Grid>
            </Grid>
          </Grid>
         
    </>
  );
};

export default Course;
