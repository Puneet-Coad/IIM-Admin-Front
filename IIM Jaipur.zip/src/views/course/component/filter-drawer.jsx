import React, { useState } from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import Paper from '@mui/material/Paper';
import Divider from "@mui/material/Divider";
import { styled } from "@mui/material/styles";
import { Input as BaseInput } from "@mui/base/Input";

import OutlinedInput from "@mui/material/OutlinedInput";
import ListItemText from "@mui/material/ListItemText";
import Checkbox from "@mui/material/Checkbox";
import InputLabel from "@mui/material/InputLabel";

import Switch from "@mui/material/Switch";
import { MdOutlineFilterAlt } from "react-icons/md";

import FormControlLabel from "@mui/material/FormControlLabel";
import CloseIcon from "@mui/icons-material/Close";
import {
    FormControl,
    MenuItem,
    Radio,
    RadioGroup,
    Select,
    Typography,
} from "@mui/material";

const Filtersidedrawer = () => {
    const IOSSwitch = styled((props) => (
        <Switch
            focusVisibleClassName=".Mui-focusVisible"
            disableRipple
            {...props}
        />
    ))(({ theme }) => ({
        width: 42,
        height: 26,
        padding: 0,
        "& .MuiSwitch-switchBase": {
            padding: 0,
            margin: 2,
            transitionDuration: "300ms",
            "&.Mui-checked": {
                transform: "translateX(16px)",
                color: "#fff",
                "& + .MuiSwitch-track": {
                    backgroundColor:
                        theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
                    opacity: 1,
                    border: 0,
                },
                "&.Mui-disabled + .MuiSwitch-track": {
                    opacity: 0.5,
                },
            },
            "&.Mui-focusVisible .MuiSwitch-thumb": {
                color: "#33cf4d",
                border: "6px solid #fff",
            },
            "&.Mui-disabled .MuiSwitch-thumb": {
                color:
                    theme.palette.mode === "light"
                        ? theme.palette.grey[100]
                        : theme.palette.grey[600],
            },
            "&.Mui-disabled + .MuiSwitch-track": {
                opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
            },
        },
        "& .MuiSwitch-thumb": {
            boxSizing: "border-box",
            width: 22,
            height: 22,
        },
        "& .MuiSwitch-track": {
            borderRadius: 26 / 2,
            backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
            opacity: 1,
            transition: theme.transitions.create(["background-color"], {
                duration: 500,
            }),
        },
    }));

    const [open, setOpen] = React.useState(false);

    const toggleDrawer = (openState) => (event) => {
        if (
            event &&
            event.type === "keydown" &&
            (event.key === "Tab" || event.key === "Shift")
        ) {
            return;
        }

        setOpen(openState);
    };

    const [age, setAge] = React.useState("");

    const handleChange = (event) => {
        setAge(event.target.value);
    };

    const BpIcon = styled("span")(({ theme }) => ({
        borderRadius: "50%",
        width: 16,
        height: 16,
        boxShadow:
            theme.palette.mode === "dark"
                ? "0 0 0 1px rgb(16 22 26 / 40%)"
                : "inset 0 0 0 1px rgba(16,22,26,.2), inset 0 -1px 0 rgba(16,22,26,.1)",
        backgroundColor: theme.palette.mode === "dark" ? "#394b59" : "#f5f8fa",
        backgroundImage:
            theme.palette.mode === "dark"
                ? "linear-gradient(180deg,hsla(0,0%,100%,.05),hsla(0,0%,100%,0))"
                : "linear-gradient(180deg,hsla(0,0%,100%,.8),hsla(0,0%,100%,0))",
        ".Mui-focusVisible &": {
            outline: "2px auto rgba(19,124,189,.6)",
            outlineOffset: 2,
        },
        "input:hover ~ &": {
            backgroundColor: theme.palette.mode === "dark" ? "#30404d" : "#ebf1f5",
        },
        "input:disabled ~ &": {
            boxShadow: "none",
            background:
                theme.palette.mode === "dark"
                    ? "rgba(57,75,89,.5)"
                    : "rgba(206,217,224,.5)",
        },
    }));

    const InputElement = styled("input")(
        ({ theme }) => `
        width: 100%;
        font-family: 'IBM Plex Sans', sans-serif;
        font-size: 0.875rem;
        font-weight: 400;
        line-height: 1.5;
        padding: 8px 12px;
        border-radius: 8px;
        color: ${theme.palette.mode === "dark" ? grey[300] : grey[900]};
        background: ${theme.palette.mode === "dark" ? grey[900] : "#fff"};
        border: 1px solid ${theme.palette.mode === "dark" ? grey[700] : grey[200]
            };
        box-shadow: 0px 2px 2px ${theme.palette.mode === "dark" ? grey[900] : grey[50]
            };

        &:hover {
          border-color: ${blue[400]};
        }

        &:focus {
          border-color: ${blue[400]};
          box-shadow: 0 0 0 3px ${theme.palette.mode === "dark" ? blue[600] : blue[200]
            };
        }

        // firefox
        &:focus-visible {
          outline: 0;
        }
      `
    );

    const Input = React.forwardRef(function CustomInput(props, ref) {
        return <BaseInput slots={{ input: InputElement }} {...props} ref={ref} />;
    });

    const blue = {
        100: "#DAECFF",
        200: "#80BFFF",
        400: "#3399FF",
        500: "#007FFF",
        600: "#0072E5",
    };

    const grey = {
        50: "#F3F6F9",
        100: "#E5EAF2",
        200: "#DAE2ED",
        300: "#C7D0DD",
        400: "#B0B8C4",
        500: "#9DA8B7",
        600: "#6B7A90",
        700: "#434D5B",
        800: "#303740",
        900: "#1C2025",
    };

    function BpRadio(props) {
        return (
            <Radio
                disableRipple
                color="default"
                checkedIcon={<BpCheckedIcon />}
                icon={<BpIcon />}
                {...props}
            />
        );
    }

    const BpCheckedIcon = styled(BpIcon)({
        backgroundColor: "#137cbd",
        backgroundImage:
            "linear-gradient(180deg,hsla(0,0%,100%,.1),hsla(0,0%,100%,0))",
        "&::before": {
            display: "block",
            width: 16,
            height: 16,
            backgroundImage: "radial-gradient(#fff,#fff 28%,transparent 32%)",
            content: '""',
        },
        "input:hover ~ &": {
            backgroundColor: "#106ba3",
        },
    });

    const ITEM_HEIGHT = 48;
    const ITEM_PADDING_TOP = 8;
    const MenuProps = {
        PaperProps: {
            style: {
                maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
                width: 250,
            },
        },
    };

    const names = [
        "Oliver Hansen",
        "Van Henry",
        "April Tucker",
        "Ralph Hubbard",
        "Omar Alexander",
        "Carlos Abbott",
        "Miriam Wagner",
        "Bradley Wilkerson",
        "Virginia Andrews",
        "Kelly Snyder",
    ];

    const [personName, setPersonName] = React.useState([]);

    const handleChangeCoursestatus = (event) => {
        const {
            target: { value },
        } = event;
        setPersonName(typeof value === "string" ? value.split(",") : value);
    };

    return (
        <div>
            <Button
                onClick={toggleDrawer(true)}
                component="label"
                role={undefined}
                tabIndex={-1}
                sx={{
                    width: "100%",
                    background: "white",
                    textAlign: "center",
                    borderRadius: "16px",
                    padding: "10px",
                    color: "black",
                    textTransform: "none",
                    border: "1px solid #b4b4b4",
                    height: "40px",
                }}
            >
                <MdOutlineFilterAlt />
                Filter
            </Button>

            <Drawer
                anchor="right"
                open={open}
                onClose={toggleDrawer(false)}
                sx={{
                    ".MuiPaper-root.MuiPaper-elevation.MuiPaper-elevation16.MuiDrawer-paper.MuiDrawer-paperAnchorRight.css-1160xiw-MuiPaper-root-MuiDrawer-paper":
                    {
                        borderRadius: "20px",
                        boxShadow:
                            "rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px;",
                    },
                }}
            >
                <Box sx={{ height: "730px", position: "relative" }}>
                    <Box
                        sx={{ width: 500, borderRadius: "20px" }}
                        role="presentation"
                        onClick={(event) => event.stopPropagation()}
                        onKeyDown={toggleDrawer(false)}
                    >
                        <Box
                            sx={{
                                display: "flex",
                                alignItems: "center",
                                padding: "10px",
                                height: "50px",
                                justifyContent: "space-between",
                            }}
                        >
                            <Typography sx={{ fontWeight: "600", fontSize: "23px" }}>
                                Filter
                            </Typography>
                            <Button onClick={toggleDrawer(false)}>
                                <CloseIcon />
                            </Button>
                        </Box>
                        <Divider />

                        <Box sx={{ padding: "20px" }}>
                            <Box
                                sx={{
                                    width: "95%",
                                    background: "#F3F6FD",
                                    padding: "15px",
                                    borderRadius: "10px",
                                    margin: "10px auto",
                                }}
                            >
                                <Typography fontWeight={"600"} mb={2}>
                                    Select Categories/Sub-categories
                                </Typography>
                                <FormControl
                                    fullWidth
                                    sx={{ bgcolor: "white", borderRadius: "10px" }}
                                >
                                    <Select
                                        sx={{ borderRadius: "17px" }}
                                        id="demo-simple-select"
                                        value={age}
                                        onChange={handleChange}
                                        displayEmpty
                                        inputProps={{ "aria-label": "Select age" }}
                                        renderValue={(selected) => {
                                            if (!selected) {
                                                return (
                                                    <Typography sx={{ color: "lightgray" }}>
                                                        Select Categories / Sub Categories
                                                    </Typography>
                                                );
                                            }
                                            return selected;
                                        }}
                                    >
                                        <MenuItem value="" disabled></MenuItem>
                                        <MenuItem value={10}>Ten</MenuItem>
                                        <MenuItem value={20}>Twenty</MenuItem>
                                        <MenuItem value={30}>Thirty</MenuItem>
                                    </Select>
                                </FormControl>
                            </Box>
                            <Box
                                sx={{
                                    background: "#F3F6FD",
                                    padding: "10px 20px",
                                    borderRadius: "10px",
                                    margin: "15px auto",
                                }}
                            >
                                <Typography fontWeight={"600"} mb={2}>
                                    Course Type
                                </Typography>
                                <FormControl fullWidth>
                                    <RadioGroup
                                        defaultValue=""
                                        aria-labelledby="demo-customized-radios"
                                        name="customized-radios"
                                    >
                                        <FormControlLabel
                                            value="female"
                                            control={<BpRadio />}
                                            label="Created by me"
                                        />
                                        <FormControlLabel
                                            value="male"
                                            control={<BpRadio />}
                                            label="Created by my institute"
                                        />
                                        <FormControlLabel
                                            value="other"
                                            control={<BpRadio />}
                                            label="Imported course"
                                        />
                                    </RadioGroup>
                                </FormControl>
                            </Box>
                            <Box
                                sx={{
                                    display: "flex",
                                    justifyContent: "space-between",
                                    alignItems: "center",
                                    background: "#F3F6FD",
                                    padding: "15px",
                                    borderRadius: "10px",
                                    margin: "15px auto",
                                }}
                            >
                                <Box sx={{ width: "80%" }}>
                                    <Typography fontWeight={"600"} mb={3}>
                                        Course Status
                                    </Typography>
                                    <FormControl
                                        fullWidth
                                        sx={{ bgcolor: "white", borderRadius: "15px" }}
                                    >
                                        <Select
                                            sx={{ borderRadius: "16px" }}
                                            labelId="demo-multiple-checkbox-label"
                                            id="demo-multiple-checkbox"
                                            multiple
                                            value={personName}
                                            onChange={handleChangeCoursestatus}
                                            renderValue={(selected) => selected.join(", ")}
                                            MenuProps={MenuProps}
                                        >
                                            {names.map((name) => (
                                                <MenuItem key={name} value={name}>
                                                    <Checkbox checked={personName.indexOf(name) > -1} />
                                                    <ListItemText primary={name} />
                                                </MenuItem>
                                            ))}
                                        </Select>
                                    </FormControl>
                                </Box>
                            </Box>
                        </Box>
                    </Box>{" "}
                    <Paper elevation={2}
                        sx={{
                            background: "white",
                            padding: "10px",
                            borderRadius: "10px",
                            textAlign: "center",
                            bottom: "0px", position: "absolute",
                            width: "96%"
                        }}
                    >
                        <Button variant="contained">Apply Filter</Button>
                    </Paper>
                </Box>
            </Drawer>
        </div>
    );
};

export default Filtersidedrawer;