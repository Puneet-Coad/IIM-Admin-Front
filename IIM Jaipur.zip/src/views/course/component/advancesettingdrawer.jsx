import * as React from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import { styled } from "@mui/material/styles";
import Switch from "@mui/material/Switch";
import FormControlLabel from "@mui/material/FormControlLabel";
import CloseIcon from "@mui/icons-material/Close";
import { Typography } from "@mui/material";

export default function AnchorTemporaryDrawer() {
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(16px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 0,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#33cf4d",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {
        color:
          theme.palette.mode === "light"
            ? theme.palette.grey[100]
            : theme.palette.grey[600],
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 22,
      height: 22,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
      transition: theme.transitions.create(["background-color"], {
        duration: 500,
      }),
    },
  }));
  const [open, setOpen] = React.useState(false);

  const toggleDrawer = (openState) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setOpen(openState);
  };

  return (
    <div>
      <Button
        onClick={toggleDrawer(true)}
        component="label"
        role={undefined}
        tabIndex={-1}
        sx={{
          textTransform: "none",
          fontSize: "12px",
          color: "#76C1D6",
          marginTop: "-20px",
          background: "#e4f5ff",
          borderRadius: "10px",
          padding: "10px",
          textDecoration: "underline",
        }}
      >
        Advanced Settings
      </Button>

      <Drawer
        anchor="right"
        open={open}
        onClose={toggleDrawer(false)}
        sx={{
          ".MuiPaper-root.MuiPaper-elevation.MuiPaper-elevation16.MuiDrawer-paper.MuiDrawer-paperAnchorRight.css-1160xiw-MuiPaper-root-MuiDrawer-paper":
            {
              borderRadius: "20px",
              boxShadow:
                "rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px;",
            },
        }}
      >
        <Box
          sx={{ width: 500, borderRadius: "20px" }}
          role="presentation"
          onClick={(event) => event.stopPropagation()} 
          onKeyDown={toggleDrawer(false)}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              padding: "10px",
              height: "50px",
              justifyContent: "space-between",
            }}
          >
            <Typography sx={{ fontWeight: "600", fontSize: "23px" }}>
              Advanced Settings
            </Typography>
            <Button onClick={toggleDrawer(false)}>
              <CloseIcon />
            </Button>
          </Box>
          <Divider />

          <Box sx={{ padding: "20px" }}>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box sx={{ width: "80%" }}>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  Internet handling charges
                </Typography>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  sx={{ color: "gray" }}
                  fontWeight={500}
                >
                  Switch ON to pay internet charges yourself(₹0.03){" "}
                </Typography>
              </Box>
              <Box>
                <FormControlLabel
                  control={<IOSSwitch sx={{ m: 1 }} defaultUnChecked />}
                  // label="iOS style"
                />
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box sx={{ width: "80%" }}>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  Tax Details{" "}
                </Typography>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  sx={{ color: "gray" }}
                  fontWeight={500}
                >
                  Switch ON to pay internet charges yourself(₹0.03){" "}
                </Typography>
              </Box>
              <Box>
                <FormControlLabel
                  control={<IOSSwitch sx={{ m: 1 }} defaultUnChecked />}
                  // label="iOS style"
                />
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box sx={{ width: "80%" }}>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  Course has offline Material for Shipment{" "}
                </Typography>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  sx={{ color: "gray" }}
                  fontWeight={500}
                >
                  Switch ON to collect students address and send them physical
                  study material{" "}
                </Typography>
              </Box>
              <Box>
                <FormControlLabel
                  control={<IOSSwitch sx={{ m: 1 }} defaultUnChecked />}
                  // label="iOS style"
                />
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box sx={{ width: "80%" }}>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  Offline Download of Videos{" "}
                </Typography>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  sx={{ color: "gray" }}
                  fontWeight={500}
                >
                  Switch ON if you want your students to be able to access hte
                  videos offline on phone{" "}
                </Typography>
              </Box>
              <Box>
                <FormControlLabel
                  control={<IOSSwitch sx={{ m: 1  }} defaultUnChecked  />}
                  // label="iOS style"
                />
              </Box>
            </Box>
            <Box
              sx={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box sx={{ width: "80%" }}>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  PDF Download Permission in APP{" "}
                </Typography>
                <Typography
                  variant="caption"
                  display="block"
                  gutterBottom
                  sx={{ color: "gray" }}
                  fontWeight={500}
                >
                  Switch ON if you want to allow student to download and save PDF
                  files in mobile app the files will be saved in the INTERNAL
                  storage of their mobile system through which they can share
                  the content with someone.
                </Typography>
              </Box>
              <Box>
                <FormControlLabel
                  control={<IOSSwitch sx={{ m: 1 }} defaultUnChecked />}
                  // label="iOS style"
                />
              </Box>
            </Box>
          </Box>
        </Box>{" "}
      </Drawer>
    </div>
  );
}
