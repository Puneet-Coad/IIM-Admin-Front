import React, { useState } from "react";
import { MdOutlineFilterAlt } from "react-icons/md";
import SearchIcon from "@mui/icons-material/Search";
import Usertable from './component/usertable';
import Sidebar from "../../components/sidebar";
import Navbar from "../../comon/navbar/navbar";
import {
    IconButton,
    InputBase,
    Grid,
    Box,
    Paper,
    Button
} from "@mui/material";

const User = () => {
    const [activeStep, setActiveStep] = useState(0);
    const [checked, setChecked] = useState(false);

    const handleChangecheck = (event) => {
        setChecked(event.target.checked);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    };

    const [searchQuery, setSearchQuery] = useState("");

    const handleSearch = () => {
        console.log("Search query:", searchQuery);
    };

    const handleChange1 = (event) => {
        setSearchQuery(event.target.value);
    };

    return (
        <>
             
                    <Grid container >
                        <Grid item xs={12}>
                            <Navbar
                                title=" Your Courses(157) "
                                desc=" Add/View Courses of your brand "
                                progressNum={78}
                            />
                        </Grid>
                        <Grid item xs={12} sx={{ mt: '10px' }}>
                            <Grid container spacing={2}>
                                <Grid item xs={4}>
                                    <Box
                                        component="form"
                                        sx={{
                                            p: "2px 4px",
                                            display: "flex",
                                            alignItems: "center",
                                            width: "100%",
                                            borderRadius: "16px",
                                            border: "1px solid #b4b4b4",
                                            background: "white",
                                            height: "36px",
                                        }}
                                    >
                                        <IconButton
                                            type="button"
                                            sx={{ p: "10px" }}
                                            aria-label="search"
                                            onClick={handleSearch}
                                        >
                                            <SearchIcon />
                                        </IconButton>
                                        <InputBase
                                            sx={{ ml: 1, flex: 1 }}
                                            placeholder="Search by name"
                                            inputProps={{ "aria-label": "search google maps" }}
                                            onChange={handleChange1}
                                            value={searchQuery}
                                        />
                                    </Box>
                                </Grid>
                                <Grid item xs={3}>
                                    <Button
                                        component="label"
                                        role={undefined}
                                        tabIndex={-1}
                                        sx={{
                                            width: "90%",
                                            background: "white",
                                            textAlign: "center",
                                            borderRadius: "16px",
                                            padding: "10px",
                                            color: "black",
                                            textTransform: "none",
                                            border: "1px solid #b4b4b4",
                                            height: "40px",
                                        }}
                                    >
                                        <MdOutlineFilterAlt />
                                        Filter
                                    </Button>
                                </Grid>
                            </Grid>
                        </Grid>

                        <Grid container mt={0} spacing={2} position={"relative"}>
                            <Grid item xs={12}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        borderRadius: "20px",
                                        padding: "25px",
                                        height: "70vh",
                                        overflow: "overlay",
                                        "&::-webkit-scrollbar": { display: "none" },
                                    }}
                                >
                                    <Usertable />
                                </Paper>
                            </Grid>

                        </Grid>
                    </Grid>
                
        </>
    );
};

export default User;
