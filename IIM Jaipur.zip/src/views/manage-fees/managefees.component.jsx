import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import { FormControl, InputBase, } from "@mui/material";
import Accordion from "@mui/material/Accordion";
import IconButton from "@mui/material/IconButton";
import DeleteIcon from "@mui/icons-material/Delete";
import Radio from "@mui/material/Radio";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import ListItemAvatar from "@mui/material/ListItemAvatar";
import RadioGroup from "@mui/material/RadioGroup";
import FormControlLabel from "@mui/material/FormControlLabel";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import iim from "../../assets/iim.png";
import Divider from "@mui/material/Divider";
import money from "../../assets/money.png";
import Navbar from "../../comon/navbar/navbar";
import SearchIcon from "@mui/icons-material/Search";

const ManageFees = () => {
  const [expanded, setExpanded] = React.useState(true);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };

  const handleCheckboxClick = (event) => {
    event.stopPropagation(); // Prevent event propagation to the accordion
  };

  const [activeButton, setActiveButton] = useState("Unpaid");
  const [grid8Content, setGrid8Content] = useState("Default Content");

  const handleButtonClick = (buttonName, content) => {
    setActiveButton(buttonName);
    setGrid8Content(content);
  };
  const [searchQuery, setSearchQuery] = useState("");
  const [age, setAge] = useState("");

  const handleSearch = () => {
    // Implement your search logic here
  };
  const label = { inputProps: { "aria-label": "Checkbox demo" } };

  const handleChange1 = (event) => {
    setSearchQuery(event.target.value);
  };

  const renderContent = () => {
    switch (activeButton) {
      case "Unpaid":
        return (
          <Grid container sx={{ alignItems: "center" }}>
            <Grid itemn xs={6}>
              <Typography sx={{ fontSize: "20px", color: "gray" }}>
                Outstanding Payment - ₹0
              </Typography>
            </Grid>
            <Grid itemn xs={6}>
              <Box sx={{ textAlign: "center" }}>
                <Button
                  sx={{
                    background: "#059FE3",
                    padding: "8px",
                    borderRadius: "5px",
                    color: "white",
                    textTransform: "none",
                    fontSize: "12px",

                    "&:hover": {
                      background: "#007bb5", // Change background color on hover
                      textDecoration: "none", // Remove any default hover effects
                    },
                  }}
                >
                  Add Payment Record
                </Button>
              </Box>
            </Grid>

            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Typography sx={{ fontSize: "10px", color: "gray" }}>
                TRANSACTION
              </Typography>
            </Grid>
            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Box sx={{ textAlign: "center" }}>
                <Box
                  component="form"
                  sx={{
                    p: "2px 4px",
                    display: "flex",
                    alignItems: "center",
                    width: "350px",
                    borderRadius: "16px",
                    height: "42px",
                    borderRadius: "42px",
                  }}
                >
                  <IconButton
                    type="button"
                    sx={{ p: "10px", height: "44.6px" }}
                    aria-label="search"
                    onClick={handleSearch}
                  >
                    <SearchIcon />
                  </IconButton>
                  <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder="Search by name"
                    inputProps={{
                      "aria-label": "search google maps",
                    }}
                    onChange={handleChange1}
                    value={searchQuery}
                  />
                </Box>
              </Box>
            </Grid>

            <Grid container>
              <Grid item xs={12}>
                <Paper sx={{ padding: "20px" }}>
                  <Box sx={{ textAlign: "center", padding: "10px" }}>
                    <img
                      src={money}
                      style={{
                        width: "50px",
                        background: "#80808026",
                        borderRadius: "50px",
                      }}
                    ></img>
                  </Box>
                  <Typography
                    variant="h5"
                    fontWeight={600}
                    sx={{ textAlign: "center" }}
                  >
                    You Dont have any payment record to display here
                  </Typography>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
        );
      case "Upcoming":
        return (
          <Grid container sx={{ alignItems: "center" }}>
            <Grid itemn xs={6}>
              <Typography sx={{ fontSize: "20px", color: "gray" }}>
                Upcoming Payment - ₹0
              </Typography>
            </Grid>
            <Grid itemn xs={6}>
              <Box sx={{ textAlign: "center" }}>
                <Button
                  sx={{
                    background: "#059FE3",
                    padding: "8px",
                    borderRadius: "5px",
                    color: "white",
                    textTransform: "none",
                    fontSize: "12px",

                    "&:hover": {
                      background: "#007bb5", // Change background color on hover
                      textDecoration: "none", // Remove any default hover effects
                    },
                  }}
                >
                  Add Payment Record
                </Button>
              </Box>
            </Grid>

            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Typography sx={{ fontSize: "10px", color: "gray" }}>
                TRANSACTION
              </Typography>
            </Grid>
            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Box sx={{ textAlign: "center" }}>
                <Box
                  component="form"
                  sx={{
                    p: "2px 4px",
                    display: "flex",
                    alignItems: "center",
                    width: "350px",
                    borderRadius: "16px",
                    height: "42px",
                    borderRadius: "42px",
                  }}
                >
                  <IconButton
                    type="button"
                    sx={{ p: "10px", height: "44.6px" }}
                    aria-label="search"
                    onClick={handleSearch}
                  >
                    <SearchIcon />
                  </IconButton>
                  <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder="Search by name"
                    inputProps={{
                      "aria-label": "search google maps",
                    }}
                    onChange={handleChange1}
                    value={searchQuery}
                  />
                </Box>
              </Box>
            </Grid>

            <Grid container>
              <Grid item xs={12}>
                <Paper sx={{ padding: "20px" }}>
                  <Box sx={{ textAlign: "center", padding: "10px" }}>
                    <img
                      src={money}
                      style={{
                        width: "50px",
                        background: "#80808026",
                        borderRadius: "50px",
                      }}
                    ></img>
                  </Box>
                  <Typography
                    variant="h5"
                    fontWeight={600}
                    sx={{ textAlign: "center" }}
                  >
                    You Dont have any payment record to display here
                  </Typography>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
        );
      case "Paid":
        return (
          <Grid container sx={{ alignItems: "center" }}>
            <Grid itemn xs={6}>
              <Typography sx={{ fontSize: "20px", color: "gray" }}>
                Payment Recieved - ₹0
              </Typography>
            </Grid>
            <Grid itemn xs={6}>
              <Box sx={{ textAlign: "center" }}>
                <Button
                  sx={{
                    background: "#059FE3",
                    padding: "8px",
                    borderRadius: "5px",
                    color: "white",
                    textTransform: "none",
                    fontSize: "12px",

                    "&:hover": {
                      background: "#007bb5",
                      textDecoration: "none",
                    },
                  }}
                >
                  Add Payment Record
                </Button>
              </Box>
            </Grid>

            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Typography sx={{ fontSize: "10px", color: "gray" }}>
                TRANSACTION
              </Typography>
            </Grid>
            <Grid itemn xs={6} sx={{ margin: "10px auto" }}>
              <Box sx={{ textAlign: "center" }}>
                <Box
                  component="form"
                  sx={{
                    p: "2px 4px",
                    display: "flex",
                    alignItems: "center",
                    width: "350px",
                    borderRadius: "16px",
                    height: "42px",
                    borderRadius: "42px",
                  }}
                >
                  <IconButton
                    type="button"
                    sx={{ p: "10px", height: "44.6px" }}
                    aria-label="search"
                    onClick={handleSearch}
                  >
                    <SearchIcon />
                  </IconButton>
                  <InputBase
                    sx={{ ml: 1, flex: 1 }}
                    placeholder="Search by name"
                    inputProps={{
                      "aria-label": "search google maps",
                    }}
                    onChange={handleChange1}
                    value={searchQuery}
                  />
                </Box>
              </Box>
            </Grid>

            <Grid container>
              <Grid item xs={12}>
                <Paper sx={{ padding: "20px" }}>
                  <Box sx={{ textAlign: "center", padding: "10px" }}>
                    <img
                      src={money}
                      style={{
                        width: "50px",
                        background: "#80808026",
                        borderRadius: "50px",
                      }}
                    ></img>
                  </Box>
                  <Typography
                    variant="h5"
                    fontWeight={600}
                    sx={{ textAlign: "center" }}
                  >
                    You Dont have any payment record to display here
                  </Typography>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
        );
      case "Student List":
        return (
          <Grid container sx={{ alignItems: "center" }}>
            <Grid container>
              <Grid item xs={12}>
                <Paper
                  sx={{
                    padding: "20px",
                    height: "84vh",
                    overflow: "overlay",
                    borderRadius: "16px",
                    "&::-webkit-scrollbar": {
                      width: "8px",
                      display: "none",
                    },
                    "&::-webkit-scrollbar-thumb": {
                      backgroundColor: "#888",
                      borderRadius: "4px",
                      display: "none",
                    },
                    "&::-webkit-scrollbar-track": {
                      backgroundColor: "#f1f1f1",
                      borderRadius: "8px",
                      display: "none",
                    },
                  }}
                >
                  <Typography
                    sx={{
                      color: " #b6b6b6",
                      fontWeight: "400",
                      fontSize: "13px",
                    }}
                  >
                    STUDENTS(31090)
                  </Typography>

                  <Box
                    component="form"
                    sx={{
                      p: "2px 4px",
                      display: "flex",
                      alignItems: "center",
                      width: "350px",
                      borderRadius: "16px",
                      height: "42px",
                      borderRadius: "42px",
                    }}
                  >
                    <IconButton
                      type="button"
                      sx={{ padding: "0px" }}
                      aria-label="search"
                      onClick={handleSearch}
                    >
                      <SearchIcon sx={{ fontSize: "20px" }} />
                    </IconButton>
                    <InputBase
                      sx={{ ml: 1, flex: 1 }}
                      placeholder="Search..."
                      style={{ fontSize: "13px" }}
                      inputProps={{
                        "aria-label": "search google maps",
                      }}
                      onChange={handleChange1}
                      value={searchQuery}
                    />
                  </Box>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "green",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          N
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Naved"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "pink",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          R
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Rakesh"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "Yellow",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          V
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Vikas"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "purple",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          P
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Pankaj"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "Orange",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          O
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Orhan"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "indigo",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          I
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Ishan"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                  <List
                    sx={{
                      width: "100%",
                      maxWidth: 360,
                      bgcolor: "background.paper",
                    }}
                  >
                    <ListItem>
                      <ListItemAvatar>
                        <Typography
                          sx={{
                            fontSize: "18px",
                            background: "#D0DC57",
                            padding: "15px",
                            alignItems: "center",
                            color: "white",
                            borderRadius: "50px",
                            width: "13px",
                            height: "13px",
                            display: "flex",
                            justifyContent: "center",
                            fontWeight: "500",
                          }}
                        >
                          A
                        </Typography>
                      </ListItemAvatar>
                      <ListItemText
                        primary="Anil"
                        style={{ fontWeight: "500" }}
                      />
                    </ListItem>
                    <Divider sx={{ width: "100%" }} />{" "}
                    {/* Set divider width to 100% */}
                  </List>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
        );
      case "Payment Setting":
        return (
          <>
            <Paper>
              <Grid container padding={5}>
                <Grid item xs={12}>
                  <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                    TEAM MEMBERS(S)
                  </Typography>
                  <Typography
                    sx={{
                      fontWeight: "500",
                      color: "gray",
                      fontSize: "12px",
                      margin: "10px auto",
                    }}
                  >
                    OWNER{" "}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      margin: "20px auto",
                      height: "20px",
                    }}
                  >
                    <img
                      src={iim}
                      style={{ width: "10%", borderRadius: "20px" }}
                    ></img>
                    <Typography
                      sx={{
                        fontWeight: "600",
                        fontSize: "12px",
                        marginLeft: "10px",
                      }}
                    >
                      IIM Jaipur
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      margin: "20px auto",
                      height: "20px",
                    }}
                  >
                    <Typography
                      sx={{
                        fontWeight: "500",
                        fontSize: "12px",
                        marginLeft: "10px",
                        color: "gray",
                      }}
                    >
                      9563773848{" "}
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={12}>
                  <Typography
                    sx={{
                      fontWeight: "500",
                      color: "gray",
                      fontSize: "12px",
                      margin: "10px auto",
                    }}
                  >
                    TEAM MEMBER{" "}
                  </Typography>
                </Grid>
                <Grid item xs={12}>
                  <Typography
                    sx={{
                      fontWeight: "600",
                      color: "gray",
                      fontSize: "15px",
                      margin: "10px auto",
                      textAlign: "center",
                    }}
                  >
                    NO CARETAKER PRESENT{" "}
                  </Typography>
                </Grid>
              </Grid>{" "}
            </Paper>
            <Paper sx={{
              margin: "10px auto", height: "48vh", borderRadius: "16px", overflow: "overlay",
              "&::-webkit-scrollbar": {
                width: "8px",
              },
              "&::-webkit-scrollbar-thumb": {
                backgroundColor: "#888",
                borderRadius: "4px",
              },
              "&::-webkit-scrollbar-track": {
                backgroundColor: "#f1f1f1",
                borderRadius: "8px",
              },
            }}
            >
              <Grid container padding={3}>
                <Grid item xs={6}>
                  <Typography
                    sx={{
                      fontWeight: "500",
                      color: "gray",
                      fontSize: "12px",
                      margin: "10px auto",
                    }}
                  >
                    FEES STRUCTURE{" "}
                  </Typography>
                </Grid>
                <Grid item xs={6}>
                  <Box sx={{ display: "flex", justifyContent: "end" }}>
                    <Button
                      sx={{
                        background: "#059FE3",
                        padding: "8px",
                        borderRadius: "5px",
                        color: "white",
                        textTransform: "none",
                        fontSize: "12px",

                        "&:hover": {
                          background: "#007bb5", // Change background color on hover
                          textDecoration: "none", // Remove any default hover effects
                        },
                      }}
                    >
                      Add
                    </Button>
                  </Box>
                </Grid>


                <Grid container alignItems="center"  >
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test2</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test2</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test2</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Typography sx={{ fontWeight: "600" }}>Test2</Typography>
                  </Grid>
                  <Grid item xs={6}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "flex-end",
                        alignItems: "center",
                        margin: "10px auto"
                      }}
                    >
                      <Button sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Edit
                      </Button>
                      <IconButton aria-label="delete">
                        <DeleteIcon sx={{ fontSize: "20px" }} />
                      </IconButton>
                      <Typography sx={{ fontWeight: "600", fontSize: "12px" }}>
                        Remove
                      </Typography>
                    </Box>
                  </Grid>
                </Grid>


              </Grid>{" "}
            </Paper>
          </>
        );

      default:
        return null;
    }
  };

  const renderGrid8Content = () => {
    switch (activeButton) {
      case "Unpaid":
        return (
          <Box sx={{ width: "70%", margin: "55px auto" }}>
            {" "}
            <Accordion
              expanded={expanded === "panel2"}
              onChange={handleChange("panel2")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Batches
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                  eget.
                </Typography>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === "panel1"}
              onChange={handleChange("panel1")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1-content"
                id="panel1-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Date
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <FormControl>
                  <RadioGroup
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="All"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel
                      value="All"
                      control={<Radio />}
                      label="All"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 7 Days"
                      control={<Radio />}
                      label="Last 7 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 14 Days"
                      control={<Radio />}
                      label="Last 14 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Custom date"
                      control={<Radio />}
                      label="Custom date"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                  </RadioGroup>
                </FormControl>
              </AccordionDetails>
            </Accordion>
          </Box>
        );
      case "Upcoming":
        return (
          <Box sx={{ width: "70%", margin: "55px auto" }}>
            {" "}
            <Accordion
              expanded={expanded === "panel2"}
              onChange={handleChange("panel2")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Batches
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                  eget.
                </Typography>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === "panel1"}
              onChange={handleChange("panel1")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1-content"
                id="panel1-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Date
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <FormControl>
                  <RadioGroup
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="All"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel
                      value="All"
                      control={<Radio />}
                      label="All"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 7 Days"
                      control={<Radio />}
                      label="Last 7 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 14 Days"
                      control={<Radio />}
                      label="Last 14 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Custom date"
                      control={<Radio />}
                      label="Custom date"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                  </RadioGroup>
                </FormControl>
              </AccordionDetails>
            </Accordion>
          </Box>
        );
      case "Paid":
        return (
          <Box sx={{ width: "70%", margin: "55px auto" }}>
            {" "}
            <Accordion
              expanded={expanded === "panel2"}
              onChange={handleChange("panel2")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel2-content"
                id="panel2-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Batches
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Typography>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                  Suspendisse malesuada lacus ex, sit amet blandit leo lobortis
                  eget.
                </Typography>
              </AccordionDetails>
            </Accordion>
            <Accordion
              expanded={expanded === "panel1"}
              onChange={handleChange("panel1")}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panel1-content"
                id="panel1-header"
              >
                <Typography
                  sx={{ margin: " auto", color: "gray", fontWeight: "600" }}
                >
                  Date
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <FormControl>
                  <RadioGroup
                    aria-labelledby="demo-radio-buttons-group-label"
                    defaultValue="All"
                    name="radio-buttons-group"
                  >
                    <FormControlLabel
                      value="All"
                      control={<Radio />}
                      label="All"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 7 Days"
                      control={<Radio />}
                      label="Last 7 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Last 14 Days"
                      control={<Radio />}
                      label="Last 14 Days"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                    <FormControlLabel
                      value="Custom date"
                      control={<Radio />}
                      label="Custom date"
                      sx={{ fontWeight: "bold", height: "25px" }}
                    />
                  </RadioGroup>
                </FormControl>
              </AccordionDetails>
            </Accordion>
          </Box>
        );
      case "Student List":
        return (
          <>
            <Paper sx={{ height: "fit-content" }}>
              <Box
                sx={{
                  padding: "15px",
                  height: "240px",
                  overflow: "overlay",
                  borderRadius: "16px",
                  "&::-webkit-scrollbar": {
                    width: "8px",
                  },
                  "&::-webkit-scrollbar-thumb": {
                    backgroundColor: "#888",
                    borderRadius: "4px",
                  },
                  "&::-webkit-scrollbar-track": {
                    backgroundColor: "#f1f1f1",
                    borderRadius: "8px",
                  },
                }}
              >
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  BSE Third year complex Analysis
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  BSE Second year complex Analysis
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
                <Typography
                  sx={{
                    fontSize: "12px",
                    fontWeight: "500",
                    display: "flex",
                    alignItems: "center",
                    width: "70%",
                  }}
                >
                  <Checkbox {...label} sx={{ color: "gray" }} />
                  CSE Mathematics
                </Typography>
              </Box>
            </Paper>
          </>
        );
      case "Payment Setting":
        return <div>Grid 8 Payment Setting Content</div>;
      default:
        return null;
    }
  };

  return (
    <>

      <Grid container>
        <Grid item xs={12}>
          <Navbar
            title=" Your Courses(157) "
            desc=" Add/View Courses of your brand "
            progressNum={78}
          />
        </Grid>

        <Grid container mt={0} spacing={2} position={"relative"}>
          <Grid item xs={2} container>
            <Box
              sx={{
                display: "flex",
                flexDirection: "column",
              }}
            >
              <Button
                sx={{
                  textTransform: "none",
                  color: "black",
                  justifyContent: "left",
                  color: activeButton === "Unpaid" ? "blue" : "inherit",
                }}
                onClick={() =>
                  handleButtonClick("Unpaid", "Grid 8 Unpaid Content")
                }
              >
                Unpaid
              </Button>
              <Button
                sx={{
                  textTransform: "none",
                  color: "black",
                  justifyContent: "left",
                  color: activeButton === "Upcoming" ? "blue" : "inherit",
                }}
                onClick={() =>
                  handleButtonClick("Upcoming", "Grid 8 Upcoming Content")
                }
              >
                Upcoming
              </Button>
              <Button
                sx={{
                  textTransform: "none",
                  color: "black",
                  justifyContent: "left",
                  color: activeButton === "Paid" ? "blue" : "inherit", // Change background color to blue if active
                }}
                onClick={() =>
                  handleButtonClick("Paid", "Grid 8 Paid Content")
                }
              >
                Paid
              </Button>
              <Button
                sx={{
                  textTransform: "none",
                  color: "black",
                  justifyContent: "left",
                  color:
                    activeButton === "Student List" ? "blue" : "inherit", // Change background color to blue if active
                }}
                onClick={() =>
                  handleButtonClick(
                    "Student List",
                    "Grid 8 Student List Content"
                  )
                }
              >
                Student List
              </Button>
              <Button
                sx={{
                  textTransform: "none",
                  color: "black",
                  justifyContent: "left",
                  color:
                    activeButton === "Payment Setting" ? "blue" : "inherit", // Change background color to blue if active
                }}
                onClick={() =>
                  handleButtonClick(
                    "Payment Setting",
                    "Grid 8 Payment Setting Content"
                  )
                }
              >
                Payment Setting
              </Button>
            </Box>
          </Grid>

          <Grid item xs={0.1} container>
            <Divider orientation="vertical" sx={{ width: "1px" }} />{" "}
            {/* Change divider color to blue */}
          </Grid>

          <Grid item xs={6.5}>
            {renderContent()}
          </Grid>
          <Grid
            item
            xs={3.3}
            sx={{ justifyContent: "center", display: "flex" }}
          >
            {renderGrid8Content()}
          </Grid>
        </Grid>
      </Grid>

    </>
  );
};

export default ManageFees;
