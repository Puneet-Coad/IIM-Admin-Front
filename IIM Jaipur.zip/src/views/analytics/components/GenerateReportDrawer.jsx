import React, { useState } from "react";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import { styled } from "@mui/material/styles";
import MenuItem from '@mui/material/MenuItem';
 import Select from '@mui/material/Select';
import { FaFileInvoice } from "react-icons/fa6";
import { FaChevronRight } from "react-icons/fa";
import Switch from "@mui/material/Switch"; 
import { FormControl, InputBase, NativeSelect } from "@mui/material";

import CloseIcon from "@mui/icons-material/Close";
import { Typography } from "@mui/material";

export default function AnchorTemporaryDrawer() {
  const BootstrapInput = styled(InputBase)(({ theme }) => ({
    "& .MuiInputBase-input": {
      borderRadius: 4,
      backgroundColor: theme.palette.background.paper,
      border: "1px solid #ced4da",
      fontSize: 16,
      padding: "10px 26px 10px 12px",
      transition: theme.transitions.create(["border-color", "box-shadow"]),
      fontFamily: [
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(","),
      "&:focus": {
        borderRadius: 4,
        borderColor: "#80bdff",
        boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
      },
    },
  }));
  const IOSSwitch = styled((props) => (
    <Switch
      focusVisibleClassName=".Mui-focusVisible"
      disableRipple
      {...props}
    />
  ))(({ theme }) => ({
    width: 42,
    height: 26,
    padding: 0,
    "& .MuiSwitch-switchBase": {
      padding: 0,
      margin: 2,
      transitionDuration: "300ms",
      "&.Mui-checked": {
        transform: "translateX(16px)",
        color: "#fff",
        "& + .MuiSwitch-track": {
          backgroundColor:
            theme.palette.mode === "dark" ? "#2ECA45" : "#65C466",
          opacity: 1,
          border: 0,
        },
        "&.Mui-disabled + .MuiSwitch-track": {
          opacity: 0.5,
        },
      },
      "&.Mui-focusVisible .MuiSwitch-thumb": {
        color: "#33cf4d",
        border: "6px solid #fff",
      },
      "&.Mui-disabled .MuiSwitch-thumb": {
        color:
          theme.palette.mode === "light"
            ? theme.palette.grey[100]
            : theme.palette.grey[600],
      },
      "&.Mui-disabled + .MuiSwitch-track": {
        opacity: theme.palette.mode === "light" ? 0.7 : 0.3,
      },
    },
    "& .MuiSwitch-thumb": {
      boxSizing: "border-box",
      width: 22,
      height: 22,
    },
    "& .MuiSwitch-track": {
      borderRadius: 26 / 2,
      backgroundColor: theme.palette.mode === "light" ? "#E9E9EA" : "#39393D",
      opacity: 1,
      transition: theme.transitions.create(["background-color"], {
        duration: 500,
      }),
    },
  }));
  const [open, setOpen] = React.useState(false);
  const handleChange = (event) => {
    setAge(event.target.value);
  };

  const [age, setAge] = useState("");

  const toggleDrawer = (openState) => (event) => {
    if (
      event &&
      event.type === "keydown" &&
      (event.key === "Tab" || event.key === "Shift")
    ) {
      return;
    }

    setOpen(openState);
  };

  return (
    <div>
      <Box
        onClick={toggleDrawer(true)}
        sx={{
          display: "flex",
          justifyContent: "space-evenly",
          textAlign: "left",
          alignItems: "center",
          background: "#F3F6FD",
          color: "#35D5FF",
          borderRadius: "12px",
          margin: "20px auto",
          padding: "10px",
        }}
      >
        <FaFileInvoice
          style={{
            color: "#55A2C9",
            background: "#CFECFC",
            borderRadius: "50%",
            padding: "12px",
            fontWeight: "600",
          }}
        />
        <Button
          component="label"
          role={undefined}
          tabIndex={-1}
          sx={{
            textTransform: "none", 
            color: "#55A2C9",
            fontSize: "15px",
            fontWeight: "700",
          }}
        >
          Generate Reports{" "}
        </Button>{" "}
        <Typography sx={{ marginLeft: "20px" }}>
          {" "}
          <FaChevronRight style={{ color: "#6FC2EA" }} />{" "}
        </Typography>
      </Box>

      <Drawer
        anchor="right"
        open={open}
        onClose={toggleDrawer(false)}
        sx={{
          ".MuiPaper-root.MuiPaper-elevation.MuiPaper-elevation16.MuiDrawer-paper.MuiDrawer-paperAnchorRight.css-1160xiw-MuiPaper-root-MuiDrawer-paper":
            {
              borderRadius: "20px",
              boxShadow:
                "rgba(17, 17, 26, 0.1) 0px 4px 16px, rgba(17, 17, 26, 0.1) 0px 8px 24px, rgba(17, 17, 26, 0.1) 0px 16px 56px;",
            },
        }}
      >
        <Box
          sx={{ width: 500, borderRadius: "20px" }}
          role="presentation"
          onClick={(event) => event.stopPropagation()}
          onKeyDown={toggleDrawer(false)}
        >
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              padding: "10px",
              height: "50px",
              justifyContent: "space-between",
            }}
          >
            <Typography sx={{ fontWeight: "600", fontSize: "23px" }}>
              Advanced Settings
            </Typography>
            <Button onClick={toggleDrawer(false)}>
              <CloseIcon />
            </Button>
          </Box>
          <Divider />

          <Box sx={{ padding: "20px" }}>
            <Box
              sx={{
                background: "#F3F6FD",
                padding: "10px",
                borderRadius: "10px",
                margin: "15px auto",
              }}
            >
              <Box>
                <Typography
                  variant="subtitle2"
                  fontSize={16}
                  fontWeight={600}
                  gutterBottom
                >
                  Report Type
                </Typography>
              </Box>
              <Box>
                <FormControl variant="standard" sx={{ width: "100%" }}>
                  <Select
                    id="demo-customized-select-native"
                    value={age}
                    onChange={handleChange}
                    sx={{ height: "47.6px" }}
                    input={<BootstrapInput />}
                  >
                    <MenuItem value="0" > 
                        Recently Created{" "} 
                    </MenuItem>
                    <MenuItem value="1" > 
                        1{" "} 
                    </MenuItem>
                    <MenuItem value="2"> 
                    2{" "} 
                    </MenuItem>
                  </Select>
                </FormControl>
              </Box>
            </Box>
          </Box>
        </Box>{" "}
      </Drawer>
    </div>
  );
}
