import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { MdOutlineCurrencyRupee } from "react-icons/md";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import { IoPersonOutline } from "react-icons/io5";
import { FormControl, InputBase, NativeSelect } from "@mui/material";
import { FaArrowUp } from "react-icons/fa";
import { styled } from "@mui/material/styles";
import Navbar from "../../comon/navbar/navbar";
import website from "../../assets/0 website.png";
import GenerateReportDrawer from "./components/GenerateReportDrawer";
import { FaChevronRight } from "react-icons/fa";




const TabContent1 = () => (
    <Paper
        sx={{
            height: "45vh",
            overflow: "overlay",
            "&::-webkit-scrollbar": { display: "none" },
        }}
    >
        <Box
            display={"flex"}
            justifyContent={"center"}
            alignItems={"center"}
            sx={{ height: "100%" }}
        >
            <img src={website} style={{ width: "20%" }}></img>
        </Box>
    </Paper>
);

const TabContent2 = () => (
    <Paper
        sx={{
            height: "45vh",
            overflow: "overlay",
            "&::-webkit-scrollbar": { display: "none" },
        }}
    >
        <Box>Content for Tab 2</Box>
    </Paper>
);

const TabContent3 = () => (
    <Paper
        sx={{
            height: "45vh",
            overflow: "overlay",
            "&::-webkit-scrollbar": { display: "none" },
        }}
    >
        <Box>Content for Tab 3</Box>
    </Paper>
);

const TabContent4 = () => (
    <Paper
        sx={{
            height: "45vh",
            overflow: "overlay",
            "&::-webkit-scrollbar": { display: "none" },
        }}
    >
        <Box>Content for Tab 4</Box>
    </Paper>
);

const analyticsArr = [
    {
        desc: "0% up compared to last 7 days",
        name: "Website Sessions",
    },
    {
        desc: "40% down compared to last 7 days",
        name: "Buy Now Clicks",
    },
    {
        desc: "61% compared to last 7 days",
        name: "Transactions",
    },
    {
        desc: "62% compared to last 7 days",
        name: "Revenue",
    },
];

const Analytics = () => {
    const [activeTab, setActiveTab] = useState(0);
    const handleTabChange = (index) => {
        setActiveTab(index);
    };

    const BootstrapInput = styled(InputBase)(({ theme }) => ({
        "& .MuiInputBase-input": {
            borderRadius: 4,
            backgroundColor: theme.palette.background.paper,
            border: "1px solid #ced4da",
            fontSize: 16,
            padding: "10px 26px 10px 12px",
            transition: theme.transitions.create(["border-color", "box-shadow"]),
            fontFamily: [
                "-apple-system",
                "BlinkMacSystemFont",
                '"Segoe UI"',
                "Roboto",
                '"Helvetica Neue"',
                "Arial",
                "sans-serif",
                '"Apple Color Emoji"',
                '"Segoe UI Emoji"',
                '"Segoe UI Symbol"',
            ].join(","),
            "&:focus": {
                borderRadius: 4,
                borderColor: "#80bdff",
                boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
            },
        },
    }));
    const [age, setAge] = useState("");
    const handleChange = (event) => {
        setAge(event.target.value);
    };



    return (
        <>
             
                    <Grid container>
                        <Grid item xs={12}>
                            <Navbar
                                title=" Your Courses(157) "
                                desc=" Add/View Courses of your brand "
                                progressNum={78}
                            />
                        </Grid>

                        <Grid container mt={0} spacing={2} position={"relative"}>
                            <Grid item xs={12}>
                                {" "}
                                <Box sx={{ margin: "20px auto" }}>
                                    <FormControl variant="standard">
                                        <NativeSelect
                                            id="demo-customized-select-native"
                                            value={age}
                                            onChange={handleChange}
                                            sx={{ height: "47.6px" }}
                                            input={<BootstrapInput />}
                                        >
                                            <option value="">
                                                <Typography sx={{ fontWeight: "700" }}>
                                                    Last 7 Days
                                                </Typography>
                                            </option>
                                            <option value={10}>Ten</option>
                                            <option value={20}>Twenty</option>
                                            <option value={30}>Thirty</option>
                                        </NativeSelect>
                                    </FormControl>
                                </Box>{" "}
                            </Grid>
                        </Grid>
                        <Grid container spacing={2}>
                            <Grid item xs={9}>
                                <Box>
                                    <Grid container spacing={2}>
                                        {analyticsArr.map((row, index) => (
                                            <Grid key={index} item xs={3}>
                                                <Paper
                                                    elevation={0}
                                                    sx={{
                                                        padding: "20px",
                                                        borderRadius: "20px",
                                                        cursor: "pointer",
                                                    }}
                                                    onClick={() => handleTabChange(index)}
                                                >
                                                    <Typography sx={{ fontWeight: "600" }}>
                                                        {row.name}
                                                    </Typography>

                                                    <Typography
                                                        sx={{
                                                            fontWeight: "800",
                                                            color: "#007FD4",
                                                            margin: "3px auto",
                                                            fontSize: "20px",
                                                        }}
                                                    >
                                                        {index + 1}
                                                    </Typography>
                                                    <Box
                                                        sx={{
                                                            display: "flex",
                                                            alignItems: "center",
                                                            margin: "10px auto",
                                                        }}
                                                    >
                                                        <FaArrowUp
                                                            style={{ color: "#9EE5BE", marginRight: "5px" }}
                                                        />
                                                        <Typography
                                                            sx={{
                                                                fontSize: "13px",
                                                                color: "gray",
                                                                fontWeight: "500",
                                                            }}
                                                        >
                                                            {row.desc}
                                                        </Typography>
                                                    </Box>
                                                </Paper>
                                            </Grid>
                                        ))}
                                        <Grid item xs={12}>
                                            {activeTab === 0 && <TabContent1 />}
                                            {activeTab === 1 && <TabContent2 />}
                                            {activeTab === 2 && <TabContent3 />}
                                            {activeTab === 3 && <TabContent4 />}
                                        </Grid>
                                    </Grid>
                                </Box>
                            </Grid>
                            <Grid item xs={3}>
                                <Paper elevation={0} sx={{ padding: "15px" }}>
                                    <Typography sx={{ fontWeight: "700" }}>
                                        Quick actions
                                    </Typography>
                                    <Box
                                        sx={{
                                            display: "flex",
                                            justifyContent: "space-evenly",
                                            textAlign: "left",
                                            alignItems: "center",
                                            background: "#F3F6FD",
                                            color: "#35D5FF",
                                            borderRadius: "12px",
                                            margin: "20px auto",
                                            padding: "10px",
                                        }}
                                    >
                                        <MdOutlineCurrencyRupee
                                            style={{
                                                color: "#55A2C9",
                                                background: "#CFECFC",
                                                borderRadius: "50%",
                                                padding: "12px",
                                                fontWeight: "600",
                                            }}
                                        />
                                        <Box>
                                            <Typography
                                                sx={{
                                                    color: "#55A2C9",
                                                    fontSize: "15px",
                                                    fontWeight: "700",
                                                }}
                                            >
                                                View Transactions
                                            </Typography>
                                        </Box>
                                        <Typography sx={{ marginLeft: "20px" }}>
                                            {" "}
                                            <FaChevronRight style={{ color: "#6FC2EA" }} />{" "}
                                        </Typography>
                                    </Box>


                                    <GenerateReportDrawer />


                                    <Box
                                        sx={{
                                            display: "flex",
                                            justifyContent: "space-evenly",
                                            textAlign: "left",
                                            alignItems: "center",
                                            background: "#F3F6FD",
                                            color: "#35D5FF",
                                            borderRadius: "12px",
                                            margin: "20px auto",
                                            padding: "10px",
                                        }}
                                    >
                                        <IoPersonOutline
                                            style={{
                                                color: "#55A2C9",
                                                background: "#CFECFC",
                                                borderRadius: "50%",
                                                padding: "12px",
                                                fontWeight: "600",
                                            }}
                                        />
                                        <Box>
                                            <Typography
                                                sx={{
                                                    color: "#55A2C9",
                                                    fontSize: "15px",
                                                    fontWeight: "700",
                                                }}
                                            >
                                                Backend Addition
                                            </Typography>
                                        </Box>
                                        <Typography sx={{ marginLeft: "20px" }}>
                                            {" "}
                                            <FaChevronRight style={{ color: "#6FC2EA" }} />{" "}
                                        </Typography>
                                    </Box>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Grid>
                
        </>
    );
};

export default Analytics;
