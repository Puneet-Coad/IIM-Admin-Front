import Analytics from "./analytics.component"
import { connect } from "react-redux";

const mapDispatchToProps = {};

const mapStateToProps = (state) => {

}

export default connect(mapStateToProps, {})(Analytics);