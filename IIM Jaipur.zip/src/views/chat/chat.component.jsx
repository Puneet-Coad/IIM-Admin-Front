import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import SearchIcon from '@mui/icons-material/Search';
import Navbar from "../../comon/navbar/navbar";
import { Avatar, Badge, Divider, IconButton, Input, InputBase, Menu, MenuItem, TextField, styled } from "@mui/material";
import { deepOrange, deepPurple } from '@mui/material/colors';
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import SendIcon from '@mui/icons-material/Send';
import { GrAttachment } from "react-icons/gr";
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import img from '../../assets/chat image.jpg';
import groupchatimg from '../../assets/groupchatimg.jpg'


const label = { inputProps: { 'aria-label': 'Checkbox demo' } };

const Chat = () => {
    
  const [currentPage, setCurrentPage] = useState("FrontPage");
  const [sidePage, setSidePage] = useState("FrontsidePage")
  const changePage = (page) => {
    // ConversationsidePage
    console.log("change state",page);
    setCurrentPage(page);
    setSidePage(page);
  };
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };



  return (
    <>
       
          <Grid container>
            <Grid item xs={12}>
              <Navbar
                title=" Your Courses(157) "
                desc=" Add/View Courses of your brand "
                progressNum={78}
              />
            </Grid>

            <Grid container mt={0} spacing={2} position={"relative"}>
              <Grid item xs={12}>
                <Paper
                  elevation={0}
                  sx={{
                    border: '1px solid #F1F1F1',
                    height: "88vh",
                    overflow: "overlay",
                    "&::-webkit-scrollbar": { display: "none" },
                  }}
                >
                  <Grid container>
                    <Grid item xs={6} sm={5} md={4} lg={4}>
                      <Box sx={{
                        height: '100%', border: '1px solid #F1F1F1'
                      }}>
                        {sidePage === "FrontsidePage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <Typography>Chats</Typography>
                              <IconButton
                                sx={{ p: '0px 10px' }}
                                aria-label="more"
                                id="long-button"
                                aria-controls={open ? 'long-menu' : undefined}
                                aria-expanded={open ? 'true' : undefined}
                                aria-haspopup="true"
                                onClick={handleClick}
                              >
                                <Typography style={{ fontSize: '25px' }}>+</Typography>
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleClose}
                                id="long-menu"
                              >
                                <MenuItem onClick={() =>{ changePage("ConversationsidePage");handleClose()}}>Start a conversation</MenuItem>
                                <MenuItem onClick={() =>{ changePage("GroupchatsidePage");handleClose()}}>New group chat</MenuItem>
                                <MenuItem>Start a Broadcast</MenuItem>
                                <MenuItem onClick={() => {changePage("MaltipalbatchPage");handleClose()}}>Multipal batch announcement</MenuItem>
                              </Menu>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>STUDENTS ARE WAITING FOR YOU</Typography>
                            <Divider />
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center'
                            }}>
                              <h2>Coursel</h2>
                              {/* <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowLeftIcon /></Avatar>
                          <Box
                            sx={{
                              display: 'flex',
                              width: '90%',
                              m: 'auto',
                              gap: '5px',
                              my: '10px',
                              overflowX: 'scroll',
                              "&::-webkit-scrollbar": {
                                // display:'none',
                                width: '0px',
                                height: '0px',
                              },
                            }}
                          >
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepOrange[500] }}>A</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>B</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>C</Avatar>
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepPurple[500] }}>D</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>E</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>F</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>G</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>H</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>J</Avatar>
                          </Box>
                          <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowRightIcon /></Avatar> */}
                            </Box>
                            <Divider />
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>MESSAGES</Typography>
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                height: '43.8vh',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box
                                onClick={() => changePage("AIPoweredLeadPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                onClick={() => changePage("AIPoweredLead-ProPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        )}
                        {sidePage === "AIPoweredLeadPage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <Typography>Chats</Typography>
                              <IconButton
                                sx={{ p: '0px 10px' }}
                                aria-label="more"
                                id="long-button"
                                aria-controls={open ? 'long-menu' : undefined}
                                aria-expanded={open ? 'true' : undefined}
                                aria-haspopup="true"
                                onClick={handleClick}
                              >
                                <Typography style={{ fontSize: '25px' }}>+</Typography>
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleClose}
                                id="long-menu"
                              >
                                <MenuItem onClick={() =>{ changePage("ConversationsidePage");handleClose()}}>Start a conversation</MenuItem>
                                <MenuItem onClick={() =>{ changePage("GroupchatsidePage");handleClose()}}>New group chat</MenuItem>
                                <MenuItem>Start a Broadcast</MenuItem>
                                <MenuItem onClick={() => {changePage("MaltipalbatchPage");handleClose()}}>Multipal batch announcement</MenuItem>
                              </Menu>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>STUDENTS ARE WAITING FOR YOU</Typography>
                            <Divider />
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center'
                            }}>
                              <h2>Coursel</h2>
                              {/* <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowLeftIcon /></Avatar>
                          <Box
                            sx={{
                              display: 'flex',
                              width: '90%',
                              m: 'auto',
                              gap: '5px',
                              my: '10px',
                              overflowX: 'scroll',
                              "&::-webkit-scrollbar": {
                                // display:'none',
                                width: '0px',
                                height: '0px',
                              },
                            }}
                          >
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepOrange[500] }}>A</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>B</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>C</Avatar>
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepPurple[500] }}>D</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>E</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>F</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>G</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>H</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>J</Avatar>
                          </Box>
                          <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowRightIcon /></Avatar> */}
                            </Box>
                            <Divider />
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>MESSAGES</Typography>
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                height: '43.8vh',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box
                                onClick={() => changePage("AIPoweredLeadPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                onClick={() => changePage("AIPoweredLead-ProPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        )}
                        {sidePage === "AIPoweredLead-ProPage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <Typography>Chats</Typography>
                              <IconButton
                                sx={{ p: '0px 10px' }}
                                aria-label="more"
                                id="long-button"
                                aria-controls={open ? 'long-menu' : undefined}
                                aria-expanded={open ? 'true' : undefined}
                                aria-haspopup="true"
                                onClick={handleClick}
                              >
                                <Typography style={{ fontSize: '25px' }}>+</Typography>
                              </IconButton>
                              <Menu
                                anchorEl={anchorEl}
                                open={open}
                                onClose={handleClose}
                                id="long-menu"
                              >
                                <MenuItem onClick={() =>{ changePage("ConversationsidePage");handleClose()}}>Start a conversation</MenuItem>
                                <MenuItem onClick={() =>{ changePage("GroupchatsidePage");handleClose()}}>New group chat</MenuItem>
                                <MenuItem>Start a Broadcast</MenuItem>
                                <MenuItem onClick={() => {changePage("MaltipalbatchPage");handleClose()}}>Multipal batch announcement</MenuItem>
                              </Menu>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>STUDENTS ARE WAITING FOR YOU</Typography>
                            <Divider />
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center'
                            }}>
                              <h2>Coursel</h2>
                              {/* <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowLeftIcon /></Avatar>
                          <Box
                            sx={{
                              display: 'flex',
                              width: '90%',
                              m: 'auto',
                              gap: '5px',
                              my: '10px',
                              overflowX: 'scroll',
                              "&::-webkit-scrollbar": {
                                // display:'none',
                                width: '0px',
                                height: '0px',
                              },
                            }}
                          >
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepOrange[500] }}>A</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>B</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>C</Avatar>
                            <StyledBadge
                              overlap="circular"
                              anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                              variant="dot"
                            >
                              <Avatar sx={{ bgcolor: deepPurple[500] }}>D</Avatar>
                            </StyledBadge>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>E</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>F</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>G</Avatar>
                            <Avatar sx={{ bgcolor: deepOrange[500] }}>H</Avatar>
                            <Avatar sx={{ bgcolor: deepPurple[500] }}>J</Avatar>
                          </Box>
                          <Avatar sx={{ width: 15, height: 15 }}><KeyboardArrowRightIcon /></Avatar> */}
                            </Box>
                            <Divider />
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>MESSAGES</Typography>
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                height: '43.8vh',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box
                                onClick={() => changePage("AIPoweredLeadPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                onClick={() => changePage("AIPoweredLead-ProPage")}
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                              <Box
                                sx={{
                                  "&:hover": { backgroundColor: "#ede9e8" },
                                  cursor: 'pointer',
                                  display: 'flex',
                                  gap: '10px',
                                  p: '10px'
                                }}>
                                <Box sx={{
                                  width: '38px',
                                  height: '35px',
                                  borderRadius: '50%',
                                  backgroundColor: '#E685B5',
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center'
                                }}><Typography>A</Typography>
                                </Box>
                                <Box sx={{ width: '100%' }}>
                                  <Box sx={{ display: 'flex', justifyContent: 'space-between' }}>
                                    <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'8px'} fontWeight={'600'}>06:34 pm</Typography>
                                  </Box>
                                  <Box fontSize={'10px'} fontWeight={'600'}>AI Powered Leads:Yours name </Box>
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        )}
                        {sidePage === "ConversationsidePage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <ArrowBackIcon onClick={() => changePage("FrontsidePage")} />
                              <Box>
                                <Typography fontSize={'8px'} fontWeight={'500'}>Start a new conversation</Typography>
                                <Typography fontSize={'13px'} fontWeight={'500'}>Select recipient&#40;s&#41;</Typography>
                              </Box>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>MESSAGES</Typography>
                            <Divider />
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                height: '63vh',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '38px',
                                    height: '35px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Typography sx={{ fontSize: '12px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                              </Box>
                            </Box>
                          </Box>
                        )}
                        {sidePage === "GroupchatsidePage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <ArrowBackIcon onClick={() => changePage("FrontsidePage")} />
                              <Box>
                                <Typography fontSize={'8px'} fontWeight={'500'}>New group chat</Typography>
                                <Typography fontSize={'13px'} fontWeight={'500'}>Add recipient&#40;s&#41;</Typography>
                              </Box>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>USER</Typography>
                            <Divider />
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                height: '63vh',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                "&:hover": { backgroundColor: "#ede9e8" },
                                cursor: 'pointer',
                                p: '10px'
                              }}>
                                <Box
                                  sx={{
                                    display: 'flex',
                                    alignItems: 'center',
                                    gap: '10px',
                                  }}>
                                  <Box sx={{
                                    width: '28px',
                                    height: '25px',
                                    borderRadius: '50%',
                                    backgroundColor: '#E685B5',
                                    display: 'flex',
                                    justifyContent: 'center',
                                    alignItems: 'center'
                                  }}><Typography>A</Typography>
                                  </Box>
                                  <Typography fontSize={'12px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                </Box>
                                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                  <Typography sx={{ fontSize: '10px', backgroundColor: '#f7becf', color: 'red' }}>FACULTY</Typography>
                                  <Checkbox {...label} />
                                </Box>
                              </Box>
                            </Box>
                          </Box>
                        )}
                        {sidePage === "MaltipalbatchPage" && (
                          <Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              p: '10px 7px'
                            }}>
                              <ArrowBackIcon onClick={() => changePage("FrontsidePage")} />
                              <Box>
                                <Typography fontSize={'8px'} fontWeight={'500'}>Multipal batch accouncement</Typography>
                                <Typography fontSize={'13px'} fontWeight={'500'}>Select recipient&#40;s&#41;</Typography>
                              </Box>
                            </Box>
                            <Box sx={{
                              backgroundColor: '#F9FAFC',
                              border: '1px solid #F1F1F1',
                              py: '10px'
                            }}>
                              <Box
                                sx={{
                                  display: 'flex',
                                  border: '1px solid #F1F1F1',
                                  alignItems: 'center',
                                  backgroundColor: 'white',
                                  width: '90%',
                                  margin: 'auto',
                                  borderRadius: '5px',
                                  boxShadow: 'inset 0px 0px 7px -6px #000'
                                }}
                              >
                                <IconButton
                                  type="button"
                                  sx={{ p: "4px" }}
                                >
                                  <SearchIcon />
                                </IconButton>
                                <InputBase
                                  placeholder="Search by name or number"
                                  sx={{ ml: 1, flex: 1 }} />
                              </Box>
                            </Box>
                            <Typography fontSize={"11px"} fontWeight={'600'} m={1}>BATCHES</Typography>
                            <Divider />
                            <Box
                              sx={{
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                display: 'flex',
                                justifyContent: 'center',
                                alignItems: 'center',
                                height: '64.1vh',
                                flexDirection: 'column',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <img src={img} style={{ borderRadius: '50%', height: '125px', width: '125px', mixBlendMode: 'luminosity' }} />
                              <Typography>No matches Found</Typography>
                            </Box>
                          </Box>
                        )}
                      </Box>
                    </Grid>
                    <Grid item xs={6} sm={7} md={8} lg={8}>
                      <Box sx={{ border: '1px solid #F1F1F1', height: '100%' }}>
                        {currentPage === "FrontsidePage" && (
                          <Box sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: "100%"
                          }}>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'center',
                              alignItems: 'center',
                              width: '100px',
                              height: '100px',
                              borderRadius: '50%',
                              backgroundColor: '#F1F1F1'
                            }}>
                              <QuestionAnswerIcon />
                            </Box>
                            <h5>No conversation selected</h5>
                            <Typography fontSize={'10px'}>Select a conversation from the left panel</Typography>
                          </Box>
                        )}
                        {currentPage === "ConversationsidePage" && (
                          <Box sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            alignItems: 'center',
                            height: "100%"
                          }}>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'center',
                              alignItems: 'center',
                              width: '100px',
                              height: '100px',
                              borderRadius: '50%',
                              backgroundColor: '#F1F1F1'
                            }}>
                              <QuestionAnswerIcon />
                            </Box>
                            <h5>No conversation selected</h5>
                            <Typography fontSize={'10px'}>Select a conversation from the left panel</Typography>
                          </Box>
                        )}
                        {currentPage === "AIPoweredLeadPage" && (
                          <Box sx={{ width: '100%' }}>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '11px 10px'
                            }}>
                              <Box sx={{
                                display: 'flex',
                                gap: '5px',
                                alignItems: 'center'
                              }}>
                                <Box sx={{
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                  width: '35px',
                                  height: '35px',
                                  backgroundColor: '#E685B5',
                                  borderRadius: '50%',
                                }}>
                                  <Typography>A</Typography>
                                </Box>
                                <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads</Typography>
                              </Box>
                              <Box>
                                <MoreVertIcon />
                              </Box>
                            </Box>
                            <Divider />
                            <Box
                              sx={{
                                height: '69vh',
                                overflowY: 'scroll',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{ width: '100%', my: '5px' }}>
                                <Typography textAlign={'center'} fontSize={'10px'}>TODAY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                gap: '10px',
                                pl: '5px'
                              }}>
                                <Box sx={{
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                  width: { lg: '30px', md: '40px', sm: '70px', xs: '100px' },
                                  height: '25px',
                                  backgroundColor: '#E685B5',
                                  borderRadius: '50%'
                                }}>
                                  <Typography>A</Typography>
                                </Box>
                                <Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px',
                              p: '5px',
                            }}>
                              <GrAttachment fontSize={'20px'} />
                              <TextField
                                label="Write something here"
                                size="small"
                                fullWidth />
                              <SendIcon />
                            </Box>
                          </Box>
                        )}
                        {currentPage === "AIPoweredLead-ProPage" && (
                          <Box sx={{ width: '100%' }}>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '11px 10px'
                            }}>
                              <Box sx={{
                                display: 'flex',
                                gap: '5px',
                                alignItems: 'center'
                              }}>
                                <Box sx={{
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                  width: '35px',
                                  height: '35px',
                                  backgroundColor: '#E685B5',
                                  borderRadius: '50%'
                                }}>
                                  <Typography>A</Typography>
                                </Box>
                                <Typography fontSize={'15px'} fontWeight={'600'}>AI Powered Leads - Pro</Typography>
                              </Box>
                              <Box>
                                <MoreVertIcon />
                              </Box>
                            </Box>
                            <Divider />
                            <Box
                              sx={{
                                height: '69vh',
                                overflowY: 'scroll',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{ width: '100%', my: '5px' }}>
                                <Typography textAlign={'center'} fontSize={'10px'}>TODAY</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                gap: '10px',
                                pl: '5px'
                              }}>
                                <Box sx={{
                                  display: 'flex',
                                  justifyContent: 'center',
                                  alignItems: 'center',
                                  width: '30px',
                                  height: '25px',
                                  backgroundColor: '#E685B5',
                                  borderRadius: '50%'
                                }}>
                                  <Typography>A</Typography>
                                </Box>
                                <Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                  <Box sx={{
                                    backgroundColor: '#F1F1F1',
                                    borderRadius: '10px',
                                    width: { lg: '25%', md: '30%', xs: '70%', sm: '50%' },
                                    p: '10px',
                                    my: '3px'
                                  }}>
                                    <Typography fontSize={'11px'} fontWeight={'600'}>AI Powered Leads</Typography>
                                    <Typography fontSize={'10px'} fontWeight={'500'}>Leads - Pro: Your student Pushpendra Meena &#40;+918596749632&#41; showed intrest in the course "RPSC 1st & 2nd Grade SCHOOL Level" but didn't buy. Please follow up with him/her.</Typography>
                                    <Typography fontSize={'7px'} textAlign={'end'} my={'5px'}>06:10 pm</Typography>
                                  </Box>
                                </Box>
                              </Box>
                            </Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px',
                              p: '5px',
                            }}>
                              <GrAttachment fontSize={'20px'} />
                              <TextField
                                label="Write something here"
                                size="small"
                                fullWidth />
                              <SendIcon />
                            </Box>
                          </Box>
                        )}
                        {currentPage === "GroupchatsidePage" && (
                          <Box sx={{ width: '100%' }}>
                            <Box sx={{
                              display: 'flex',
                              justifyContent: 'space-between',
                              alignItems: 'center',
                              p: '11px 10px'
                            }}>
                              <Box sx={{
                                display: 'flex',
                                gap: '5px',
                                alignItems: 'center'
                              }}>
                                <img src={groupchatimg} width={'40px'} height={'40px'} style={{ borderRadius: '50%' }} />
                                <Typography fontSize={'15px'} fontWeight={'600'}>Enter group name &#40;required&#41;</Typography>
                              </Box>
                              <Button>CREATE</Button>
                            </Box>
                            <Divider />
                            <Box
                              sx={{
                                height: '69vh',
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{ width: '100%', m: '15px' }}>
                                <Typography fontSize={'10px'}>PARTICIPANTS</Typography>
                              </Box>
                              <Box sx={{
                                display: 'flex',
                                justifyContent: 'space-between',
                                alignItems: 'center',
                                p: '10px'
                              }}>
                                <Box sx={{
                                  display: 'flex',
                                  alignItems: 'center',
                                  gap: '10px',
                                  pl: '5px'
                                }}>
                                  <Avatar sx={{ bgcolor: deepOrange[500] }}>N</Avatar>
                                  <Typography>Nitesh Ji</Typography>
                                </Box>
                                <Typography sx={{ color: '#0ab804', backgroundColor: '#b7f7b5' }}>Admin</Typography>
                              </Box>
                            </Box>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px',
                              p: '5px',
                            }}>
                              <GrAttachment fontSize={'20px'} />
                              <TextField
                                label="Write something here"
                                size="small"
                                fullWidth />
                              <SendIcon />
                            </Box>
                          </Box>
                        )}
                        {currentPage === "MaltipalbatchPage" && (
                          <Box sx={{ width: '100%' }}>
                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              p: '11px 10px',
                              gap: '5px'
                            }}>
                              <img src={groupchatimg} width={'40px'} height={'40px'} style={{ borderRadius: '50%' }} />
                              <Typography fontSize={'15px'} fontWeight={'600'}>Multipal Batch Announcement</Typography>
                            </Box>
                            <Divider />
                            <Box
                              sx={{
                                height: '69vh',
                                overflowY: 'scroll',
                                overflowX: 'hidden',
                                "&::-webkit-scrollbar": {
                                  width: "0.4em",
                                },
                                "&::-webkit-scrollbar-track": {
                                  "-webkit-box-shadow": "inset 0 0 6px rgba(0,0,0,0.00)",
                                },
                                "&::-webkit-scrollbar-thumb": {
                                  backgroundColor: "rgba(0,0,0,.1)",
                                  borderRadius: "10px",
                                },
                              }}>
                              <Box sx={{ width: '100%', m: '15px' }}>
                                <Typography fontSize={'12px'}>To:</Typography>
                              </Box>
                              <Divider />
                              <Box sx={{ height: "88%", display: 'flex', justifyContent: 'end', alignItems: 'end' }}>
                                <Box sx={{ textAlign: "center", width: "fit-content" }} >
                                  <Checkbox {...label} />
                                  <Typography fontSize={'9px'}>Send SMS</Typography>
                                  <Typography fontSize={'20px'}>0</Typography>
                                </Box>
                              </Box>
                            </Box>

                            <Box sx={{
                              display: 'flex',
                              alignItems: 'center',
                              gap: '10px',
                              p: '5px',
                            }}>
                              <GrAttachment fontSize={'20px'} />
                              <TextField
                                label="Write something here"
                                size="small"
                                fullWidth />
                              <SendIcon />
                            </Box>

                          </Box>
                        )}
                      </Box>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
       
    </>
  );
};

export default Chat;