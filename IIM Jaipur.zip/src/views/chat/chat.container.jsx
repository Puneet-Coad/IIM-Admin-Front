import Chat from "./chat.component";
import { connect } from "react-redux";


const mapDispatchToProp = {};

const mapStateToProps = (state) => { };


export default connect(mapStateToProps, {})(Chat)