import React, { useState, useRef, } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import Link from "@mui/material/Link";
import Login from "../../assets/login-image.png";
import Logo from "../../assets/iim logo.jpg";
import { Container } from "@mui/material";
import TextField from "@mui/material/TextField";

const Otp = () => {
  const [isEmailLogin, setIsEmailLogin] = useState(false);

  const toggleLoginType = () => {
    setIsEmailLogin(!isEmailLogin);
  };
  const otp1Ref = useRef(null);
  const otp2Ref = useRef(null);
  const otp3Ref = useRef(null);
  const otp4Ref = useRef(null);

  const handleOnChange = (currentRef, nextRef, e) => {
    if (e.target.value.length === 1 && nextRef) {
      nextRef.focus();
    }

  };


  return (
    <>
      <Grid container>
        <Grid item xs={6}>
          <Box
            sx={{
              background: "#DA251C",
              padding: "25px",
              height: "92.2vh",
            }}
          >
            <Container maxWidth="sm" sx={{ margin: "50px auto" }}>
              <Box paddingX={"1rem"}>
                <img
                  src={Logo}
                  style={{
                    width: "30%",
                    aspectRatio: "7 /2",
                    objectFit: "cover",
                  }}
                  alt="logo"
                />
                <Typography
                  sx={{
                    color: "white",
                    fontSize: "35px",
                    fontWeight: "600",
                    margin: "15px auto",
                  }}
                >
                  Setup Your Website in Couple of Clicks
                </Typography>
                <Box textAlign={"center"} mt={3} sx={{ padding: "35px" }}>
                  <img
                    src={Login}
                    style={{ width: "90%" }}
                    alt="logo"
                  />
                </Box>
              </Box>
            </Container>
          </Box>
        </Grid>
        <Grid item xs={6} display={"flex"} alignItems={"center"}>
          <Grid container justifyContent="center">
            <Grid item xs={8}>
              <Box>
                <Typography
                  textAlign={"center"}
                  sx={{
                    fontSize: "20px",
                    fontWeight: "600",
                    margin: "20px auto",
                  }}
                >
                  Login to IIM
                </Typography>
                <Typography
                  sx={{
                    fontSize: "16px",
                    fontWeight: "500",
                    margin: "13px 13px",
                    color: "gray",
                  }}
                >
                  {isEmailLogin ? " Email" : " Mobile Number"}
                </Typography>
                <Box></Box>
                {isEmailLogin ? (
                  <Box sx={{ display: "flex", justifyContent: "center" }}>
                    <TextField
                      id="outlined-basic"
                      variant="outlined"
                      placeholder="Enter Your Email"
                      InputProps={{
                        sx: {
                          maxWidth: "470px",
                          borderRadius: 4,
                          boxShadow:
                            "rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px",
                        },
                      }}
                    />
                  </Box>
                ) : (
                  <Box display={"flex"} justifyContent={"space-around"}>
                    <TextField
                      style={{ background: "lightgray", borderRadius: "17px" }}
                      id="outlined-basic"
                      variant="outlined"
                      placeholder="+91"
                      inputProps={{ readOnly: true }}
                      InputProps={{
                        sx: {
                          width: "70px",
                          borderRadius: 4,
                        },
                      }}
                    />
                    <TextField
                      style={{ background: "lightgray", borderRadius: "17px" }}
                      id="outlined-basic"
                      variant="outlined"
                      placeholder="888888888"
                      inputProps={{ readOnly: true }}
                      InputProps={{
                        sx: {
                          width: "400px",
                          borderRadius: 4,
                          boxShadow:
                            "rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px",
                        },
                      }}
                    />
                  </Box>
                )}
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    marginTop: "15px",
                  }}
                >
                  {/* First OTP Input */}
                  <TextField style={{ marginRight: "10px" }}
                    inputRef={otp1Ref}
                    id="otp1"
                    variant="outlined"
                    onChange={(e) => handleOnChange(otp1Ref.current, otp2Ref.current, e)}
                    InputProps={{
                      sx: {
                        width: "70px",
                        borderRadius: 4,
                      },
                    }}
                    inputProps={{
                      maxLength: 1,
                      style: { textAlign: "center" }
                    }}
                  />
                  {/* Second OTP Input */}
                  <TextField style={{ marginRight: "10px" }}
                    inputRef={otp2Ref}
                    id="otp2"
                    variant="outlined"
                    onChange={(e) => handleOnChange(otp2Ref.current, otp3Ref.current, e)}
                    InputProps={{
                      sx: {
                        width: "70px",
                        borderRadius: 4,
                      },
                    }}
                    inputProps={{
                      maxLength: 1,
                      style: { textAlign: "center" }
                    }}
                  />
                  {/* Third OTP Input */}
                  <TextField style={{ marginRight: "10px" }}
                    inputRef={otp3Ref}
                    id="otp3"
                    variant="outlined"
                    onChange={(e) => handleOnChange(otp3Ref.current, otp4Ref.current, e)}
                    InputProps={{
                      sx: {
                        width: "70px",
                        borderRadius: 4,
                      },
                    }}
                    inputProps={{
                      maxLength: 1,
                      style: { textAlign: "center" }
                    }}
                  />
                  {/* Fourth OTP Input */}
                  <TextField
                    inputRef={otp4Ref}
                    id="otp4"
                    variant="outlined"
                    onChange={(e) => handleOnChange(otp4Ref.current, null, e)}
                    InputProps={{
                      sx: {
                        width: "70px",
                        borderRadius: 4,
                      },
                    }}
                    inputProps={{
                      maxLength: 1,
                      style: { textAlign: "center" }
                    }}
                  />
                </Box>
                <Box
                  display={"grid"}
                  justifyContent={"center"}
                  marginTop={"35px"}
                >
                  <Box sx={{ display: "flex", justifyContent: "center" }}>
                    <Button
                      variant="standard"
                      color="inherit"
                      sx={{
                        border: "1px solid #CDEAE9",
                        textTransform: "none",
                        borderRadius: "10px",
                        height: "50px",
                        background: "#da251c",
                        color: "white",
                        mr: 1,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        Width: "140px",
                        marginLeft: "5px",
                        "&:hover": {
                          backgroundColor: "#da251c",
                        },
                      }}
                    >
                      Login Now
                      <ArrowForwardIcon />
                    </Button>
                  </Box>

                  <Typography
                    textAlign={"center"}
                    sx={{ color: "gray" }}
                    mt={2}
                  >
                    Or
                  </Typography>
                  <Button
                    variant="text"
                    sx={{ color: "#da251c", textTransform: "none" }}
                    onClick={toggleLoginType}
                  >
                    Login via {isEmailLogin ? "Mobile Number" : "Email"}
                  </Button>
                </Box>
              </Box>

              <Typography color={"gray"} textAlign={"center"} mt={5}>
                by signing up, you agree to our{" "}
                <Link href="#" underline="none" fontWeight={"600"}>
                  {"T&C"}
                </Link>{" "}
                and{" "}
                <Link href="#" underline="none" fontWeight={"600"}>
                  {"Privacy Policy"}
                </Link>
              </Typography>
            </Grid>
          </Grid>
        </Grid>
      </Grid>
    </>
  );
};

export default Otp;
