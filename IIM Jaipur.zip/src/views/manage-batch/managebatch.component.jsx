import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import { IconButton } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { FormControl, InputBase, NativeSelect } from "@mui/material";
import Fade from "@mui/material/Fade";
import Paper from "@mui/material/Paper";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import Button from "@mui/material/Button";
import { MdOutlineFilterAlt } from "react-icons/md";
import { styled } from "@mui/material/styles";
import { CiMenuKebab } from "react-icons/ci";
import Navbar from "../../comon/navbar/navbar";

const ManageBatch = () => {
  const BootstrapInput = styled(InputBase)(({ theme }) => ({
    "& .MuiInputBase-input": {
      borderRadius: 4,
      backgroundColor: theme.palette.background.paper,
      border: "1px solid #ced4da",
      fontSize: 16,
      padding: "10px 26px 10px 12px",
      transition: theme.transitions.create(["border-color", "box-shadow"]),
      fontFamily: [
        "-apple-system",
        "BlinkMacSystemFont",
        '"Segoe UI"',
        "Roboto",
        '"Helvetica Neue"',
        "Arial",
        "sans-serif",
        '"Apple Color Emoji"',
        '"Segoe UI Emoji"',
        '"Segoe UI Symbol"',
      ].join(","),
      "&:focus": {
        borderRadius: 4,
        borderColor: "#80bdff",
        boxShadow: "0 0 0 0.2rem rgba(0,123,255,.25)",
      },
    },
  }));

  const [searchQuery, setSearchQuery] = useState("");
  const [age, setAge] = useState("");

  const handleSearch = () => {
    // Implement your search logic here
  };

  const handleChange1 = (event) => {
    setSearchQuery(event.target.value);
  };

  const handleChange = (event) => {
    setAge(event.target.value);
  };
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <>
       
          <Grid container>
            <Grid item xs={12}>
              <Navbar
                title=" Your Courses(157) "
                desc=" Add/View Courses of your brand "
                progressNum={78}
              />
            </Grid>

            <Grid container mt={0} spacing={2}>
              <Grid item xs={12}>
                <Grid
                  container
                  sx={{
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                  mt={4}
                >
                  <Grid item xs={7}>
                    <Box
                      sx={{
                        display: "flex",
                        justifyContent: "space-between",
                      }}
                    >
                      <Box>
                        <Box
                          component="form"
                          sx={{
                            p: "2px 4px",
                            display: "flex",
                            alignItems: "center",
                            width: "350px",
                             border: "1px solid #b4b4b4",
                            background: "white",
                            height: "42px",
                            borderRadius: "42px",
                          }}
                        >
                          <IconButton
                            type="button"
                            sx={{ p: "10px", height: "44.6px" }}
                            aria-label="search"
                            onClick={handleSearch}
                          >
                            <SearchIcon />
                          </IconButton>
                          <InputBase
                            sx={{ ml: 1, flex: 1 }}
                            placeholder="Search by name"
                            inputProps={{
                              "aria-label": "search google maps",
                            }}
                            onChange={handleChange1}
                            value={searchQuery}
                          />
                        </Box>
                      </Box>
                      <Box>
                        <FormControl variant="standard">
                          <NativeSelect
                            id="demo-customized-select-native"
                            value={age}
                            onChange={handleChange}
                            sx={{ height: "47.6px" }}
                            input={<BootstrapInput />}
                          >
                            <option value="">
                              <Typography sx={{ fontWeight: "600" }}>
                                Recently Created{" "}
                              </Typography>
                            </option>
                            <option value={10}>Ten</option>
                            <option value={20}>Twenty</option>
                            <option value={30}>Thirty</option>
                          </NativeSelect>
                        </FormControl>
                      </Box>
                      <Box>
                        <Button
                          sx={{
                            width: "120px",
                            background: "white",
                            textAlign: "center",
                            borderRadius: "42px",
                            padding: "10px",
                            color: "black",
                            textTransform: "none",
                            border: "1px solid #b4b4b4",
                            height: "47.6px",
                          }}
                        >
                          <MdOutlineFilterAlt />
                          Filter
                        </Button>
                      </Box>
                    </Box>
                  </Grid>
                  <Grid item xs={3} sx={{ textAlign: "end" }}>
                    {/* <Button
                  sx={{
                    background: "white",
                    padding: "10px",
                    borderRadius: "10px",
                    color: "#059FE3",
                    border: "2px solid #059FE3",
                    marginRight: "10px",
                  }}
                >
                  <FaRegStar />
                  Featured
                </Button> */}
                    <Button
                      sx={{
                        background: "#059FE3",
                        padding: "10px",
                        borderRadius: "10px",
                        color: "white",
                        "&:hover": {
                          background: "#007bb5", // Change background color on hover
                          textDecoration: "none", // Remove any default hover effects
                        },
                      }}
                    >
                      Create Courses
                    </Button>
                  </Grid>
                </Grid>{" "}
              </Grid>

              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        IIT JAM TEST SERIES
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        IIT JAM 2023
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        Mathematics{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Offline
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Recorded
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
Mathematics                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    15 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Live
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    41 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        B.Sc Second Year Real Analysis
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                   42 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                      B.Sc Third Year Abstract algebra
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
M.Sc Final Numerical Analysis
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                      M.Sc Final Functional Analysis
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
Functional Analysis                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Offline
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Offline
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Offline
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={4}>
                <Paper sx={{ padding: "15px", borderRadius: "20px" }}>
                  <Box
                    sx={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "baseline",
                    }}
                  >
                    <Box sx={{ width: "80%" }}>
                      <Typography sx={{ fontWeight: "600" }}>
                        CSIR NET DEC 22 Offline
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "500",
                          color: "gray",
                          fontSize: "12px",
                          margin: "10px auto",
                        }}
                      >
                        No Subjects{" "}
                      </Typography>
                    </Box>
                    <Button
                      id="fade-button"
                      aria-controls={open ? "fade-menu" : undefined}
                      aria-haspopup="true"
                      aria-expanded={open ? "true" : undefined}
                      onClick={handleClick}
                      sx={{ minWidth: "0px" }}
                    >
                      <CiMenuKebab style={{ color: "black" }} />
                    </Button>
                    <Menu
                      id="fade-menu"
                      MenuListProps={{
                        "aria-labelledby": "fade-button",
                      }}
                      anchorEl={anchorEl}
                      open={open}
                      onClose={handleClose}
                      TransitionComponent={Fade}
                    >
                      <MenuItem onClick={handleClose}>Profile</MenuItem>
                      <MenuItem onClick={handleClose}>My account</MenuItem>
                      <MenuItem onClick={handleClose}>Logout</MenuItem>
                    </Menu>
                  </Box>
                  <Box
                    marginTop={6}
                    sx={{
                      display: "flex",
                      fontSize: "12px",
                      fontWeight: "500",
                      color: "gray",
                      alignItems: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        color: "#45A1CD",
                        background: "#EFF4FB",
                        marginRight: "10px",
                        padding: "5px",
                        width: "10px",
                        textAlign: "center",
                        borderRadius: "20px",
                        height: "10px",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      +
                    </Typography>
                    1 Student
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
       
    </>
  );
};

export default ManageBatch;
