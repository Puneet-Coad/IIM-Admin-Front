import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import documentimg from "../../assets/docs.jpeg";
import ytimg from "../../assets/youtube.jpeg";
import alpimg from "../../assets/a-logo.jpeg";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import { FaArrowLeft } from "react-icons/fa";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
 
import Navbar from "../../comon/navbar/navbar";
import Footer from "../../components/footer";
import { useNavigate } from "react-router-dom";

const FreeMaterial = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [checked, setChecked] = useState(false);
  const navigate = useNavigate();

  const handleChangecheck = (event) => {
    setChecked(event.target.checked);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  return (
    <>
   
          <Grid container>
            <Grid item xs={12}>
              <Navbar />
            </Grid>

            <Grid container mt={0} spacing={2} position={"relative"}>
              <Grid item xs={12}>
                <Paper
                  elevation={0}
                  sx={{
                    borderRadius: "20px",
                    padding: "25px",
                    height: "83vh",
                    overflow: "overlay",
                    "&::-webkit-scrollbar": { display: "none" },
                  }}
                >
                  <Grid container spacing={5}>
                    <Grid item xs={4}>
                      <Box onClick={() => navigate("/create-free-document")}
                        sx={{
                          border: "2px solid #80808047",
                          padding: "20px",
                          borderRadius: "15px",
                        }}
                      >
                        <Box 
                          sx={{
                            background: "#F2F9FF",
                            justifyContent: "center",
                            display: "flex",
                            paddingY: "60px ",
                          }}
                        >
                          <img src={documentimg} style={{ width: "10%" }}></img>{" "}
                        </Box>
                        <Box textAlign={"center"}>
                          <Typography mt={2} sx={{ fontWeight: "600" }}>
                            Document
                          </Typography>
                          <Typography
                            sx={{
                              fontWeight: "600",
                              color: "gray",
                              fontSize: "13px",
                            }}
                          >
                            File type includes .doc. , .docx , .png , .jpg , etc
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                    <Grid item xs={4}>
                      <Box
                        sx={{
                          border: "2px solid #80808047",
                          padding: "20px",
                          borderRadius: "15px",
                        }}
                      >
                        <Box
                          sx={{
                            background: "#F2F9FF",
                            justifyContent: "center",
                            display: "flex",
                            paddingY: "60px ",
                          }}
                        >
                          <img src={ytimg} style={{ width: "10%" }}></img>{" "}
                        </Box>
                        <Box textAlign={"center"}>
                          <Typography mt={2} sx={{ fontWeight: "600" }}>
                            Video
                          </Typography>
                          <Typography
                            sx={{
                              fontWeight: "600",
                              color: "gray",
                              fontSize: "13px",
                            }}
                          >
                            Suppoprted link : Youtube URL
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                    <Grid item xs={4}>
                      <Box
                        sx={{
                          border: "2px solid #80808047",
                          padding: "20px",
                          borderRadius: "15px",
                        }}
                      >
                        <Box
                          sx={{
                            background: "#F2F9FF",
                            justifyContent: "center",
                            display: "flex",
                            paddingY: "60px ",
                          }}
                        >
                          <img src={alpimg} style={{ width: "10%" }}></img>{" "}
                        </Box>
                        <Box textAlign={"center"}>
                          <Typography mt={2} sx={{ fontWeight: "600" }}>
                            Test
                          </Typography>
                          <Typography
                            sx={{
                              fontWeight: "600",
                              color: "gray",
                              fontSize: "13px",
                            }}
                          >
                            Import from test from cms portal
                          </Typography>
                        </Box>
                      </Box>
                    </Grid>
                  </Grid>
                </Paper>
              </Grid>
            </Grid>
          </Grid>
      
    </>
  );
};

export default FreeMaterial;
