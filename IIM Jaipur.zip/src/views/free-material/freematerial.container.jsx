import FreeMaterial from "./freematerial.component";
import { connect } from "react-redux";


const mapDispatchToProp = {};

const mapStateToProps = (state) => { };


export default connect(mapStateToProps, {})(FreeMaterial)