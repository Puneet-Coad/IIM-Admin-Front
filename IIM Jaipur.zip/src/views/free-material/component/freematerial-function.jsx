import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import FolderIcon from '@mui/icons-material/Folder';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import CloudUploadIcon from '@mui/icons-material/CloudUpload';
import { styled } from '@mui/material/styles';
import Sidebar from "../../components/sidebar";
import Navbar from "../../components/navbar";
import Footer from "../../components/footer";
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import { Button, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, Divider, TextField } from "@mui/material";

const FreeDocument = () => {
    const [activeStep, setActiveStep] = useState(0);
    const [checked, setChecked] = useState(false);

    const handleChangecheck = (event) => {
        setChecked(event.target.checked);
    };

    const handleBack = () => {
        setActiveStep((prevActiveStep) => prevActiveStep - 1);
    };

    const handleNext = () => {
        setActiveStep((prevActiveStep) => prevActiveStep + 1);
    };
    const [open, setOpen] = React.useState(false);
    const [opendocument, setOpendocument] = React.useState(false);

    const handleClickFolder = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const handleClickDocument = () => {
        setOpendocument(true);
    }
    const handleClosedocument = () => {
        setOpendocument(false);
    };
    const VisuallyHiddenInput = styled('input')({
        clip: 'rect(0 0 0 0)',
        clipPath: 'inset(50%)',
        height: 1,
        overflow: 'hidden',
        position: 'absolute',
        bottom: 0,
        left: 0,
        whiteSpace: 'nowrap',
        width: 1,
    });
    const [folderData, setfolderData] = useState({ foldername: "", description: "" })
    const [allFolder, setallFolder] = useState([{foldername: "RPSC First & Second Grade Math ENGLISH Medium.", description: "IIM Jaipur"}])

    const makefolder = (e) => {
        setfolderData({ ...folderData, [e.target.name]: e.target.value })
    }
    const foldersubmit = () => {
        setfolderData({foldername:"",description:""})
        let localData = []
        localData = allFolder.concat(folderData)
        setallFolder(localData)
    }

    return (
        <>
            <Grid
                container
                spacing={2}
                sx={{
                    background: "#F3F6FD",
                    padding: "20px",
                    justifyContent: "space-evenly",
                }}
            >
                <Grid item xs={2}>
                    <Sidebar />
                </Grid>
                <Grid item xs={10}>
                    <Grid container>
                        <Grid item xs={12}>
                            <Navbar />
                        </Grid>

                        <Grid container mt={0} spacing={2} position={"relative"}>
                            <Grid item xs={12}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        borderRadius: "20px",
                                        padding: "25px",
                                        height: "83vh",
                                        overflow: "overlay",
                                        "&::-webkit-scrollbar": { display: "none" },
                                    }}
                                >
                                    <Grid container spacing={5}>
                                        <Grid item xs={8}>
                                            <Typography mb={'10px'} fontSize={"25px"} fontWeight={'600'}>Content</Typography>
                                            {allFolder.map((e) => {
                                                return (
                                                    <><Box sx={{
                                                        display: 'flex',
                                                        alignItems: 'center',
                                                        justifyContent: 'space-between',
                                                        p: '10px',
                                                        "&:hover": {
                                                            backgroundColor: '#bee7f7'
                                                        },
                                                        cursor: 'pointer'
                                                    }}>
                                                        <Box sx={{
                                                            display: 'flex',
                                                            alignItems: 'center',
                                                            gap: '5px'
                                                        }}>
                                                            <FolderIcon sx={{ height: '55px', width: '55px' }} color="primary" />
                                                            <Box>
                                                                <Typography fontSize={'18px'} fontWeight={"600"}>{e.foldername}</Typography>
                                                                <Typography fontSize={'10px'} fontWeight={"500"}>{e.description}</Typography>
                                                            </Box>
                                                        </Box>
                                                        <MoreVertIcon />
                                                    </Box>
                                                        <Divider />
                                                    </>
                                                )
                                            })}
                                        </Grid>
                                        <Grid item xs={4}>
                                            <Box sx={{
                                                border: '1px solid gray',
                                                borderRadius: '10px',
                                                padding: '30px 20px',
                                            }}>
                                                <Typography fontSize={"15px"} marginBottom={"10px"} fontWeight={"600"} mb={"10px"}>Select content to be added</Typography>
                                                <Button onClick={handleClickFolder} sx={{ display: 'flex', alignItems: 'center', gap: '5px', color: 'black', textTransform: 'none' }} fontSize={"15px"} my={"10px"} ><FolderIcon fontSize="small" color="primary" /> Folder</Button>
                                                <Dialog
                                                    open={open}
                                                    onClose={handleClose}
                                                    minWidth={"500px"}
                                                    PaperProps={{
                                                        component: 'form',
                                                        onSubmit: (event) => {
                                                            event.preventDefault();
                                                            const formData = new FormData(event.currentTarget);
                                                            const formJson = Object.fromEntries(formData.entries());
                                                            const email = formJson.email;
                                                            console.log(email);
                                                            handleClose();
                                                        },
                                                    }}
                                                >
                                                    <DialogTitle>New Folder</DialogTitle>
                                                    <DialogContent>
                                                        <TextField
                                                            value={folderData.foldername}
                                                            onChange={makefolder}
                                                            autoFocus
                                                            required
                                                            margin="dense"
                                                            id="foldername"
                                                            name="foldername"
                                                            label="Folder Name"
                                                            type="text"
                                                            fullWidth
                                                            variant="outlined"
                                                        />
                                                        <TextField
                                                            value={folderData.description}
                                                            onChange={makefolder}
                                                            autoFocus
                                                            required
                                                            margin="dense"
                                                            id="description"
                                                            name="description"
                                                            label="Description"
                                                            type="text"
                                                            fullWidth
                                                            variant="outlined"
                                                        />
                                                    </DialogContent>
                                                    <DialogActions>
                                                        <Button onClick={handleClose}>Cancel</Button>
                                                        <Button type="submit" onClick={foldersubmit}>Submit</Button>
                                                    </DialogActions>
                                                </Dialog>
                                                <Button onClick={handleClickDocument} sx={{ display: 'flex', alignItems: 'center', gap: '5px', color: 'black', textTransform: 'none' }} fontSize={"15px"} my={"10px"}><InsertDriveFileIcon fontSize="small" color="primary" /> Document</Button>
                                                <Dialog
                                                    open={opendocument}
                                                    onClose={handleClosedocument}
                                                    minWidth={"500px"}
                                                    PaperProps={{
                                                        component: 'form',
                                                        onSubmit: (event) => {
                                                            event.preventDefault();
                                                            const formData = new FormData(event.currentTarget);
                                                            const formJson = Object.fromEntries(formData.entries());
                                                            const email = formJson.email;
                                                            console.log(email);
                                                            handleClosedocument();
                                                        },
                                                    }}
                                                >
                                                    <DialogTitle>Upload Document</DialogTitle>
                                                    <Button
                                                        component="label"
                                                        role={undefined}
                                                        variant="outlined"
                                                        sx={{ mx: '15px', width: '500px' }}
                                                        tabIndex={-1}
                                                        startIcon={<CloudUploadIcon />}
                                                    >
                                                        Upload file
                                                        <VisuallyHiddenInput type="file" />
                                                    </Button>
                                                    <Typography textAlign={'center'} fontWeight={'500'} my={'10px'}>Select documents for upload</Typography>
                                                    <DialogActions>
                                                        <Button onClick={handleClosedocument}>Cancel</Button>
                                                        <Button type="submit">Submit</Button>
                                                    </DialogActions>
                                                </Dialog>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Paper>
                            </Grid>
                        </Grid>
                    </Grid>
                </Grid >
            </Grid >
        </>
    );
};

export default FreeDocument;
