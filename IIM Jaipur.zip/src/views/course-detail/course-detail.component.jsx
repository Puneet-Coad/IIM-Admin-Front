import React from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import { ImBullhorn } from "react-icons/im";
import Typography from "@mui/material/Typography";
import { FaCube } from "react-icons/fa6";
import { Link } from "react-router-dom";
import { Paper, Button } from "@mui/material";
import { FaVideo } from "react-icons/fa6";
import { HiDotsHorizontal } from "react-icons/hi";
import Course1 from "../../assets/course1 img.jpg";
import Navbar from "../../comon/navbar/navbar";
import { SiFiles } from "react-icons/si";
import Divider from "@mui/material/Divider";
import Footer from "../../components/footer";




const CourseDetail = () => {
    return (
        <>
                    <Grid container>
                        <Grid item xs={12}>
                            <Navbar
                                title=" Your Courses(157) "
                                desc=" Add/View Courses of your brand "
                                progressNum={78}
                            />
                        </Grid>

                        <Grid container mt={0} spacing={2} position={"relative"}>
                            <Grid item xs={9}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        borderRadius: "20px",
                                        padding: "25px",
                                        height: "70vh",
                                        overflow: "overlay",
                                        "&::-webkit-scrollbar": { display: "none" },
                                    }}
                                >
                                    <Grid container spacing={2} justifyContent={"space-between"}>
                                        <Grid item xs={5}>
                                            <Typography fontWeight={600}>Course Name</Typography>
                                            <Typography
                                                fontWeight={400}
                                                sx={{ fontSize: "13px", color: "gray" }}
                                            >
                                                Rajasthan State Eligibility Test(SET)Mathematics
                                            </Typography>
                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "20px auto",
                                                }}
                                            />
                                            <Typography fontWeight={600}>Description</Typography>
                                            <Typography
                                                fontWeight={400}
                                                sx={{ fontSize: "13px", color: "gray" }}
                                            >
                                                This Course Contains Video Lectures,assignments and test
                                                for SET mathematics exam
                                            </Typography>
                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "20px auto",
                                                }}
                                            />
                                            <Box
                                                sx={{
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                    width: "85%",
                                                }}
                                            >
                                                <Box>
                                                    <Typography fontWeight={600}>Price</Typography>
                                                    <Typography
                                                        fontWeight={500}
                                                        sx={{
                                                            fontSize: "13px",
                                                            color: "gray",
                                                            margin: "10px auto",
                                                        }}
                                                    >
                                                        ₹ 4000
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <Typography fontWeight={600}>Discount</Typography>
                                                    <Typography
                                                        fontWeight={500}
                                                        sx={{
                                                            fontSize: "13px",
                                                            color: "gray",
                                                            margin: "10px auto",
                                                        }}
                                                    >
                                                        ₹ 0
                                                    </Typography>
                                                </Box>
                                            </Box>
                                            <Typography
                                                sx={{
                                                    fontSize: "10px",
                                                    fontWeight: "600",
                                                    color: "gray",
                                                    margin: "10px auto",
                                                }}
                                            >
                                                Students can pay ₹14052.80 in 2 installments{" "}
                                                <span style={{ color: "blue", cursor: "pointer" }}>
                                                    View installments
                                                </span>
                                            </Typography>
                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "20px auto",
                                                }}
                                            />
                                            <Box
                                                sx={{
                                                    display: "flex",
                                                    justifyContent: "space-between",
                                                    width: "85%",
                                                }}
                                            >
                                                <Box>
                                                    <Typography fontWeight={600}>Category</Typography>
                                                    <Typography
                                                        fontWeight={500}
                                                        sx={{
                                                            fontSize: "13px",
                                                            color: "gray",
                                                            margin: "10px auto",
                                                        }}
                                                    >
                                                        Other State Exams
                                                    </Typography>
                                                </Box>
                                                <Box>
                                                    <Typography fontWeight={600}>SubCategory</Typography>
                                                    <Typography
                                                        fontWeight={500}
                                                        sx={{ fontSize: "13px", color: "gray" }}
                                                    ></Typography>
                                                </Box>
                                            </Box>

                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "12px auto",
                                                }}
                                            />
                                            <Typography f20tWeight={600}>
                                                Course Duration Type
                                            </Typography>
                                            <Typography
                                                fontWeight={400}
                                                sx={{ fontSize: "13px", color: "gray" }}
                                            >
                                                1Year(s)Duration
                                            </Typography>
                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "20px auto",
                                                }}
                                            />
                                            <Typography fontWeight={600}>
                                                Students Enrolled{" "}
                                                <Link
                                                    href="#"
                                                    underline="none"
                                                    ml={1}
                                                    sx={{ fontSize: "14px" }}
                                                >
                                                    {"View All"}
                                                </Link>
                                            </Typography>
                                            <Typography
                                                fontWeight={400}
                                                sx={{ fontSize: "13px", color: "gray" }}
                                            >
                                                14
                                            </Typography>
                                            <Divider
                                                sx={{
                                                    color: "#d1d1d1",
                                                    borderBottom: "dotted",
                                                    margin: "20px auto",
                                                }}
                                            />
                                        </Grid>
                                        <Grid item xs={5}>
                                            <Box>
                                                <img
                                                    src={Course1}
                                                    style={{
                                                        width: "100%",
                                                        borderRadius: "20PX",
                                                        height: "44vh",
                                                        objectFit: "cover",
                                                    }}
                                                ></img>
                                            </Box>
                                        </Grid>
                                    </Grid>
                                </Paper>
                            </Grid>
                            <Grid item xs={3}>
                                <Paper
                                    elevation={0}
                                    sx={{
                                        padding: "15px",
                                        textAlign: "center",
                                        borderRadius: "20px",
                                    }}
                                >
                                    <Button
                                        sx={{
                                            textTransform: "none",
                                            border: "1px solid #f0f0f0",
                                            borderRadius: "10px",
                                            margin: "5px auto",
                                            padding: "10px",
                                            width: "100%",
                                            "&:hover": {
                                                boxShadow: " rgba(0, 0, 0, 0.24) 0px 3px 8px;",
                                            },
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                display: "flex",
                                                alignItems: "center",
                                                width: "150px",
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                    background: "#D2F2FC",
                                                    padding: "7px",
                                                    borderRadius: "20px",
                                                    height: "13px",
                                                    display: "flex",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <SiFiles style={{ fontSize: "17px" }} />
                                            </Box>
                                            <Link
                                                to="/create-course"
                                                style={{ textDecoration: "none" }}
                                            >
                                                <Box sx={{ textAlign: "left", marginLeft: "10px" }}>
                                                    <Typography
                                                        sx={{
                                                            fontWeight: "700",
                                                            fontSize: "17px",
                                                            color: "black",
                                                            textDecoration: "none",
                                                        }}
                                                    >
                                                        Content
                                                    </Typography>{" "}
                                                    <Typography
                                                        sx={{
                                                            fontSize: "12px",
                                                            fontWeight: "500",
                                                            color: "text.secondary",
                                                        }}
                                                    >
                                                        {" "}
                                                        555 content
                                                    </Typography>
                                                </Box>
                                            </Link>
                                        </Box>
                                    </Button>
                                    <Button
                                        sx={{
                                            textTransform: "none",
                                            border: "1px solid #f0f0f0",
                                            borderRadius: "10px",
                                            margin: "5px auto",
                                            padding: "10px",
                                            width: "100%",
                                            "&:hover": {
                                                boxShadow: " rgba(0, 0, 0, 0.24) 0px 3px 8px;",
                                            },
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                display: "flex",
                                                alignItems: "center",
                                                width: "150px",
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                    background: "#D2F2FC",
                                                    padding: "7px",
                                                    borderRadius: "20px",
                                                    height: "13px",
                                                    display: "flex",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <FaVideo style={{ fontSize: "17px" }} />
                                            </Box>
                                            <Box sx={{ textAlign: "left", marginLeft: "10px" }}>
                                                <Typography
                                                    sx={{
                                                        fontWeight: "700",
                                                        fontSize: "17px",
                                                        color: "black",
                                                    }}
                                                >
                                                    Live Classes
                                                </Typography>{" "}
                                                <Typography
                                                    sx={{
                                                        fontSize: "12px",
                                                        fontWeight: "500",
                                                        color: "text.secondary",
                                                    }}
                                                >
                                                    {" "}
                                                    Live 5{" "}
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Button>
                                    <Button
                                        sx={{
                                            textTransform: "none",
                                            border: "1px solid #f0f0f0",
                                            borderRadius: "10px",
                                            margin: "10px auto",
                                            width: "100%",
                                            padding: "10px",
                                            "&:hover": {
                                                boxShadow: " rgba(0, 0, 0, 0.24) 0px 3px 8px;",
                                            },
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                display: "flex",
                                                alignItems: "center",
                                                width: "150px",
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                    background: "#D2F2FC",
                                                    padding: "7px",
                                                    borderRadius: "20px",
                                                    height: "13px",
                                                    display: "flex",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <ImBullhorn style={{ fontSize: "17px" }} />
                                            </Box>
                                            <Box sx={{ textAlign: "left", marginLeft: "10px" }}>
                                                <Typography
                                                    sx={{
                                                        fontWeight: "700",
                                                        fontSize: "17px",
                                                        color: "black",
                                                    }}
                                                >
                                                    Notice Board{" "}
                                                </Typography>{" "}
                                                <Typography
                                                    sx={{
                                                        fontSize: "12px",
                                                        fontWeight: "500",
                                                        color: "text.secondary",
                                                    }}
                                                >
                                                    {" "}
                                                    Creat5 a Notice
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Button>
                                    <Button
                                        sx={{
                                            textTransform: "none",
                                            border: "1px solid #f0f0f0",
                                            borderRadius: "10px",
                                            margin: "5px auto",
                                            padding: "10px",
                                            width: "100%",
                                            "&:hover": {
                                                boxShadow: " rgba(0, 0, 0, 0.24) 0px 3px 8px;",
                                            },
                                        }}
                                    >
                                        <Box
                                            sx={{
                                                display: "flex",
                                                alignItems: "center",
                                                width: "150px",
                                            }}
                                        >
                                            <Box
                                                sx={{
                                                    background: "#D2F2FC",
                                                    padding: "7px",
                                                    borderRadius: "20px",
                                                    height: "13px",
                                                    display: "flex",
                                                    alignItems: "center",
                                                }}
                                            >
                                                <FaCube style={{ fontSize: "17px" }} />
                                            </Box>
                                            <Box sx={{ textAlign: "left", marginLeft: "10px" }}>
                                                <Typography
                                                    sx={{
                                                        fontWeight: "700",
                                                        fontSize: "17px",
                                                        color: "black",
                                                    }}
                                                >
                                                    Bundles{" "}
                                                </Typography>{" "}
                                                <Typography
                                                    sx={{
                                                        fontSize: "12px",
                                                        fontWeight: "500",
                                                        color: "text.secondary",
                                                    }}
                                                >
                                                    {" "}
                                                    Create Bundle and Earn More
                                                </Typography>
                                            </Box>
                                        </Box>
                                    </Button>
                                    <Button
                                        variant="outlined"
                                        sx={{
                                            border: "1px solid #CDEAE9",
                                            textTransform: "none",
                                            borderRadius: "10px",
                                            width: "100%",
                                            margin: "10px auto ",
                                            height: "50px",
                                        }}
                                    >
                                        <HiDotsHorizontal />
                                        More Options
                                    </Button>
                                    <Button
                                        variant="contained"
                                        sx={{
                                            background: "#0387C0",
                                            textTransform: "none",
                                            width: "100%",
                                            height: "50px",
                                            borderRadius: "10px",
                                        }}
                                    >
                                        Publish Course
                                    </Button>
                                </Paper>
                            </Grid>

                            <Footer />
                        </Grid>
                    </Grid>
                 
        </>
    );
};

export default CourseDetail;
