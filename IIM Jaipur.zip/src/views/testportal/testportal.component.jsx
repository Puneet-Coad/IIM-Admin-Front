import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import Autocomplete from "@mui/material/Autocomplete";

import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";

import Menu from "@mui/material/Menu";

import MenuItem from "@mui/material/MenuItem";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import { FaFolderClosed } from "react-icons/fa6";
import { FaFileAlt } from "react-icons/fa";
import { AiTwotoneSetting } from "react-icons/ai";

import { styled, alpha } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import SearchIcon from "@mui/icons-material/Search";

import { TiPlusOutline } from "react-icons/ti";
import { FaArrowLeft } from "react-icons/fa";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import Backdrop from "@mui/material/Backdrop";
import Modal from "@mui/material/Modal";
import Fade from "@mui/material/Fade";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import Link from "@mui/material/Link";
import Divider from "@mui/material/Divider";
import Createtestform from './components/testportaldialog'
import Sidebar from "../../components/sidebar";
import Navbar from "../../comon/navbar/navbar";



function handleClick(event) {
  event.preventDefault();
  console.info("You clicked a breadcrumb.");
}

const Testportal = () => {
  const [dialogOpen, setDialogOpen] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const [checked, setChecked] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [showFolderContent, setShowFolderContent] = useState(false);

  const handleChangeCheck = (event) => {
    setChecked(event.target.checked);
  };
  const [isHovered, setIsHovered] = useState(false);

  const handleBack = () => {
    setShowFolderContent(false);
  };

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const [value, setValue] = React.useState([]);
  const handleMenuClose = () => { };
  const [anchorElnew, setAnchorElnew] = useState(null);

  const handleClicknew = (event) => {
    setAnchorElnew(event.currentTarget);
  };

  const handleClosenew = () => {
    setAnchorElnew(null);
  };
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    boxShadow: 24,
    p: 1,
  };

  const [open, setOpen] = React.useState(false);

  const handleOpentest = () => {
    setOpen(true);
    handleClosenew(); // Close the menu when opening the modal
  };

  const handleClosetest = () => {
    setOpen(false);
  };
  const Search = styled("div")(({ theme }) => ({
    position: "relative",
    borderRadius: theme.shape.borderRadius,
    backgroundColor: alpha(theme.palette.common.white, 0.15),
    "&:hover": {
      backgroundColor: alpha(theme.palette.common.white, 0.25),
    },
    marginLeft: 0,
    width: "100%",
  }));

  const SearchIconWrapper = styled("div")(({ theme }) => ({
    padding: theme.spacing(0, 2),
    height: "100%",
    position: "absolute",
    pointerEvents: "none",
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
  }));

  const StyledInputBase = styled(InputBase)(({ theme }) => ({
    color: "inherit",
    width: "100%",
    "& .MuiInputBase-input": {
      padding: theme.spacing(1, 1, 1, 0),
      // vertical padding + font size from searchIcon
      paddingLeft: `calc(1em + ${theme.spacing(4)})`,
    },
  }));
  // Top 100 films as rated by IMDb users. http://www.imdb.com/chart/top
  const top100Films = [
    { title: "The Shawshank Redemption", year: 1994 },
    { title: "The Godfather", year: 1972 },
    { title: "The Godfather: Part II", year: 1974 },
    { title: "The Dark Knight", year: 2008 },
    { title: "12 Angry Men", year: 1957 },
    // Add 5 more sample movie data
    { title: "The Avengers", year: 2012 },
    { title: "Inception", year: 2010 },
    { title: "The Matrix", year: 1999 },
    { title: "Titanic", year: 1997 },
    { title: "Jurassic Park", year: 1993 },
  ];
  const options = ["Edit", "Update", "Delete"];
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  const breadcrumbs = [
    <Link
      underline="hover"
      key="1"
      color="inherit"
      href="/"
      onClick={handleClick}
    >
      MUI
    </Link>,
    <Link
      underline="hover"
      key="2"
      color="inherit"
      href="/material-ui/getting-started/installation/"
      onClick={handleClick}
    >
      Core
    </Link>,
    <Typography key="3" color="text.primary">
      Breadcrumb
    </Typography>,
  ];
  const FolderContent = () => {
    return (
      <Box>
        <Createtestform
          open={dialogOpen}
          onClose={() => { setDialogOpen(false) }}

        />
        <Paper elevation={0}>
          <Box sx={{ display: "flex", alignItems: "center" }}>
            <Checkbox {...label} />
            <Typography sx={{ fontWeight: "600" }}>Test(2)</Typography>
          </Box>

          <Divider sx={{ margin: "15px auto" }} />
        </Paper>
        <Paper
          elevation={0}
          sx={{ background: "#F4F3F4", padding: "20px", height: "70px" }}
        >
          <Grid container>
            <Grid
              item
              xs={0.5}
              style={{
                display: "flex",
                margin: "10px 0px ",
                alignItems: "flex-start",
              }}
            >
              <FaFileAlt style={{ color: "#008CBE", fontSize: "25px" }} />
            </Grid>
            <Grid item xs={9}>
              <Typography
                sx={{
                  fontSize: "15px",
                  padding: "5px",
                  fontWeight: "600",
                  display: "grid",
                  height: "100%",
                  ".regular": {
                    display: isHovered ? "none" : "flex",
                    color: "gray",
                  },
                  ".hover": {
                    display: isHovered ? "flex" : "none",
                  },
                }}
                onMouseEnter={() => setIsHovered(true)}
                onMouseLeave={() => setIsHovered(false)}
              >
                B-08 TEST-01 SET&RELATION
                <span className="regular">First Grade,Second Grade</span>
                <span className="hover">
                  <Link
                    href="#"
                    underline="hover"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    {"Copy test"}
                  </Link>{" "}
                  <Divider
                    orientation="vertical"
                    variant="middle"
                    flexItem
                    sx={{
                      width: "0.5px",
                      background: "blue",
                      margin: "10px 10px",
                      height: "12px",
                    }}
                  />
                  <Link
                    href="#"
                    underline="hover"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    {"Move to Folder"}
                  </Link>{" "}
                  <Divider
                    orientation="vertical"
                    variant="middle"
                    flexItem
                    sx={{
                      width: "0.5px",
                      background: "blue",
                      margin: "10px 10px",
                      height: "12px",
                    }}
                  />
                  <Link
                    href="#"
                    underline="hover"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    {"Export PDF"}
                  </Link>{" "}
                  <Divider
                    orientation="vertical"
                    variant="middle"
                    flexItem
                    sx={{
                      width: "0.5px",
                      background: "blue",
                      margin: "10px 10px",
                      height: "12px",
                    }}
                  />
                  <Link
                    href="#"
                    underline="hover"
                    sx={{ display: "flex", alignItems: "center" }}
                  >
                    {"Add to free Test"}
                  </Link>{" "}
                </span>
              </Typography>
            </Grid>
            <Grid item xs={1.2}>
              <Button
                variant="contained"
                sx={{ fontSize: "10px", padding: "5px", fontWeight: "600" }}
              >
                Test attempted
              </Button>
            </Grid>
            <Grid
              item
              xs={1}
              sx={{ fontSize: "13px", padding: "5px", fontWeight: "600" }}
            >
              2024/01/04
            </Grid>
          </Grid>
        </Paper>
      </Box>
    );
  };

  return (
     
      <Box>
        <Navbar
          title=" Your Courses(157) "
          desc=" Add/View Courses of your brand "
          progressNum={78}
        />
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Paper
              elevation={0}
              sx={{
                padding: "25px",
                height: "calc(100vh - 108px)",
                overflow: "auto",
              }}
            >
              {showFolderContent && (
                <>
                  <Grid container alignItems={"center"} marginBottom={"30px"}>
                    <Grid item xs={0.5}>
                      <IconButton aria-label="back" onClick={handleBack}>
                        <FaArrowLeft />
                      </IconButton>
                    </Grid>
                    <Grid item xs={2.5}>
                      {" "}
                      <Breadcrumbs
                        separator={<NavigateNextIcon fontSize="small" />}
                        aria-label="breadcrumb"
                      >
                        {breadcrumbs}
                      </Breadcrumbs>
                    </Grid>
                    <Grid item xs={1.2}></Grid>
                    <Grid item xs={4}>
                      <Box
                        sx={{
                          background: "#F4F3F4",
                          border: "2px solid #e6e6e6",
                          borderRadius: "5px",
                        }}
                      >
                        <Search>
                          <SearchIconWrapper>
                            <SearchIcon />
                          </SearchIconWrapper>
                          <StyledInputBase
                            placeholder="Search…"
                            inputProps={{ "aria-label": "search" }}
                          />
                        </Search>
                      </Box>
                    </Grid>
                    <Grid item xs={1.2}>
                      <Box sx={{ textAlign: "center", color: "black" }}>
                        <Button
                          startIcon={<AiTwotoneSetting />}
                          sx={{
                            color: "gray",
                            background: "#F4F3F4",
                            border: "2px solid #e6e6e6",
                            textTransform: "none",
                          }}
                        >
                          Settings
                        </Button>
                      </Box>
                    </Grid>
                    <Grid item xs={1.3}>
                      <Box sx={{ textAlign: "center", color: "black" }}>
                        <Button
                          startIcon={<AiTwotoneSetting />}
                          sx={{
                            color: "gray",
                            background: "#F4F3F4",
                            border: "2px solid #e6e6e6",
                            textTransform: "none",
                          }}
                        >
                          Sort/Filter
                        </Button>
                      </Box>
                    </Grid>
                    <Grid item xs={1.3}>
                      <Box sx={{ textAlign: "center", color: "black" }}>
                        <Button
                          onClick={(event) => {
                            anchorElnew !== null
                              ? handleClosenew()
                              : handleClicknew(event);
                          }}
                          style={{ padding: "0px", color: "white" }}
                          startIcon={
                            <IconButton>
                              <TiPlusOutline
                                style={{ color: "white", padding: "0px" }}
                              />
                            </IconButton>
                          }
                          sx={{
                            color: "white",
                            background: "#0191DA",
                            border: "2px solid #e6e6e6",
                            textTransform: "none",
                            width: "80%",
                            "&:hover": {
                              bgcolor: "#0191DA",
                            },
                          }}
                        >
                          New
                        </Button>
                        <Menu
                          anchorEl={anchorElnew}
                          open={Boolean(anchorElnew) && !open}
                          onClose={handleClosenew}
                          PaperProps={{
                            elevation: 0,
                            sx: {
                              overflow: "visible",
                              "& .MuiMenuItem-root": {
                                py: 2,
                              },
                            },
                          }}
                        >
                          <MenuItem onClick={handleOpentest}>
                            <Typography
                              sx={{ fontSize: "15px", fontWeight: "600" }}
                            >
                              Test
                            </Typography>
                          </MenuItem>
                          <MenuItem onClick={handleClosenew}>
                            <Typography
                              sx={{ fontSize: "15px", fontWeight: "600" }}
                            >
                              Folder
                            </Typography>
                          </MenuItem>
                        </Menu>
                        <Modal
                          aria-labelledby="transition-modal-title"
                          aria-describedby="transition-modal-description"
                          open={open}
                          onClose={handleClosetest}
                          closeAfterTransition
                          BackdropComponent={Backdrop}
                          BackdropProps={{ timeout: 500 }}
                        >
                          <Fade in={open}>
                            <Box sx={style}>
                              <Typography
                                id="transition-modal-title"
                                sx={{
                                  fontSize: "15px",
                                  fontWeight: "500",
                                  margin: "10px auto",
                                }}
                              >
                                Create New Test{" "}
                              </Typography>
                              <Divider />
                              <FormControl style={{ width: "100%" }}>
                                <Typography
                                  variant="subtitle1"
                                  sx={{
                                    fontWeight: "700",
                                    fontSize: "13px",
                                    marginTop: "20px",
                                  }}
                                  gutterBottom
                                >
                                  Name{" "}
                                </Typography>
                                <TextField
                                  style={{
                                    borderRadius: "12px",
                                    border: "1px solid #e1e1e1",
                                    padding: "5px 15px",
                                  }}
                                  sx={{
                                    transition: "0.3s ease-in-out",
                                    "&:hover": {
                                      boxShadow:
                                        " rgba(50, 50, 93, 0.25) 0px 6px 12px -2px, rgba(0, 0, 0, 0.3) 0px 3px 7px -3px",
                                    },
                                  }}
                                  size="small"
                                  variant="standard"
                                  placeholder="e.g General Knowledge (Minimum 3 Characters)"
                                  InputProps={{
                                    disableUnderline: true,
                                    style: {
                                      fontSize: "15px",
                                      fontWeight: "500",
                                    },
                                  }}
                                />
                              </FormControl>
                              <FormControl style={{ width: "100%" }}>
                                <Typography
                                  variant="subtitle1"
                                  sx={{
                                    fontWeight: "700",
                                    fontSize: "13px",
                                    marginTop: "20px",
                                  }}
                                  gutterBottom
                                >
                                  Tags{" "}
                                </Typography>
                                <Autocomplete
                                  multiple
                                  id="tags-outlined"
                                  options={top100Films}
                                  getOptionLabel={(option) => option.title}
                                  value={value}
                                  onChange={(event, newValue) => {
                                    setValue(newValue);
                                  }}
                                  filterSelectedOptions
                                  renderInput={(params) => (
                                    <TextField
                                      {...params}
                                      placeholder="Select"
                                    />
                                  )}
                                  sx={{ minWidth: 200, maxWidth: 500 }}
                                />

                              </FormControl>
                              <Box
                                sx={{ textAlign: "right", margin: "10px auto" }}
                              >
                                <Button onClick={() => setDialogOpen(true)} variant="contained">Create test</Button>
                              </Box>
                            </Box>
                          </Fade>
                        </Modal>
                      </Box>
                    </Grid>
                  </Grid>
                </>
              )}
              <Grid container spacing={2} alignItems="center">
                {!showFolderContent && (
                  <>
                    <Grid item xs={0.5}></Grid>
                    <Grid item xs={8}>
                      <Typography sx={{ fontWeight: "700", fontSize: "17px" }}>
                        Test/Portal
                      </Typography>
                    </Grid>
                    <Grid item xs={2}>
                      <Typography
                        variant="subtitle1"
                        sx={{ fontWeight: "600" }}
                      >
                        Date{" "}
                      </Typography>
                    </Grid>
                    <Grid item xs={1}>
                      <Typography
                        variant="subtitle1"
                        sx={{ fontWeight: "600" }}
                      >
                        Options{" "}
                      </Typography>{" "}
                    </Grid>
                    <Grid item xs={12}>
                      <Divider />
                    </Grid>
                  </>
                )}
              </Grid>

              {!showFolderContent && (
                <Box
                  sx={{
                    margin: "10px auto",
                  }}
                >
                  <Grid container>
                    <Grid item xs={0.5}>
                      <Checkbox />
                    </Grid>
                    <Grid
                      item
                      xs={8}
                      sx={{ display: "flex", alignItems: "center" }}
                      onClick={() => setShowFolderContent(true)}
                      style={{ cursor: "pointer" }}
                    >
                      <Box
                        display="flex"
                        alignItems="center"
                        sx={{ maxHeight: "40px" }}
                      >
                        <FaFolderClosed
                          style={{
                            color: "#069DE5",
                            marginRight: "10px",
                            fontSize: "25px",
                          }}
                        />
                        <Typography
                          variant="subtitle1"
                          sx={{ fontWeight: "600" }}
                        >
                          BB 2024
                        </Typography>
                      </Box>
                    </Grid>
                    <Grid
                      item
                      xs={2}
                      sx={{ display: "flex", alignItems: "center" }}
                    >
                      <Typography
                        variant="subtitle1"
                        sx={{ fontWeight: "600" }}
                      >
                        24 Jan-2024
                      </Typography>
                    </Grid>
                    <Grid
                      item
                      xs={1}
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <IconButton
                        aria-label="more"
                        onClick={handleMenuOpen}
                        disabled={showFolderContent}
                      >
                        <MoreVertIcon />
                      </IconButton>
                      <Menu
                        id="long-menu"
                        anchorEl={anchorEl}
                        open={Boolean(anchorEl)}
                        onClose={handleMenuClose}
                      >
                        {options.map((option) => (
                          <MenuItem key={option} onClick={handleMenuClose}>
                            {option}
                          </MenuItem>
                        ))}
                      </Menu>
                    </Grid>
                  </Grid>
                </Box>
              )}

              {showFolderContent && (
                <Box sx={{ paddingLeft: "40px" }}>
                  <FolderContent />
                </Box>
              )}
            </Paper>
          </Grid>
        </Grid>
      </Box>
    
  );
};

export default Testportal;
