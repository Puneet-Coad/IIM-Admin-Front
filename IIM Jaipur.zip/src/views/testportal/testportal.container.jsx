import Testportal from "./testportal.component";
import { connect } from "react-redux";



const mapDispatchToProp ={};

const mapStateToProps =(state)=>{}


export default connect(mapStateToProps, {})(Testportal);