import * as React from "react";
import Button from "@mui/material/Button";
import Grid from "@mui/material/Grid";
import Dialog from "@mui/material/Dialog";
import ListItemText from "@mui/material/ListItemText";
import ListItemButton from "@mui/material/ListItemButton";
import List from "@mui/material/List";
import Divider from "@mui/material/Divider";
import AppBar from "@mui/material/AppBar";
import Switch from "@mui/material/Switch";
import Box from "@mui/material/Box";

import Toolbar from "@mui/material/Toolbar";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";

import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import ListSubheader from "@mui/material/ListSubheader";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import Slide from "@mui/material/Slide";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import { IoMdPricetag } from "react-icons/io";
import { CiGift } from "react-icons/ci";
import { IoMdArrowRoundBack } from "react-icons/io";

import { MdEdit } from "react-icons/md";
import { FaGraduationCap } from "react-icons/fa";
import TextField from "@mui/material/TextField";
import { IoIosInformationCircleOutline } from "react-icons/io";
import Badge from "@mui/material/Badge";
import Checkbox from "@mui/material/Checkbox";
import { CiGrid42 } from "react-icons/ci";
import { FaRegClock } from "react-icons/fa";
import Accordion from "@mui/material/Accordion";
import { IoMdSettings } from "react-icons/io";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { FaRegQuestionCircle } from "react-icons/fa";
import Advancesetting from "./advanced-setting-dialog";
import { MdOutlineFileDownload } from "react-icons/md";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

export default function FullScreenDialog() {
  const [open, setOpen] = React.useState(false);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  const label = { inputProps: { "aria-label": "Checkbox demo" } };
  const [checked, setChecked] = React.useState(true);

  const handleChange = (event) => {
    setChecked(event.target.checked);
  };
  return (
    <React.Fragment>
      <Button
        onClick={(event) => {
          handleClickOpen(event);
        }}
        sx={{
          textTransform: "none",
          fontSize: "10px",
          fontWeight: "700",
        }}
      >
        Advanced settings
      </Button>

      <Dialog
        fullScreen
        open={open}
        onClose={handleClose}
        TransitionComponent={Transition}
      >
        <Box sx={{ background: "#F4F3F4" }}>
          <AppBar sx={{ position: "relative" }}>
            <Toolbar sx={{ background: "white", color: "black" }}>
              <Grid container alignItems={"center"}>
                <Grid item xs={0.5}></Grid>
                <Grid item xs={1}>
                  {" "}
                  <Typography
                    sx={{ ml: 2, flex: 1 }}
                    variant="h6"
                    component="div"
                  >
                    Logo
                  </Typography>
                </Grid>
                <Grid item xs={1}>
                  {" "}
                  <Box
                    sx={{
                      textAlign: "center",
                      height: "65px",
                      display: "grid",
                      alignItems: "center",
                      background: "#F6FAFC",
                    }}
                  >
                    <Typography sx={{ color: "blue", fontWeight: "600" }}>
                      My Library
                    </Typography>
                  </Box>
                  <Divider sx={{ color: "blue", borderBottom: "3px solid" }} />
                </Grid>
                <Grid item xs={4}></Grid>
                <Grid item xs={1}>
                  <Box
                    sx={{
                      height: "65px",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      textAlign: "center",
                    }}
                  >
                    <Typography
                      sx={{
                        fontSize: "15px",
                        fontWeight: "500",
                        color: "gray",
                        display: "grid",
                        textAlign: "center",
                        alignItems: "center",
                        marginBottom: "14px",
                      }}
                    >
                      <span
                        style={{
                          background: "red",
                          width: "fit-content",
                          display: "flex",
                          margin: "auto",
                          fontSize: "10px",
                          color: "white",
                        }}
                      >
                        NEW
                      </span>
                      Bulk Upload
                    </Typography>
                  </Box>
                </Grid>
                <Grid item xs={1.5}>
                  <Badge color="error" badgeContent={99}>
                    {" "}
                    <Typography
                      sx={{
                        fontSize: "15px",
                        fontWeight: "600",
                        color: "#CD1832",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                      }}
                    >
                      <IoIosInformationCircleOutline
                        style={{ marginRight: "2px", fontSize: "20px" }}
                      />
                      Report Dashboard
                    </Typography>
                  </Badge>
                </Grid>
                <Grid item xs={1}>
                  <Typography
                    sx={{
                      fontSize: "15px",
                      fontWeight: "600",
                      color: "gray",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <CiGift style={{ marginRight: "2px", fontSize: "20px" }} />
                    Whats new
                  </Typography>{" "}
                </Grid>
                <Grid item xs={1}>
                  <Typography
                    sx={{
                      fontSize: "15px",
                      fontWeight: "600",
                      color: "gray",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <FaRegQuestionCircle
                      style={{ marginRight: "2px", fontSize: "20px" }}
                    />
                    Help Videos
                  </Typography>{" "}
                </Grid>
                <Grid item xs={1}>
                  <Typography sx={{}}>Profile</Typography>
                </Grid>
              </Grid>
            </Toolbar>
          </AppBar>
          <Grid container>
            <Grid item xs={8} sx={{ margin: "10px auto" }}>
              <Paper elevation={0} sx={{ width: "100%", padding: "10px" }}>
                <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                  <Typography
                    sx={{
                      fontSize: "18px",
                      fontWeight: "600",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <IconButton
                      edge="start"
                      color="inherit"
                      onClick={handleClose}
                      aria-label="close"
                    >
                      <IoMdArrowRoundBack />
                    </IconButton>{" "}
                    Test Settings{" "}
                    <span
                      style={{
                        background: "red",
                        width: "fit-content",
                        padding: "5px",
                        fontSize: "10px",
                        color: "white",
                        marginLeft: "5px",
                      }}
                    >
                      NEW
                    </span>
                  </Typography>

                  <Box sx={{ display: "flex", alignItems: "center" }}>
                    <Typography
                      sx={{
                        fontSize: "12px",
                        marginRight: "5px",
                        fontWeight: "600",
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      <Checkbox {...label} />
                      Set as default
                    </Typography>
                    <Button
                      variant="contained"
                      sx={{
                        background: "#0087ED",
                        textTransform: "none",
                        borderRadius: "5px",
                        padding: "5px",
                        fontSize: "10px",
                        height: "30px",
                      }}
                    >
                      Save Settings
                    </Button>
                  </Box>
                </Box>
                <Divider sx={{ margin: "10px auto" }} />
                <Box sx={{ padding: "10px" }}>
                  <Typography sx={{ color: "gray", fontSize: "14px" }}>
                    TEST
                  </Typography>
                  <Typography sx={{ fontWeight: "600" }}>
                    JAM 24 TS:Full Length Test 1
                  </Typography>
                </Box>
                <Box sx={{ display: "flex", alignItems: "center" }}>
                  <Typography
                    sx={{
                      background: "#0091EB",
                      padding: "6px",
                      borderRadius: "100px",
                      height: "6px",
                      width: "fit-content",
                      display: "flex",
                      alignItems: "center",
                      color: "white",
                      fontSize: "12px",
                    }}
                  >
                    1
                  </Typography>
                  <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                    Order
                  </Typography>
                </Box>

                <Divider sx={{ margin: "10px auto" }} />
                <Box display={"flex"} alignItems={"center"}>
                  <Typography
                    sx={{
                      color: "gray",
                      fontWeight: "500",
                      marginRight: "10px",
                    }}
                  >
                    Order of Questions:
                  </Typography>

                  <FormControl sx={{ m: 1, minWidth: 200 }}>
                    <Select
                      native
                      defaultValue=""
                      id="grouped-native-select"
                      size="small"
                      sx={{
                        borderRadius: "10px",
                        boxShadow:
                          "inset 0 0 35px 5px rgba(0,0,0,0.25), inset 0 2px 1px 1px rgba(255,255,255,0.9), inset 0 -2px 1px rgba(0,0,0,0.25)",
                      }}
                    >
                      <option aria-label="None" value="None" />
                      <option value={1}>Option 1</option>
                      <option value={2}>Option 2</option>
                      <option value={3}>Option 3</option>
                      <option value={4}>Option 4</option>
                    </Select>
                  </FormControl>
                </Box>

                <Box sx={{ display: "flex", alignItems: "center" }} mt={5}>
                  <Typography
                    sx={{
                      background: "#0091EB",
                      padding: "6px",
                      borderRadius: "100px",
                      height: "6px",
                      width: "fit-content",
                      display: "flex",
                      alignItems: "center",
                      color: "white",
                      fontSize: "12px",
                    }}
                  >
                    2
                  </Typography>
                  <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                    Customize Result
                  </Typography>
                </Box>
                <Divider sx={{ margin: "10px auto" }} />
                <Box display={"flex"} justifyContent={"space-between"}>
                  <Box>
                    <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                      Generate Rank
                    </Typography>
                    <Typography
                      sx={{
                        fontWeight: 500,
                        marginLeft: "15px",
                        fontSize: "12px",
                      }}
                    >
                      Your student will get a rank based ion their performance
                    </Typography>
                  </Box>
                  <Box>
                    <Switch
                      sx={{ color: "pink" }}
                      checked={checked}
                      onChange={handleChange}
                      inputProps={{ "aria-label": "controlled" }}
                    />
                  </Box>
                </Box>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "end",
                    margin: "12px auto",
                  }}
                >
                  <Checkbox {...label} />
                  <Typography
                    sx={{
                      fontSize: "12px",
                      marginRight: "5px",
                      fontWeight: "600",
                      display: "grid",
                      alignItems: "baseline",
                    }}
                  >
                    Batch Test Rank
                    <span>
                      Batch test rank is generated once the tst is assigned to
                      batch
                    </span>
                  </Typography>
                </Box>

                <Box
                  sx={{
                    display: "flex",
                    alignItems: "end",
                    margin: "12px auto",
                  }}
                >
                  <Checkbox {...label} />
                  <Typography
                    sx={{
                      fontSize: "12px",
                      marginRight: "5px",
                      fontWeight: "600",
                      display: "grid",
                      alignItems: "baseline",
                    }}
                  >
                    GLobal/Institute Rank
                    <span>
                      Let your students compete to other students of your
                      institute
                    </span>
                  </Typography>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "end",
                    margin: "12px auto",
                  }}
                >
                  <Checkbox {...label} />
                  <Typography
                    sx={{
                      fontSize: "12px",
                      marginRight: "5px",
                      fontWeight: "600",
                      display: "grid",
                      alignItems: "baseline",
                    }}
                  >
                    Percentile{" "}
                    <span style={{ width: "50%" }}>
                      Let your students compete to other students of your
                      institute Let your students compete to other students of
                      your institute
                    </span>
                  </Typography>
                </Box>

                <Box display={"flex"} justifyContent={"space-between"} mt={5}>
                  <Box>
                    <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                      Enable Letter Grading
                    </Typography>
                    <Typography
                      sx={{
                        fontWeight: 500,
                        marginLeft: "15px",
                        fontSize: "12px",
                      }}
                    >
                      Now customize and give grades to your students according
                      to theri performance
                    </Typography>
                  </Box>
                  <Box>
                    <Switch
                      sx={{ color: "pink" }}
                      checked={checked}
                      onChange={handleChange}
                      inputProps={{ "aria-label": "controlled" }}
                    />
                  </Box>
                </Box>

                <Box
                  sx={{
                    background: "#E3ECF4",
                    margin: "20px",
                    borderRadius: "10px",
                    padding: "20px",
                  }}
                >
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography sx={{ fontWeight: "500", marginRight: "10px" }}>
                      Grade<span style={{ fontWeight: "700" }}>A</span>
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                    <Typography sx={{ fontWeight: "500", margin: "10px 25px" }}>
                      to
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography sx={{ fontWeight: "500", marginRight: "10px" }}>
                      Grade<span style={{ fontWeight: "700" }}>B</span>
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                    <Typography sx={{ fontWeight: "500", margin: "10px 25px" }}>
                      to
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography sx={{ fontWeight: "500", marginRight: "10px" }}>
                      Grade<span style={{ fontWeight: "700" }}>C</span>
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                    <Typography sx={{ fontWeight: "500", margin: "10px 25px" }}>
                      to
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography sx={{ fontWeight: "500", marginRight: "10px" }}>
                      Grade<span style={{ fontWeight: "700" }}>D</span>
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                    <Typography sx={{ fontWeight: "500", margin: "10px 25px" }}>
                      to
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                  </Box>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    <Typography sx={{ fontWeight: "500", marginRight: "10px" }}>
                      Grade<span style={{ fontWeight: "700" }}>E</span>
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                    <Typography sx={{ fontWeight: "500", margin: "10px 25px" }}>
                      to
                    </Typography>
                    <FormControl sx={{ m: 1, minWidth: 330 }}>
                      <Select
                        native
                        defaultValue=""
                        id="grouped-native-select"
                        size="small"
                        sx={{
                          borderRadius: "10px",
                        }}
                      >
                        <option aria-label="None" value="None" />
                        <option value={1}>Option 1</option>
                        <option value={2}>Option 2</option>
                        <option value={3}>Option 3</option>
                        <option value={4}>Option 4</option>
                      </Select>
                    </FormControl>
                  </Box>
                </Box>

                <Box sx={{ display: "flex", alignItems: "center" }} mt={5}>
                  <Typography
                    sx={{
                      background: "#0091EB",
                      padding: "6px",
                      borderRadius: "100px",
                      height: "6px",
                      width: "fit-content",
                      display: "flex",
                      alignItems: "center",
                      color: "white",
                      fontSize: "12px",
                    }}
                  >
                    3
                  </Typography>
                  <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                    Solution
                  </Typography>
                </Box>
                <Divider sx={{ margin: "10px auto" }} />
                <Box display={"flex"} justifyContent={"space-between"}>
                  <Box>
                    <Typography sx={{ fontWeight: 700, marginLeft: "15px" }}>
                      Enable Solution
                    </Typography>
                    <Typography
                      sx={{
                        fontWeight: 500,
                        marginLeft: "15px",
                        fontSize: "12px",
                      }}
                    >
                      Your student will able to view the test solutions
                    </Typography>
                  </Box>
                  <Box>
                    <Switch
                      sx={{ color: "pink" }}
                      checked={checked}
                      onChange={handleChange}
                      inputProps={{ "aria-label": "controlled" }}
                    />
                  </Box>
                </Box>
                <Box display={"flex"} alignItems={"center"}>
                  <Typography
                    sx={{
                      color: "gray",
                      fontWeight: "500",
                      marginRight: "10px",
                    }}
                  >
                    When to show solutions
                  </Typography>

                  <FormControl sx={{ m: 1, minWidth: 200 }}>
                    <Select
                      native
                      defaultValue=""
                      id="grouped-native-select"
                      size="small"
                      sx={{
                        borderRadius: "10px",
                        boxShadow:
                          "inset 0 0 35px 5px rgba(0,0,0,0.25), inset 0 2px 1px 1px rgba(255,255,255,0.9), inset 0 -2px 1px rgba(0,0,0,0.25)",
                      }}
                    >
                      <option aria-label="None" value="None" />
                      <option value={1}>Option 1</option>
                      <option value={2}>Option 2</option>
                      <option value={3}>Option 3</option>
                      <option value={4}>Option 4</option>
                    </Select>
                  </FormControl>
                </Box>
                <Box display={"flex"} alignItems={"center"}>
                  <Typography
                    sx={{
                      color: "gray",
                      fontWeight: "500",
                      marginRight: "10px",
                    }}
                  >
                    Reveal correct solutions
                  </Typography>

                  <FormControl sx={{ m: 1, minWidth: 200 }}>
                    <Select
                      native
                      defaultValue=""
                      id="grouped-native-select"
                      size="small"
                      sx={{
                        borderRadius: "10px",
                        boxShadow:
                          "inset 0 0 35px 5px rgba(0,0,0,0.25), inset 0 2px 1px 1px rgba(255,255,255,0.9), inset 0 -2px 1px rgba(0,0,0,0.25)",
                      }}
                    >
                      <option aria-label="None" value="None" />
                      <option value={1}>Option 1</option>
                      <option value={2}>Option 2</option>
                      <option value={3}>Option 3</option>
                      <option value={4}>Option 4</option>
                    </Select>
                  </FormControl>
                </Box>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "end",
                    margin: "12px auto",
                  }}
                >
                  <Checkbox {...label} />
                  <Typography
                    sx={{
                      fontSize: "12px",
                      marginRight: "5px",
                      fontWeight: "600",
                      display: "grid",
                      alignItems: "baseline",
                    }}
                  >
                    Click here to give solution only once
                    <span>
                      If you select this option If you select this option If you
                      select this option If you select this option If you select
                      this option
                    </span>
                  </Typography>
                </Box>
              </Paper>
            </Grid>
          </Grid>
        </Box>

        <Grid container></Grid>
      </Dialog>
    </React.Fragment>
  );
}
