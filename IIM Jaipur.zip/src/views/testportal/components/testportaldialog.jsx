import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Typography from "@mui/material/Typography";
import Paper from "@mui/material/Paper";
import IconButton from "@mui/material/IconButton";
import { IoMdPricetag } from "react-icons/io";
import { MdEdit } from "react-icons/md";
import { FaGraduationCap } from "react-icons/fa";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Checkbox from "@mui/material/Checkbox";
import { CiGrid42 } from "react-icons/ci";
import Divider from "@mui/material/Divider";
import Dialog from "@mui/material/Dialog";
import { FaRegClock } from "react-icons/fa";
import CloseIcon from "@mui/icons-material/Close";
import Accordion from "@mui/material/Accordion";
import { IoMdSettings } from "react-icons/io";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import Slide from "@mui/material/Slide";
import { FaRegQuestionCircle } from "react-icons/fa";
import Advancesetting from './advanced-setting-dialog'
import { MdOutlineFileDownload } from "react-icons/md";

const Transition = React.forwardRef(function Transition(props, ref) {
  return <Slide direction="up" ref={ref} {...props} />;
});

const label = { inputProps: { "aria-label": "Checkbox demo" } };
const styles = {
  "css-10botns-MuiInputBase-input-MuiFilledInput-input": {
    padding: "0px",
  },
};

export default function Createtestform(props) {
  const { open, onClose } = props;
  const [expandedAccordion, setExpandedAccordion] = useState(null);

  const handleChange = (panel) => (event, isExpanded) => {
    setExpandedAccordion(isExpanded ? panel : null);
  };
  return (
    <React.Fragment>
      <Dialog
        fullScreen
        open={open}
        onClose={() => onClose()}
        TransitionComponent={Transition}
      >
        <Box sx={{ background: "#F2F1F2" }}>
          <Paper sx={{ padding: "10px" }}>
            <Grid container>
              <Grid item xs={12}>
                <Box sx={{ display: "flex", justifyContent: "space-between" }}>
                  <IconButton
                    edge="start"
                    color="inherit"
                    onClick={() => onClose()}
                    aria-label="close"
                  >
                    <CloseIcon />
                    <Typography sx={{ fontWeight: "600" }}>Test</Typography>
                  </IconButton>

                  <Box>
                    <Button
                      component="label"
                      sx={{
                        textTransform: "none",
                        fontSize: "12px",
                        color: "#76C1D6",
                        marginTop: "0", // Adjusted marginTop value
                        background: "#e4f5ff",
                        borderRadius: "5px",
                        marginRight: "10px",
                        padding: "10px",
                        "&:hover": {
                          background: "#e4f5ff",
                        },
                      }}
                    >
                      Preview{" "}
                    </Button>
                    <Button
                      component="label"
                      sx={{
                        textTransform: "none",
                        fontSize: "12px",
                        color: "#76C1D6",
                        marginTop: "0", // Adjusted marginTop value
                        background: "#e4f5ff",
                        borderRadius: "5px",
                        marginRight: "10px",
                        padding: "10px",
                        "&:hover": {
                          background: "#e4f5ff",
                        },
                      }}
                    >
                      Save Test{" "}
                    </Button>
                  </Box>
                </Box>
              </Grid>
            </Grid>
          </Paper>
          <Grid container>
            <Grid item xs={3}>
              <Box
                sx={{
                  padding: "15px",
                  maxHeight: "85vh",
                  overflowY: "scroll",
                  borderRadius: "10px",
                  "&::-webkit-scrollbar": {
                    width: "8px",
                    borderRadius: "10px",
                  },
                  "&::-webkit-scrollbar-track": {
                    background: "#f1f1f1",
                    borderRadius: "10px",
                  },
                  "&::-webkit-scrollbar-thumb": {
                    background: "#888",
                    borderRadius: "10px",
                  },
                }}
              >
                {" "}
                <Accordion
                  sx={{ margin: "10px auto", border: "1px solid #cacaca" }}
                  expanded={expandedAccordion === "panel1"}
                  onChange={handleChange("panel1")}
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel1-content"
                    id="panel1-header"
                  >
                    <Typography
                      sx={{
                        fontWeight: "700",
                        display: "flex",
                        alignItems: "center",
                        paddingY: "13px",
                      }}
                    >
                      <FaRegQuestionCircle
                        style={{
                          color: "#0085CA",
                          marginRight: "10px",
                          fontSize: "25px",
                        }}
                      />
                      Create Question
                    </Typography>
                  </AccordionSummary>
                  <Divider
                    sx={{
                      border: "1px solid #80808078",
                    }}
                  />
                  <AccordionDetails>
                    <Box>
                      <Button
                        variant="text"
                        sx={{
                          textTransform: "none",
                          color: "black",
                          width: "100%",
                          fontWeight: "700",
                          justifyContent: "left",
                          margin: "10px auto",
                        }}
                      >
                        Multiple Choice Questions
                      </Button>
                      <Divider
                        sx={{
                          border: "1px solid #80808078",
                        }}
                      />
                    </Box>
                    <Box>
                      <Button
                        variant="text"
                        sx={{
                          textTransform: "none",
                          color: "black",
                          width: "100%",
                          fontWeight: "700",
                          justifyContent: "left",
                          margin: "10px auto",
                        }}
                      >
                        True/False Questions{" "}
                      </Button>
                      <Divider
                        sx={{
                          border: "1px solid #80808078",
                        }}
                      />
                    </Box>
                    <Box>
                      <Button
                        variant="text"
                        sx={{
                          textTransform: "none",
                          color: "black",
                          width: "100%",
                          fontWeight: "700",
                          justifyContent: "left",
                          margin: "10px auto",
                        }}
                      >
                        Comprehnsion Questions{" "}
                      </Button>
                      <Divider
                        sx={{
                          border: "1px solid #80808078",
                        }}
                      />
                      {/* Add more content as needed */}
                    </Box>
                    <Box>
                      <Button
                        variant="text"
                        sx={{
                          textTransform: "none",
                          color: "black",
                          width: "100%",
                          fontWeight: "700",
                          justifyContent: "left",
                          margin: "10px auto",
                        }}
                      >
                        Fill in the Blanks Questions{" "}
                      </Button>
                      <Divider
                        sx={{
                          border: "1px solid #80808078",
                        }}
                      />
                      {/* Add more content as needed */}
                    </Box>
                    <Box>
                      <Button
                        variant="text"
                        sx={{
                          textTransform: "none",
                          color: "black",
                          width: "100%",
                          fontWeight: "700",
                          justifyContent: "left",
                          margin: "10px auto",
                        }}
                      >
                        Integer Type Questions{" "}
                      </Button>
                      <Divider
                        sx={{
                          border: "1px solid #80808078",
                        }}
                      />
                      {/* Add more content as needed */}
                    </Box>
                  </AccordionDetails>
                </Accordion>
                <Accordion
                  sx={{ margin: "10px auto" }}
                  expanded={expandedAccordion === "panel2"}
                  onChange={handleChange("panel2")}
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel2-content"
                    id="panel2-header"
                  >
                    <Typography
                      sx={{
                        fontWeight: "700",
                        display: "flex",
                        alignItems: "center",
                        paddingY: "13px",
                      }}
                    >
                      <FaGraduationCap
                        style={{
                          color: "#0085CA",
                          marginRight: "10px",
                          fontSize: "25px",
                        }}
                      />
                      Grading
                    </Typography>
                  </AccordionSummary>
                  <Divider
                    sx={{
                      border: "1px solid #80808078",
                    }}
                  />
                  <AccordionDetails>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Multiple Choice
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Fill in the blanks
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          True/False
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Integer Type
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                            width: "45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height: "0.5rem",
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Divider
                      sx={{
                        border: "1px solid #80808078",
                      }}
                    />
                    <Box
                      sx={{
                        textAlign: "center",
                        margin: "10px auto",
                      }}
                    >
                      <Button
                        component="label"
                        sx={{
                          textTransform: "none",
                          fontSize: "12px",
                          color: "White",
                          marginTop: "0",
                          background: "#69A5CF",
                          borderRadius: "5px",
                          marginRight: "10px",
                          padding: "10px",
                          textAlign: "center",
                          "&:hover": {
                            background: "#69A5CF",
                          },
                        }}
                      >
                        Submit{" "}
                      </Button>
                    </Box>
                  </AccordionDetails>
                </Accordion>
                <Accordion
                  sx={{ margin: "10px auto" }}
                  expanded={expandedAccordion === "panel3"}
                  onChange={handleChange("panel3")}
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel3-content"
                    id="panel3-header"
                  >
                    <Typography
                      sx={{
                        fontWeight: "700",
                        display: "flex",
                        alignItems: "center",
                        paddingY: "13px",
                      }}
                    >
                      <CiGrid42
                        style={{
                          color: "#0085CA",
                          marginRight: "10px",
                          fontSize: "25px",
                        }}
                      />
                      Test Section
                    </Typography>
                  </AccordionSummary>
                  <Divider
                    sx={{
                      border: "1px solid #80808078",
                    }}
                  />
                  {/* <AccordionDetails>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Multiple Choice
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Fill in the blanks
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          True/False
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Integer Type
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Divider
                      sx={{
                        border: "1px solid #80808078",
                      }}
                    />
                    <Box
                      sx={{
                        textAlign: "center",
                        margin: "10px auto",
                      }}
                    >
                      <Button
                        component="label"
                        sx={{
                          textTransform: "none",
                          fontSize: "12px",
                          color: "White",
                          marginTop: "0",
                          background: "#69A5CF",
                          borderRadius: "5px",
                          marginRight: "10px",
                          padding: "10px",
                          textAlign: "center",
                          "&:hover": {
                            background: "#69A5CF",
                          },
                        }}
                      >
                        Submit{" "}
                      </Button>
                    </Box>
                  </AccordionDetails> */}
                </Accordion>
                <Accordion
                  sx={{ margin: "10px auto" }}
                  expanded={expandedAccordion === "panel4"}
                  onChange={handleChange("panel4")}
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel4-content"
                    id="panel4-header"
                  >
                    <Typography
                      sx={{
                        fontWeight: "700",
                        display: "flex",
                        alignItems: "center",
                        paddingY: "13px",
                      }}
                    >
                      <MdOutlineFileDownload
                        style={{
                          color: "#0085CA",
                          marginRight: "10px",
                          fontSize: "25px",
                        }}
                      />
                      Import Question{" "}
                    </Typography>
                  </AccordionSummary>
                  <Divider
                    sx={{
                      border: "1px solid #80808078",
                    }}
                  />
                  {/* <AccordionDetails>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Multiple Choice
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Fill in the blanks
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          True/False
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Integer Type
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Divider
                      sx={{
                        border: "1px solid #80808078",
                      }}
                    />
                    <Box
                      sx={{
                        textAlign: "center",
                        margin: "10px auto",
                      }}
                    >
                      <Button
                        component="label"
                        sx={{
                          textTransform: "none",
                          fontSize: "12px",
                          color: "White",
                          marginTop: "0",
                          background: "#69A5CF",
                          borderRadius: "5px",
                          marginRight: "10px",
                          padding: "10px",
                          textAlign: "center",
                          "&:hover": {
                            background: "#69A5CF",
                          },
                        }}
                      >
                        Submit{" "}
                      </Button>
                    </Box>
                  </AccordionDetails> */}
                </Accordion>
                <Accordion
                  sx={{ margin: "10px auto" }}
                  expanded={expandedAccordion === "panel5"}
                  onChange={handleChange("panel5")}
                >
                  <AccordionSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panel5-content"
                    id="panel5-header"
                  >
                    <Box
                      display={"flex"}
                      justifyContent={"space-between"}
                      width={"100%"}
                    >
                      <Typography
                        sx={{
                          fontWeight: "700",
                          display: "flex",
                          alignItems: "center",
                          paddingY: "13px",
                        }}
                      >
                        <IoMdSettings
                          style={{
                            color: "#0085CA",
                            marginRight: "10px",
                            fontSize: "25px",
                          }}
                        />
                        Test Settings{" "}
                      </Typography>
                  <Advancesetting/>

                    </Box>
                  </AccordionSummary>

                  <Divider
                    sx={{
                      border: "1px solid #80808078",
                    }}
                  />
                  {/* <AccordionDetails>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Multiple Choice
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Fill in the blanks
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          True/False
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        margin: "5px auto",
                      }}
                    >
                      <Box sx={{ display: "flex", alignItems: "center" }}>
                        <Checkbox {...label} style={{ color: "#ababab" }} />
                        <Typography
                          sx={{ fontWeight: "600", fontSize: "14px" }}
                        >
                          Integer Type
                        </Typography>
                      </Box>

                      <Box>
                        <TextField
                          variant="filled"
                          sx={{
                            width: "40px",
                            border: "1px solid #ababab",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                            },
                          }}
                        />
                        <TextField
                          variant="outlined"
                          size="small"
                          sx={{
                           width:"45px",
                            borderRadius: "5px",
                            borderBottom: "none",
                            justifyContent: "center",
                            marginRight: "15px",
                            "& input": {
                              textAlign: "center",
                              height:'0.5rem'
                            },
                          }}
                        />
                      </Box>
                    </Box>
                    <Divider
                      sx={{
                        border: "1px solid #80808078",
                      }}
                    />
                    <Box
                      sx={{
                        textAlign: "center",
                        margin: "10px auto",
                      }}
                    >
                      <Button
                        component="label"
                        sx={{
                          textTransform: "none",
                          fontSize: "12px",
                          color: "White",
                          marginTop: "0",
                          background: "#69A5CF",
                          borderRadius: "5px",
                          marginRight: "10px",
                          padding: "10px",
                          textAlign: "center",
                          "&:hover": {
                            background: "#69A5CF",
                          },
                        }}
                      >
                        Submit{" "}
                      </Button>
                    </Box>
                  </AccordionDetails> */}
                </Accordion>
              </Box>
            </Grid>
            <Grid item xs={9}>
              <Box
                sx={{ height: "90vh", background: "white", marginTop: "1px" }}
              >
                <Paper sx={{ padding: "15px" }}>
                  <Typography
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      fontWeight: "600",
                    }}
                  >
                    Test Details
                    <MdEdit style={{ color: "#008DD3", marginLeft: "5px" }} />
                  </Typography>
                  <Typography
                    sx={{
                      display: "flex",
                      alignItems: "center",
                      margin: "10px auto",
                      color: "#a2a2a2",
                      fontSize: "13px",
                    }}
                  >
                    <FaRegClock />
                    Test Duration
                    <span style={{ color: "black", fontWeight: "600" }}>
                      30 mins
                    </span>
                    <Typography
                      sx={{
                        display: "flex",
                        alignItems: "center",
                        color: "#a2a2a2",
                        marginLeft: "10px",
                        fontSize: "13px",
                      }}
                    >
                      <IoMdPricetag />
                      Tags:{" "}
                      <span style={{ color: "black", fontWeight: "600" }}>
                        asdc
                      </span>
                    </Typography>
                  </Typography>
                  <Box
                    sx={{
                      border: "1px solid",
                      padding: "5px",
                      borderColor: "#a2a2a273",
                      borderRadius: "5px",
                      margin: "15px auto",
                    }}
                  >
                    <Typography sx={{ fontWeight: "600" }}>
                      Test Instructions:{" "}
                      <span style={{ fontWeight: "500" }}>
                        Test Instruction:Click here to add
                      </span>
                    </Typography>
                  </Box>
                </Paper>
                <Box
                  sx={{
                    textAlign: "center",
                    display: "flex",
                    justifyContent: "center",
                    height: "60%",
                    alignItems: "center",
                  }}
                >
                  <Grid container>
                    <Grid item xs={12}>
                      <Typography
                        sx={{
                          fontSize: "20px",
                          fontWeight: "500",
                          margin: "10px auto",
                        }}
                      >
                        Start by adding a section
                      </Typography>
                      <Typography
                        sx={{
                          fontWeight: "400",
                          fontSize: "15px",
                          margin: "10px auto",
                        }}
                      >
                        You can add& manage sections from the 'Test Sections'
                        panel on the left
                      </Typography>
                      <Button
                        component="label"
                        sx={{
                          textTransform: "none",
                          fontSize: "12px",
                          color: "White",
                          marginTop: "0",
                          background: "#69A5CF",
                          borderRadius: "5px",
                          marginRight: "10px",
                          padding: "10px",
                          margin: "10px auto",
                          textAlign: "center",
                          "&:hover": {
                            background: "#69A5CF",
                          },
                        }}
                      >
                        Add new section{" "}
                      </Button>
                    </Grid>
                  </Grid>
                </Box>
              </Box>
            </Grid>
          </Grid>
        </Box>
      </Dialog>
    </React.Fragment>
  );
}
