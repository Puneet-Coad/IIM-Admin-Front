import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import { Typography } from "@mui/material";
import Button from "@mui/material/Button";
import { Divider } from "@mui/material";
import SpringModal from "./components/dialog";
import { FaBullhorn } from "react-icons/fa";
import { TbDiscount2 } from "react-icons/tb";
import { FaArrowRight } from "react-icons/fa6";
import { IoMdBookmarks } from "react-icons/io";
import { GiStack } from "react-icons/gi";
import { FaChevronRight } from "react-icons/fa";
import { TbDeviceMobileDollar } from "react-icons/tb";
import Accordion from "@mui/material/Accordion";
import AccordionDetails from "@mui/material/AccordionDetails";
import AccordionSummary from "@mui/material/AccordionSummary";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import { IoShareSocial } from "react-icons/io5";
import { FaRegCopy } from "react-icons/fa6";
import { RiGalleryFill } from "react-icons/ri";
import Navbar from "../../comon/navbar/navbar";



const Dashboard = () => {
  const [expanded, setExpanded] = useState(false);
  const[dialogOpen,setDialogOpen] = useState(false);
 
  const handleChange = (panel) => (event, isExpanded) => {
    setExpanded(isExpanded ? panel : false);
  };



  return (
    <>
       
        <Box >
          <Navbar
            title="  Hi IIM Jaipur"
            desc=" Welcome to your Dashboard"
            progressNum={78}
          />
        <SpringModal
          open={dialogOpen}
          onClose={() => setDialogOpen(false)}

        />
          <Box>
            <Grid container spacing={2} mt={2}>
              <Grid item xs={8}>
                <Box>
                  <Grid container spacing={2}>
                    <Grid item xs={12} md={6}>
                      <Paper
                        elevation={5}
                        sx={{
                          textAlign: "center",
                          borderRadius: "20px",
                          padding: "20px",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            justifyContent: "space-evenly",
                            textAlign: "left",
                            alignItems: "center",
                          }}
                        >
                          <GiStack
                            style={{
                              color: "#007FB6",
                              background: "#CFECFC",
                              borderRadius: "50%",
                              padding: "12px",
                              marginRight: "20px",
                            }}
                          />
                          <Box>
                            <Typography
                              sx={{
                                color: "#007FB6",
                                fontSize: "15px",
                                fontWeight: "700",
                              }}
                            >
                              Create Website
                            </Typography>
                            <Typography sx={{ color: "gray", fontSize: "12px" }}>
                              Create your personalised Website{" "}
                            </Typography>
                          </Box>
                          <Typography sx={{ marginLeft: "20px" }}>
                            {" "}
                            <FaChevronRight style={{ color: "#6FC2EA" }} />{" "}
                          </Typography>
                        </Box>
                      </Paper>
                    </Grid>
                    <Grid item xs={12} md={6}>
                      <Paper
                        elevation={5}
                        sx={{
                          textAlign: "center",
                          borderRadius: "20px",
                          padding: "20px",
                        }}
                      >
                        <Box
                          sx={{
                            display: "flex",
                            // justifyContent: "space-evenly",
                            textAlign: "left",
                            alignItems: "center",
                            position: "relative",
                          }}
                        >
                          <TbDeviceMobileDollar
                            style={{
                              color: "#007FB6",
                              background: "#CFECFC",
                              borderRadius: "50%",
                              padding: "12px",
                              marginRight: "20px",
                            }}
                          />
                          <Box>
                            <Typography
                              sx={{
                                color: "#007FB6",
                                fontSize: "15px",
                                fontWeight: "700",
                              }}
                            >
                              Your App
                            </Typography>
                            <Box
                              sx={{
                                display: "flex",
                                justifyContent: "space-between",
                                width: "153px",
                                cursor: "pointer",
                              }}
                            >
                              <Typography
                                sx={{
                                  color: "gray",
                                  fontSize: "12px",
                                  fontWeight: "500",
                                  display: "flex",
                                  alignItems: "center",
                                }}
                              >
                                <IoShareSocial /> Share App{" "}
                              </Typography>
                              <Typography
                                sx={{
                                  color: "gray",
                                  fontSize: "12px",
                                  fontWeight: "500",
                                  display: "flex",
                                  alignItems: "center",
                                }}
                              >
                                <FaRegCopy />
                                Copy Link{" "}
                              </Typography>
                            </Box>
                          </Box>
                          <Typography
                            sx={{
                              marginLeft: "20px",
                              position: "absolute",
                              right: "0",
                            }}
                          >
                            {" "}
                            <FaChevronRight style={{ color: "#6FC2EA" }} />{" "}
                          </Typography>
                        </Box>
                      </Paper>
                    </Grid>

                    <Grid item xs={12}>
                      <Grid item xs={12}>
                        {" "}
                        <Paper
                          elevation={5}
                          sx={{ borderRadius: "20px", padding: "15px" }}
                        >
                          <Typography sx={{ fontWeight: "700", marginBottom: "25px" }}>
                            Our Offerings
                          </Typography>{" "}
                          <Grid container spacing={2}>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  border: "2px solid #cbcbcb",
                                  borderRadius: "15px",
                                  padding: "20px",
                                  minHeight: "134px",
                                }}
                              >
                                <Box sx={{ display: "flex" }}>
                                  {" "}
                                  <IoMdBookmarks
                                    style={{
                                      color: "#007FB6",
                                      background: "#CFECFC",
                                      borderRadius: "50%",
                                      padding: "12px",
                                      marginRight: "20px",
                                    }}
                                  />
                                  <Box>
                                    <Box sx={{ display: "flex" }}>
                                      <Typography
                                        sx={{ fontSize: "14px", fontWeight: "700" }}
                                      >
                                        Course
                                      </Typography>
                                      {/* <Button
                              sx={{
                                background: "#FCF8E5",
                                border: "2px solid #E48558",
                                color: "#E48558",
                                textTransform: "none",
                                fontWeight: "600",
                                padding: "0px",
                                fontSize: "10px",
                                marginLeft: "5px",
                              }}
                            >
                              Premium
                            </Button> */}
                                    </Box>
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        color: "gray",
                                        fontWeight: "400",
                                      }}
                                    >
                                      40 Course Published
                                    </Typography>
                                  </Box>
                                </Box>
                                <Typography
                                  sx={{
                                    fontSize: "10px",
                                    color: "gray",
                                    fontWeight: "600",
                                    margin: "10px auto",
                                  }}
                                >
                                  Easily create and sell courses online
                                </Typography>
                                <Typography
                                  sx={{
                                    fontSize: "13px",
                                    color: "#35A3E2",

                                    fontWeight: "700",
                                    alignItems: "center",
                                    display: "flex",
                                    margin: "13px auto",
                                  }}
                                >
                                  Create Courses <FaArrowRight />
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  border: "2px solid #cbcbcb",
                                  borderRadius: "15px",
                                  padding: "20px",
                                  minHeight: "134px",
                                }}
                              >
                                <Box sx={{ display: "flex" }}>
                                  {" "}
                                  <IoMdBookmarks
                                    style={{
                                      color: "#007FB6",
                                      background: "#CFECFC",
                                      borderRadius: "50%",
                                      padding: "12px",
                                      marginRight: "20px",
                                    }}
                                  />
                                  <Box>
                                    <Box sx={{ display: "flex" }}>
                                      <Typography
                                        sx={{ fontSize: "14px", fontWeight: "700" }}
                                      >
                                        Landing Page{" "}
                                      </Typography>
                                      {/* <Button
                              sx={{
                                background: "#FCF8E5",
                                border: "2px solid #E48558",
                                color: "#E48558",
                                textTransform: "none",
                                fontWeight: "600",
                                padding: "0px",
                                fontSize: "10px",
                                marginLeft: "5px",
                              }}
                            >
                              Premium
                            </Button> */}
                                    </Box>
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        color: "gray",
                                        fontWeight: "400",
                                      }}
                                    >
                                      No landing Pages
                                    </Typography>
                                  </Box>
                                </Box>
                                <Typography
                                  sx={{
                                    fontSize: "10px",
                                    color: "gray",
                                    fontWeight: "600",
                                    margin: "10px auto",
                                  }}
                                >
                                  Boost your conversion which stand alone landing
                                  playwhich standalone landing pages{" "}
                                </Typography>
                                <Typography
                                  sx={{
                                    fontSize: "13px",
                                    color: "#35A3E2",

                                    fontWeight: "700",
                                    alignItems: "center",
                                    display: "flex",
                                    margin: "13px auto",
                                  }}
                                >
                                  Create Courses <FaArrowRight />
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  border: "2px solid #cbcbcb",
                                  borderRadius: "15px",
                                  padding: "20px",
                                  minHeight: "134px",
                                }}
                              >
                                <Box sx={{ display: "flex" }}>
                                  {" "}
                                  <IoMdBookmarks
                                    style={{
                                      color: "#007FB6",
                                      background: "#CFECFC",
                                      borderRadius: "50%",
                                      padding: "12px",
                                      marginRight: "20px",
                                    }}
                                  />
                                  <Box>
                                    <Box sx={{ display: "flex" }}>
                                      <Typography
                                        sx={{ fontSize: "14px", fontWeight: "700" }}
                                      >
                                        Course
                                      </Typography>
                                      <Button
                                        sx={{
                                          background: "#FCF8E5",
                                          border: "2px solid #E48558",
                                          color: "#E48558",
                                          textTransform: "none",
                                          fontWeight: "600",
                                          padding: "0px",
                                          fontSize: "10px",
                                          marginLeft: "5px",
                                        }}
                                      >
                                        Premium
                                      </Button>
                                    </Box>
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        color: "gray",
                                        fontWeight: "400",
                                      }}
                                    >
                                      40 Course Published
                                    </Typography>
                                  </Box>
                                </Box>
                                <Typography
                                  sx={{
                                    fontSize: "10px",
                                    color: "gray",
                                    fontWeight: "600",
                                    margin: "10px auto",
                                  }}
                                >
                                  Easily create and sell courses online
                                </Typography>
                                <Typography
                                  sx={{
                                    fontSize: "13px",
                                    color: "#35A3E2",

                                    fontWeight: "700",
                                    alignItems: "center",
                                    display: "flex",
                                    margin: "13px auto",
                                  }}
                                >
                                  Create Courses <FaArrowRight />
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  border: "2px solid #cbcbcb",
                                  borderRadius: "15px",
                                  padding: "20px",
                                  minHeight: "134px",
                                }}
                              >
                                <Box sx={{ display: "flex" }}>
                                  {" "}
                                  <IoMdBookmarks
                                    style={{
                                      color: "#007FB6",
                                      background: "#CFECFC",
                                      borderRadius: "50%",
                                      padding: "12px",
                                      marginRight: "20px",
                                    }}
                                  />
                                  <Box>
                                    <Box sx={{ display: "flex" }}>
                                      <Typography
                                        sx={{ fontSize: "14px", fontWeight: "700" }}
                                      >
                                        Course
                                      </Typography>
                                      {/* <Button
                              sx={{
                                background: "#FCF8E5",
                                border: "2px solid #E48558",
                                color: "#E48558",
                                textTransform: "none",
                                fontWeight: "600",
                                padding: "0px",
                                fontSize: "10px",
                                marginLeft: "5px",
                              }}
                            >
                              Premium
                            </Button> */}
                                    </Box>
                                    <Typography
                                      sx={{
                                        fontSize: "10px",
                                        color: "gray",
                                        fontWeight: "400",
                                      }}
                                    >
                                      40 Course Published
                                    </Typography>
                                  </Box>
                                </Box>
                                <Typography
                                  sx={{
                                    fontSize: "10px",
                                    color: "gray",
                                    fontWeight: "600",
                                    margin: "10px auto",
                                  }}
                                >
                                  Easily create and sell courses online
                                </Typography>
                                <Typography
                                  sx={{
                                    fontSize: "13px",
                                    color: "#35A3E2",

                                    fontWeight: "700",
                                    alignItems: "center",
                                    display: "flex",
                                    margin: "13px auto",
                                  }}
                                >
                                  Create Courses <FaArrowRight />
                                </Typography>
                              </Box>
                            </Grid>
                          </Grid>
                        </Paper>
                      </Grid>
                      <Grid item xs={12} >
                        <Paper
                          elevation={5}
                          sx={{
                            borderRadius: "20px",
                            padding: "15px",
                            mt: 2
                          }}
                        >
                          <Typography sx={{ fontWeight: "700" }}>Analytics</Typography>{" "}
                          <Typography
                            sx={{
                              color: "#23A9E0",
                              fontWeight: "600",
                              fontSize: "12px",

                            }}
                          >
                            6 Live{" "}
                          </Typography>
                          <Grid container spacing={2} mt={1}>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  borderLeft: "4px solid #94ACBA",
                                  display: "flex",
                                  justifyContent: "space-between",
                                  padding: "3px",
                                }}
                              >
                                <Typography sx={{ fontWeight: "600" }}>
                                  Website Sessions
                                </Typography>
                                <Typography
                                  sx={{ fontWeight: "600", color: "#00699F" }}
                                >
                                  0
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  borderLeft: "4px solid #94ACBA",
                                  display: "flex",
                                  justifyContent: "space-between",
                                  padding: "3px",
                                }}
                              >
                                <Typography sx={{ fontWeight: "600" }}>
                                  Buy Now Clicks
                                </Typography>
                                <Typography
                                  sx={{ fontWeight: "600", color: "#00699F" }}
                                >
                                  281
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  borderLeft: "4px solid #94ACBA",
                                  display: "flex",
                                  justifyContent: "space-between",
                                  padding: "3px",
                                }}
                              >
                                <Typography sx={{ fontWeight: "600" }}>
                                  Transaction
                                </Typography>
                                <Typography
                                  sx={{ fontWeight: "600", color: "#00699F" }}
                                >
                                  60
                                </Typography>
                              </Box>
                            </Grid>
                            <Grid item xs={6}>
                              <Box
                                sx={{
                                  borderLeft: "4px solid #94ACBA",
                                  display: "flex",
                                  justifyContent: "space-between",
                                  padding: "3px",
                                }}
                              >
                                <Typography sx={{ fontWeight: "600" }}>
                                  Revenue
                                </Typography>
                                <Typography
                                  sx={{ fontWeight: "600", color: "#00699F" }}
                                >
                                  508049.81
                                </Typography>
                              </Box>
                            </Grid>
                          </Grid>
                        </Paper>
                      </Grid>

                    </Grid>
                  </Grid>
                </Box>

              </Grid>

              <Grid item xs={4}>



                <Paper
                  elevation={5}
                  sx={{
                    borderRadius: "20px",
                    padding: "20px",
                  }}
                >
                  <Typography variant="h6" sx={{ fontWeight: "600" }}>
                    Upcoming Classes
                  </Typography>
                  <Divider
                    sx={{
                      margin: "10px auto",
                    }}
                  />


                <Button variant="text"  onClick={()=>setDialogOpen(true)}>Create class</Button>
               
                </Paper>
                <Paper
                  elevation={5}
                  sx={{
                    borderRadius: "20px",
                    padding: "15px",
                    mt: 2
                  }}>
                  <Accordion
                    expanded={expanded === "panel1"}
                    onChange={handleChange("panel1")}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel1bh-content"
                      id="panel1bh-header"
                    >
                      <Box>
                        {" "}
                        <RiGalleryFill
                          style={{
                            textAlign: "center ",
                            background: "#D9F2F3",
                            padding: "10px ",
                            fontSize: "20px",
                            borderRadius: "20px",
                            color: "#009FDC",
                          }}
                        />
                      </Box>
                      <Box sx={{ display: "grid", marginLeft: "10px" }}>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                          }}
                        >
                          Banners{" "}
                        </Typography>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                            fontSize: "12px",

                          }}
                        >
                          6 Live{" "}
                        </Typography>
                      </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography>
                        Nulla facilisi. Phasellus sollicitudin nulla et quam mattis
                        feugiat. Aliquam eget maximus est, id dignissim quam.
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion
                    expanded={expanded === "panel2"}
                    onChange={handleChange("panel2")}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel2bh-content"
                      id="panel2bh-header"
                    >
                      <Box>
                        {" "}
                        <TbDiscount2
                          style={{
                            textAlign: "center ",
                            background: "#D9F2F3",
                            padding: "10px ",
                            fontSize: "20px",
                            borderRadius: "20px",
                            color: "#009FDC",
                          }}
                        />
                      </Box>
                      <Box sx={{ display: "grid", marginLeft: "10px" }}>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                          }}
                        >
                          Coupons{" "}
                        </Typography>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                            fontSize: "12px",

                          }}
                        >
                          1 Live{" "}
                        </Typography>
                      </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography>
                        Donec placerat, lectus sed mattis semper, neque lectus feugiat
                        lectus, varius pulvinar diam eros in elit. Pellentesque
                        convallis laoreet laoreet.
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                  <Accordion
                    expanded={expanded === "panel3"}
                    onChange={handleChange("panel3")}
                  >
                    <AccordionSummary
                      expandIcon={<ExpandMoreIcon />}
                      aria-controls="panel3bh-content"
                      id="panel3bh-header"
                    >
                      <Box>
                        {" "}
                        <FaBullhorn
                          style={{
                            textAlign: "center ",
                            background: "#D9F2F3",
                            padding: "10px ",
                            fontSize: "20px",
                            borderRadius: "20px",
                            color: "#009FDC",
                          }}
                        />
                      </Box>
                      <Box sx={{ display: "grid", marginLeft: "10px" }}>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                          }}
                        >
                          Notice{" "}
                        </Typography>
                        <Typography
                          sx={{
                            color: "#23A9E0",
                            fontWeight: "600",
                            fontSize: "12px",

                          }}
                        >

                        </Typography>
                      </Box>
                    </AccordionSummary>
                    <AccordionDetails>
                      <Typography>
                        Nunc vitae orci ultricies, auctor nunc in, volutpat nisl.
                        Integer sit amet egestas eros, vitae egestas augue. Duis vel
                        est augue.
                      </Typography>
                    </AccordionDetails>
                  </Accordion>
                </Paper>

              </Grid>
            </Grid>

          </Box>
        </Box>
       
    </>
  );
};

export default Dashboard;
