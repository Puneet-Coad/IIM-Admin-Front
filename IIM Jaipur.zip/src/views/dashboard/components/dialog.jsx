import * as React from 'react';
import {
    Dialog,
    Box,
    Typography,
    Button
} from '@mui/material';


export default function SpringModal({open,onClose}) {
    

    return (
        <div>

            <Dialog
                open={open}
                onClose={()=>onClose()}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth='lg'
                fullWidth='lg'
            >

                <Box >
                    <Typography id="spring-modal-title" variant="h6" component="h2">
                        Text in a modal
                    </Typography>
                    <Typography id="spring-modal-description" sx={{ mt: 2 }}>
                        Duis mollis, est non commodo luctus, nisi erat porttitor ligula.
                    </Typography>
                </Box>

            </Dialog>
        </div>
    );
}