import FreeDocument from "./free-material.component";
import { connect } from "react-redux";




const mapDispatchToProp = {};

const mapStateToProps = (state) => { }


export default connect(mapStateToProps, {})(FreeDocument);