import React, { useState } from "react";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import { Link } from 'react-router-dom';
import LoginImg from "../../assets/login-image.png";
import Logo from "../../assets/iim logo.jpg";
import { Container, Button, Typography, Box, Grid, TextField } from "@mui/material";



const Login = () => {
    const [isEmailLogin, setIsEmailLogin] = useState(false);

    const toggleLoginType = () => {
        setIsEmailLogin(!isEmailLogin);
    };
    return (
        <>
            <Grid container>
                <Grid item xs={6}>
                    <Box
                        sx={{
                            background: "#DA251C",
                            padding: "25px",
                            height: "81vh",
                            height: "92.2vh",
                        }}
                    >
                        <Container maxWidth="sm" sx={{ margin: "50px auto" }}>
                            <Box paddingX={"1rem"}>
                                <img
                                    src={Logo}
                                    style={{
                                        width: "30%",
                                        aspectRatio: "7 /2",
                                        objectFit: "cover",
                                    }}
                                    alt="logo"
                                />
                                <Typography
                                    sx={{
                                        color: "white",
                                        fontSize: "35px",
                                        fontWeight: "600",
                                        margin: "15px auto",
                                    }}
                                >
                                    Setup Your Website in Couple of Clicks
                                </Typography>
                                <Box textAlign={"center"} mt={3} sx={{ padding: "35px" }}>
                                    <img src={LoginImg} style={{ width: "90%" }}></img>
                                </Box>
                            </Box>
                        </Container>
                    </Box>
                </Grid>
                <Grid item xs={6} display={"flex"} alignItems={"center"}>
                    <Grid container justifyContent="center">
                        <Grid item xs={8}>
                            <Box>
                                <Typography
                                    textAlign={"center"}
                                    sx={{
                                        fontSize: "20px",
                                        fontWeight: "600",
                                        margin: "20px auto",
                                    }}
                                >
                                    Login to IIM
                                </Typography>
                                <Typography
                                    sx={{
                                        fontSize: "16px",
                                        fontWeight: "500",
                                        margin: "13px 13px",
                                        color: "gray",
                                    }}
                                >
                                    {isEmailLogin ? " Email" : " Mobile Number"}
                                </Typography>
                                <Box></Box>
                                {isEmailLogin ? (
                                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <TextField
                                            id="outlined-basic"
                                            variant="outlined"
                                            placeholder="Enter Your Email"
                                            InputProps={{
                                                sx: {
                                                    width: "470px",
                                                    borderRadius: 4,
                                                    boxShadow:
                                                        "rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px",
                                                },
                                            }}
                                        />
                                    </Box>
                                ) : (
                                    <Box display={"flex"} justifyContent={"space-around"}>
                                        <TextField
                                            id="outlined-basic"
                                            variant="outlined"
                                            placeholder="+91"
                                            inputProps={{ readOnly: true }}
                                            InputProps={{
                                                sx: {
                                                    maxWidth: "70px",
                                                    borderRadius: 4,
                                                },
                                            }}
                                        />
                                        <TextField
                                            id="outlined-basic"
                                            variant="outlined"
                                            placeholder="999 888 777"
                                            InputProps={{
                                                sx: {
                                                    borderRadius: 4,
                                                    boxShadow:
                                                        "rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px",
                                                },
                                            }}
                                        />
                                    </Box>
                                )}
                                <Box
                                    display={"grid"}
                                    justifyContent={"center"}
                                    marginTop={"35px"}
                                >
                                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <Link to="/otp" style={{ textDecoration: "none" }}>
                                            <Button
                                                variant="standard"
                                                color="inherit"
                                                sx={{
                                                    border: "1px solid #CDEAE9",
                                                    textTransform: "none",
                                                    borderRadius: "10px",
                                                    height: "50px",
                                                    background: "#da251c",
                                                    color: "white",
                                                    mr: 1,
                                                    display: "flex",
                                                    alignItems: "center",
                                                    justifyContent: "space-between",
                                                    Width: "140px",
                                                    marginLeft: "5px",
                                                    "&:hover": {
                                                        backgroundColor: "#da251c",
                                                    },
                                                }}
                                            >
                                                Login Now
                                                <ArrowForwardIcon />
                                            </Button>
                                        </Link>
                                    </Box>

                                    <Typography
                                        textAlign={"center"}
                                        sx={{ color: "gray" }}
                                        mt={2}
                                    >
                                        Or
                                    </Typography>
                                    <Button
                                        variant="text"
                                        sx={{ color: "#da251c", textTransform: "none" }}
                                        onClick={toggleLoginType}
                                    >
                                        Login via {isEmailLogin ? "Mobile Number" : "Email"}
                                    </Button>
                                </Box>
                            </Box>

                            <Typography color={"gray"} textAlign={"center"} mt={5}>
                                by signing up, you agree to our{" "}
                                <muilink href="#" underline="none" fontWeight={"600"}>
                                    {"T&C"}
                                </muilink>{" "}
                                and{" "}
                                <Link href="#" underline="none" fontWeight={"600"}>
                                    {"Privacy Policy"}
                                </Link>
                            </Typography>
                        </Grid>
                    </Grid>
                </Grid>
            </Grid>
        </>
    );
};

export default Login;
