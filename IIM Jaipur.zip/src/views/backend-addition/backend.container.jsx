import BackendAddition from "./backend.component";
import { connect } from "react-redux";


const mapDispatchToProp = {};

const mapStateToProps = (state) => { };


export default connect(mapStateToProps, {})(BackendAddition)