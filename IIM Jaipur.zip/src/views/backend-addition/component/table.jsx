import * as React from 'react';
import {
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    IconButton,
} from '@mui/material';
import MoreVertIcon from '@mui/icons-material/MoreVert';


let row = [
    {
        transId: 'dadfsadfsa',
        date: '14th fec 2024',
        NoStu: '2',
        classPlusShare: '5'
    },
    {
        transId: 'jhjkgyde',
        date: '23th fec 2024',
        NoStu: '1',
        classPlusShare: '2'
    },
]


export default function BackendTable() {
    return (
        <TableContainer component={Paper}>
            <Table sx={{ minWidth: 650 }} aria-label="simple table">
                <TableHead>
                    <TableRow>
                        <TableCell>Transition ID</TableCell>
                        <TableCell align="right">Date</TableCell>
                        <TableCell align="right">No. of Student</TableCell>
                        <TableCell align="right">Classpluse Share</TableCell>
                        <TableCell align="right">Action</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {row.map((row) => (
                        <TableRow
                            key={row.transId}
                            sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                        >
                            <TableCell component="th" scope="row">
                                {row.transId}
                            </TableCell>
                            <TableCell align="right">{row.date}</TableCell>
                            <TableCell align="right">{row.NoStu}</TableCell>
                            <TableCell align="right">{row.classPlusShare}</TableCell>
                            <TableCell align="right">
                                <IconButton>
                                    <MoreVertIcon />
                                </IconButton>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
}