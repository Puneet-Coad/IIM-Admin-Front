import React, { useState } from "react";
import Grid from "@mui/material/Grid";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Button from "@mui/material/Button";
import { FaArrowLeft } from "react-icons/fa";
import BackendTable from "./component/table";
import Navbar from "../../comon/navbar/navbar";
import { Select, MenuItem } from "@mui/material";



const BackendAddition = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [checked, setChecked] = useState(false);

  const handleChangecheck = (event) => {
    setChecked(event.target.checked);
  };

  const handleBack = () => {
    setActiveStep((prevActiveStep) => prevActiveStep - 1);
  };

  const handleNext = () => {
    setActiveStep((prevActiveStep) => prevActiveStep + 1);
  };

  return (
    <>

      <Grid container>
        <Grid item xs={12}>
          <Navbar
            title=" Your Courses(157) "
            desc=" Add/View Courses of your brand "
            progressNum={78}
          />
        </Grid>
        <Grid item xs={12}>
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
              py: 1
            }}
          >
            <Select
              id="demo-simple-select"
              sx={{ minWidth: '8rem' }}
              size="small"
              defaultValue={'10'}
            >
              <MenuItem value={10}>Last 10 days</MenuItem>
              <MenuItem value={20}>Twenty</MenuItem>
              <MenuItem value={30}>Thirty</MenuItem>
            </Select>

            <Button
              variant="contained"
              sx={{ color: 'white' }}
            >
              Add Student
            </Button>
          </Box>
        </Grid>
        <Grid item xs={12}>
          <Grid
            container
            spacing={2}
            position={"relative"}>
            <Grid item xs={12}>

              <BackendTable />

            </Grid>
            <Grid
              item
              xs={12}
              sx={{
                position: "sticky",
                bottom: "0px",
                width: "100%",
                mt: 2,
              }}
            >
              <Paper
                sx={{
                  padding: "10px",
                  borderRadius: "20px",
                  display: "flex",
                  justifyContent: "space-between",
                }}
              >
                <Button
                  variant="outlined"
                  color="inherit"
                  disabled={activeStep === 0}
                  onClick={handleBack}
                  sx={{
                    border: "1px solid #63BEEA",
                    textTransform: "none",
                    borderRadius: "10px",
                    height: "50px",
                    color: "#63BEEA",
                    mr: 1,
                  }}
                >
                  <FaArrowLeft /> Previous
                </Button>
                <Box sx={{ display: "flex", alignItems: "center" }}>
                  {/* <Typography sx={{ fontSize: "11px" }}>
                      <Checkbox
                        checked={checked}
                        onChange={handleChangecheck}
                        inputProps={{ "aria-label": "controlled" }}
                        sx={{ fontSize: "11px" }}
                      />
                      I have read and agree to <Link href="#">the T&C</Link>
                    </Typography> */}
                </Box>
              </Paper>
            </Grid>{" "}
          </Grid>
        </Grid>
      </Grid>

    </>
  );
};

export default BackendAddition;
