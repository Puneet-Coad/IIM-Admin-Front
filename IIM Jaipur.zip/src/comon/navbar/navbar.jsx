import React, { useState } from "react";
import {Typography, Menu, Button, Box, MenuItem, } from "@mui/material";
import ArrowDropDownIcon from "@mui/icons-material/ArrowDropDown";
 





const Navbar = (props) => {
  const { title, desc } = props;
  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };



  return (

    <Box 
    sx={{ 
      display: "flex",
       justifyContent: "space-between",
       mb:3
       }}>
      <Box>
        <Typography variant="h4" sx={{ fontWeight: "600" }}>
          {title}

        </Typography>

        <Typography sx={{ fontSize: "14px", fontWeight: "500" }}>
          {desc}

          <span style={{ color: "blue" }}> Learn how </span>
        </Typography>
      </Box>

      <Box
        sx={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-around",
          gap:2
        }}
      >
         
        <Box>
          <Button
            aria-controls="dropdown-menu"
            aria-haspopup="true"
            onClick={handleClick}
            endIcon={<ArrowDropDownIcon />}

            sx={{
              background: "white",
              padding: "10px",
              color: "black",
              fontWeight: "600",
              justifyContent: "space-around",
              borderRadius: 20,
              minWidth: 235,
             
            }}
          >
            <Typography
              sx={{
                background: "#FAE8BD",
                color: "#EFB847",
                padding: "10px",
                borderRadius: "50px",
                display: "flex",
                alignItems: "center",
                height: "14px",
                fontWeight: "600",
                marginRight: "10px",
              }}
            >
              U
            </Typography>
            IIM Jaipur
          </Button>
          <Menu
            id="dropdown-menu"
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleClose}
            sx={{
              borderRadius: "20px",
              width: "217px !important",
              justifyContent: "center",
              display: "grid",
              padding: "10px",
            }}
          >
            <MenuItem onClick={handleClose}>Option 1</MenuItem>
            <MenuItem onClick={handleClose}>Option 2</MenuItem>
            <MenuItem onClick={handleClose}>Option 3</MenuItem>
          </Menu>
        </Box>
      </Box>
    </Box>

  );
};

export default Navbar;
