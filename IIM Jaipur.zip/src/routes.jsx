import React, { lazy, Suspense } from 'react';
import { Route, Routes } from "react-router-dom";

const LoginContainer = lazy(() => import('./views/login/login.container.jsx'));
const CourseContainer = lazy(() => import('./views/course/course.container'));
const UserProfileContainer = lazy(() => import('./views/user/user.component'));
const MangageBatchContainer = lazy(() => import('./views/manage-batch/managebatch.container'));
const CreateCourseContainer = lazy(() => import('./views/create-course/crate-course.container'));
const ChatContainer = lazy(() => import('./views/chat/chat.container'));
const DashboardContainer = lazy(() => import('./views/dashboard/dashboard.container'));
const SignupContainer = lazy(() => import('./components/signup'));
const BackendAddContainer = lazy(() => import('./views/backend-addition/backend.container'));
const ForgetPasswordContainer = lazy(() => import('./components/forget-password'));
const CourseDetailContainer = lazy(() => import('./views/course-detail/course-detail.container'));
const ManageFeesContainer = lazy(() => import('./views/manage-fees/managefees.container'));
const TestportalContainer = lazy(() => import('./views/testportal/testportal.container'));
const ManageCouponContainer = lazy(() => import('./views/manage-coupon/manage-coupon.container'));
const AnalyticsContainer = lazy(() => import('./views/analytics/analytics.container'));
const OtpContainer = lazy(() => import('./views/auth-pages/otp'));
const UserContainer = lazy(() => import('./views/user/user.component'));
const FreeMaterialContainer = lazy(() => import('./views/free-material/freematerial.container')); 
const FreeMaterialDocumentContainer = lazy(() => import('./views/free-material-document/free-material.container.jsx')); 






function RoutePath() {
    return (
        <Routes>
            <Route path="/login" element={<Suspense fallback={<>...</>}>
                <LoginContainer />
            </Suspense>} />
            <Route path="/" element={<Suspense fallback={<>...</>}>
                <DashboardContainer />
            </Suspense>} />
            <Route path="/create-course" element={<Suspense fallback={<>...</>}>
                <CreateCourseContainer />
            </Suspense>} />
            <Route path="/course" element={<Suspense fallback={<>...</>}>
                <CourseContainer />
            </Suspense>} />
            <Route path="/signup" element={<Suspense fallback={<>...</>}>
                <SignupContainer />
            </Suspense>} />
            <Route path="/chat" element={<Suspense fallback={<>...</>}>
                <ChatContainer />
            </Suspense>} />
            <Route path="/user-profile" element={<Suspense fallback={<>...</>}>
                <UserProfileContainer />
            </Suspense>} />

            <Route path="/backend-addition" element={<Suspense fallback={<>...</>}>
                <BackendAddContainer />
            </Suspense>} />
            <Route path="/course-detail" element={<Suspense fallback={<>...</>}>
                <CourseDetailContainer />
            </Suspense>} />
            <Route path="/forget-password" element={<Suspense fallback={<>...</>}>
                <ForgetPasswordContainer />
            </Suspense>} />
            <Route path="/manage-batch" element={<Suspense fallback={<>...</>}>
                <MangageBatchContainer />
            </Suspense>} />
            <Route path="/manage-fees" element={<Suspense fallback={<>...</>}>
                <ManageFeesContainer />
            </Suspense>} />
            <Route path="/test-portal" element={<Suspense fallback={<>...</>}>
                <TestportalContainer />
            </Suspense>} />
            <Route path="/manage-coupon" element={<Suspense fallback={<>...</>}>
                <ManageCouponContainer />
            </Suspense>} />
            <Route path="/analytics" element={<Suspense fallback={<>...</>}>
                <AnalyticsContainer />
            </Suspense>} />

            <Route path="/otp" element={<Suspense fallback={<>...</>}>
                <OtpContainer />
            </Suspense>} />

            <Route path="/user" element={<Suspense fallback={<>...</>}>
                <UserContainer />
            </Suspense>} />
            
            <Route path="/free-material" element={<Suspense fallback={<>...</>}>
                <FreeMaterialContainer />
            </Suspense>} />
            <Route path="/create-free-document" element={<Suspense fallback={<>...</>}>
                <FreeMaterialDocumentContainer />
            </Suspense>} />
        </Routes>

    )
}

export default RoutePath